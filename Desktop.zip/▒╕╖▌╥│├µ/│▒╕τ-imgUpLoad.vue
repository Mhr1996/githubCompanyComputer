<script>
uploadImage(e) {
const self = this
if (self.head_imgs.length >= 8) {
self.$vux.toast.text('最多上传8张照片')
return false
}
self.$vux.loading.show({
text: '上传中'
})
let file = e.target.files[0]
let param_file = new FormData() // 创建form对象
param_file.append('HTTP_API', 'api/common/upload')
param_file.append('upload', file) // 通过append向form对象添加数据
console.log(param_file.get('file')) // FormData私有类对象，访问不到，可以通过get判断值是否传进去
let reader = new FileReader()
reader.readAsDataURL(file)
reader.onloadend = function(e) {
//console.log(e.target)
// self.head_imgs.push(e.target.result)
}
// 添加请求头
let config = {
headers: { 'Content-Type': 'multipart/form-data' }
}

axios
.post('http://hscyhsx.app.xiaozhuschool.com/admin', param_file, config)
.then(res => {
console.log(res)
self.$vux.loading.hide()
if (res.data.code == 1) {
self.head_imgs.push(res.data.data.url)
self.$vux.toast.show({
text: '上传成功',
type: 'success',
onHide() {}
})
} else {
self.$vux.toast.text(res.data.msg)
}
})
}
</script>