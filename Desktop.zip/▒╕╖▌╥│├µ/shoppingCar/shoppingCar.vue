<template>
	<div class="shoppingCar">
		<div class="mt10 mlr_10 fsb cgf mb10 p10">
			<div><img src="@/assets/imgs/circular1.png" style="width: .29rem;height: .29rem;"> 全选</div>
			<span style="color: #ff836e;">删除</span>
		</div>
		<div class="b-r oh bgf mlr_10 pt10">
			<div class="product_item bbf5">
				<input type="checkbox" name="shop_check" v-show="false"><label class="check_lab"></label>
				<div class="mark">
					<img src="@/assets/imgs/title.png" class="product">
					<div class="info flex-cca">
						<div class="name w100">名称</div>
						<div class="pro_price w100">￥123.00</div>
					</div>
				</div>
				<div class="sliceTeam fsb">
					<span class="cut"></span>
					<span class="cipherVal">1</span>
					<span class="add"></span>
				</div>
			</div>
			<div class="product_item bbf5">
				<input type="checkbox" name="shop_check" v-show="false"><label class="check_lab"></label>
				<div class="mark">
					<img src="@/assets/imgs/title.png" class="product">
					<div class="info flex-cca">
						<div class="name w100">名称</div>
						<div class="pro_price w100">￥123.00</div>
					</div>
				</div>
				<div class="sliceTeam fsb">
					<span class="cut"></span>
					<span class="cipherVal">1</span>
					<span class="add"></span>
				</div>
			</div>
			<div class="product_item bbf5">
				<input type="checkbox" name="shop_check" v-show="false"><label class="check_lab"></label>
				<div class="mark">
					<img src="@/assets/imgs/title.png" class="product">
					<div class="info flex-cca">
						<div class="name w100">名称</div>
						<div class="pro_price w100">￥123.00</div>
					</div>
				</div>
				<div class="sliceTeam fsb">
					<span class="cut"></span>
					<span class="cipherVal">1</span>
					<span class="add"></span>
				</div>
			</div>
		</div>
		<div class="bottom flex-c">
			<div class="l bottom_info fsb flex1">
				<span class="ml10">已选(3)</span>
				<div class="mr10">合计<span class="totalPrice">￥203.00</span></div>
			</div>
			<div class="r w-5" style="width: 2rem;">
				<div class="bill" >结算</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default{
		name:"shoppingCar",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.shoppingCar{
		padding-bottom:1.4rem;
		min-height: 100vh;
		background-color: #f9f9f9;
		overflow: hidden;
		.bottom{
			position: fixed;
			bottom: 0;
			width: 100%;
			left: 0;
			height: 1rem;
			z-index: 10;
    		background-color: #fff;
			.del,.bill{
				height: 1rem;
				font-size: .32rem;
				line-height: 1rem;
				text-align: center;
				font-weight: bold;
			}
			.bill{
				background-color: #ff836e;
				color: #fff;
			}
			.del{
				background-color: #e5e5e5;
				color: #999999;
			}
			.w-5{
				width: 50%;
			}
		}
		.bottom_info{
			line-height: 1rem;
			position: relative;
		}
		.totalPrice{
			color: #ed971b;;
		}
	}
	.product_item{
		padding: .24rem;
		box-sizing: border-box;
		    height: 1.58rem;
		    position: relative;
		img.product{
			width: 1.03rem;
			height: 1.03rem;
			float: left;
			margin-right: .28rem;
		}
	}
	.mark{
		overflow: hidden;
		height: 1.03rem;
		.info{
			position: relative;
			height: 100%;
			.name{
				margin-bottom: .38rem;
				@include oneLines;
			}
			.note{
				font-size: .24rem;
				color: $g9;
				@include oneLines;
				width: 35%;
			}
			.pro_price{
				color: #f7ca49;
    			font-size: .24rem;
			}
		}
	}
	.check_lab{
		float: left;
		display: block;
		width: .29rem;
		height: .29rem;
		margin-right: .24rem;
    	margin-top: 0.32rem;
    	background: url('~@/assets/imgs/circular1.png') no-repeat;
		background-size: 100%;
	}
	.sliceTeam{
		position: absolute;
	    min-width: 1.7rem;
	    right: .25rem;
	    top: .8rem;
		.cut, .add{
			width: .4rem;
			height: .4rem;
		}
		.cut{
			background: url('~@/assets/imgs/del.png') no-repeat;
			background-size: 100%;
		}
		.add{
			background: url('~@/assets/imgs/add.png') no-repeat;
			background-size: 100%;
		}
		.cipherVal{
			display: inline-table;
			min-width: .6rem;
			text-align: center;
			color: $g9;
			white-space: nowrap;
			padding: 0 .1rem;
		}
	}
	label.active{
		background: url('~@/assets/imgs/circular.png') no-repeat;
		background-size: 100%;
		border:0px solid;
	}
	#total{
		display: none;
	}
	.total{
		float: left;
		display: block;
		width: .35rem;
		height: .35rem;
		margin-right: .24rem;
		margin-left: .24rem;
		border:1px solid #e5e5e5;
    	margin-top: 0.3rem;
    	box-sizing: border-box;
	}
</style>