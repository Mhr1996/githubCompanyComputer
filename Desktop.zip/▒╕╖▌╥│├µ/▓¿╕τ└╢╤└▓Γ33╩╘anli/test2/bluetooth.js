class Bluetooth {
  constructor() {
    this.start = (data) => {//初始化蓝牙适配器
      data = data ? data : {};
      if (data.order && data.mac_id) {
        let that = this;
        this.state = {
          device_list: []
        };
        this.data = data;
        wx.closeBluetoothAdapter({ //关闭蓝牙模块，使其进入未初始化状态。调用该方法将断开所有已建立的链接并释放系统资源。建议在使用小程序蓝牙流程后调用，与wx.openBluetoothAdapter成对调用。
          success: function (res) {
            wx.openBluetoothAdapter({//初始化小程序蓝牙模块，生效周期为调用wx.openBluetoothAdapter至调用wx.closeBluetoothAdapter或小程序被销毁为止。 在小程序蓝牙适配器模块生效期间，开发者可以正常调用下面的小程序API，并会收到蓝牙模块相关的on回调。
              success(res) {
                that.isOpen();
              },
              fail(err) {
                wx.showModal({
                  title: '提示',
                  content: '操作失败,请确认手机蓝牙是否开启?',
                  success() {
                    that.isOpen();
                    //wx.navigateBack();
                  }
                });
              }
            });
          }
        });
      } else {
        wx.showModal({
          title: '提示',
          content: 'order/mac_id不能缺少',
          success() {
            wx.navigateBack();
          }
        });
      }
    };
  };
  isOpen = () => { //本机蓝牙适配器状态
    let that = this;
    // wx.showLoading({
    //   mask: true,
    //   title: '请稍后...'
    // });
    wx.getBluetoothAdapterState({ //获取本机蓝牙适配器状态
      complete(res) {
        console.log(res);
        if (res.available) { //蓝牙适配器是否可用
          that.search();
        } else {
          wx.hideLoading();
          wx.showModal({
            title: '提示',
            content: '当前程序需要使用蓝牙,请打开手机蓝牙！',
            success(res) {
              wx.navigateBack();
            }
          });
        }
        //监听蓝牙适配器状态  
        wx.onBluetoothAdapterStateChange((res) => {
          if (!res.available) { //没有打开手机蓝牙
            wx.showModal({
              title: '提示',
              content: '当前程序需要使用蓝牙,请打开手机蓝牙！',
              success(res) {
                wx.navigateBack();
              }
            });
          }
        })
      }
    });
  };
  search = () => { //搜索设备
    let that = this;
    this.state.is_find = 0;
    wx.startBluetoothDevicesDiscovery({  //开始搜寻附近的蓝牙外围设备。注意，该操作比较耗费系统资源，请在搜索并连接到设备后调用 stop 方法停止搜索。
      services: [], //  蓝牙设备主 service 的 uuid 列表
      allowDuplicatesKey: false,//false为不允许上报同一设备
      success(res) {
        console.log(res);
        if (that.data.mac_id) {
          setTimeout(() => {
            if (that.state.is_find == 0) {
              console.log('找不到设备');
              wx.hideLoading();
              that.reconnection('搜索不到当前蓝牙设备?', '重新搜索');
            }
          }, 6000);
        };
        wx.onBluetoothDeviceFound(res => { //监听寻找到新设备的事件
          console.log(res);
          let devices = res.devices;
          for (let i in devices) {
            if (devices[i].deviceId == that.data.mac_id) {
              console.log('找到设备');
              that.state.is_find = 1;
              that.state.needDevicedMsg = devices[i];
              wx.stopBluetoothDevicesDiscovery({ //停止搜寻附近的蓝牙外围设备。若已经找到需要的蓝牙设备并不需要继续搜索时，建议调用该接口停止蓝牙搜索。
                fail: res => console.log(res),
              });
              that.connect();
              break;
            }
          }
        });
      },
      fail(err) {
        wx.hideLoading();
        console.log(err);
      }
    })
  };
  connect = () => {//连接设备
    let that = this;
    // console.log(this.state.needDevicedMsg);
    wx.createBLEConnection({ //连接低功耗蓝牙设备。
      deviceId: that.data.mac_id,
      success(res) {
        console.log('连接成功');
        that.service();
      },
      fail(err) {
        wx.hideLoading();
        that.reconnection('蓝牙连接失败', '重新连接');
      }
    });
  };
  service = () => {//获取当前蓝牙服务
    let that = this;
    wx.getBLEDeviceServices({ //获取蓝牙设备所有服务(service)。
      deviceId: that.data.mac_id,
      success(res) {
        console.log(res);
        res.services.forEach((item, index) => {
          if (item.uuid == '0000FFE5-0000-1000-8000-00805F9B34FB') {
            that.state.serviceId = item.uuid;
            that.characteristic();
          }
        });
      },
      fail(err) {
        wx.hideLoading();
        console.log('service获取失败');
        console.log(err);
        that.reconnection('蓝牙服务获取失败', '重新连接');
      }
    });
  };
  characteristic = () => {//获取连接设备的特征值
    let that = this;
    wx.getBLEDeviceCharacteristics({
      deviceId: that.data.mac_id,
      serviceId: that.state.serviceId,
      success(res) {
        console.log('特征值');
        console.log(res);
        for (let i = 0; i < res.characteristics.length; i++) {
          if (res.characteristics[i].properties.notify) {
            that.state.notifyCharacteristicsId = res.characteristics[i].uuid;
          }
          if (res.characteristics[i].properties.write) {
            that.state.writeCharacteristicsId = res.characteristics[i].uuid
          } else if (res.characteristics[i].properties.read) {
            that.state.readCharacteristicsId = res.characteristics[i].uuid;
          }
        }
        console.log('订阅特征值：' + that.state.notifyCharacteristicsId);
        console.log('写的特征值：' + that.state.writeCharacteristicsId);
        console.log('读的特征值:' + that.state.readCharacteristicsId);
        that.notify();
      },
      fail() {
        wx.hideLoading();
        that.reconnection('蓝牙服务获取失败', '重新连接');
      }
    });
  };
  notify = () => {//启用订阅
    console.log('notify');
    let that = this;
    wx.notifyBLECharacteristicValueChange({
      state: true,
      deviceId: that.data.mac_id,
      serviceId: '0000FFE0-0000-1000-8000-00805F9B34FB',
      characteristicId: '0000FFE4-0000-1000-8000-00805F9B34FB',
      success(res) {
        console.log('notify启用成功');
        console.log(res);
        that.send(that.data.order, (res) => {
          console.log(res);
        });
      },
      fail() {
        console.log('notify失败');
        wx.hideLoading();
        that.reconnection('蓝牙服务获取失败', '重新连接');
      },
    });
  };
  send = (data, cb) => {//发送数据并读取返回数据 data为需要发送的数据指令（16位16进制组成的字符串）
    let that = this;
    console.log(data);
    // 向蓝牙设备发送一个0x00的16进制数据
    let buffer = new ArrayBuffer(data.length / 2);
    let dataView = new DataView(buffer);
    for (var i = 0; i < data.length / 2; i++) {
      dataView.setUint8(i, '0x' + data.substr(i * 2, 2));
    }
    wx.writeBLECharacteristicValue({ //向低功耗蓝牙设备特征值中写入二进制数据。注意：必须设备的特征值支持 write 才可以成功调用。
      deviceId: that.data.mac_id,
      serviceId: '0000FFE5-0000-1000-8000-00805F9B34FB',
      characteristicId: '0000FFE9-0000-1000-8000-00805F9B34FB',
      value: buffer,
      success(res) {
        console.log('发送数据成功!');
        let num = 0;
        that.state.timer = setInterval(() => {
          num++;
          console.log(num);
          if (num == 15) {
            clearInterval(that.state.timer);
            cb({ code: 0 });
          }
        }, 1000);
        wx.onBLECharacteristicValueChange((res) => {
          clearInterval(that.state.timer);
          console.log('监听到转化返回的数据:' + that.buf2hex(res.value));
          cb({ code: 1, data: that.buf2hex(res.value) });
        });
      },
      fail(err) {
        console.log(err);
        wx.hideLoading();
        cb({ code: 0, msg: '操作失败!' });
      }
    })
  };
  buf2hex = (buffer) => {
    return Array.prototype.map.call(new Uint8Array(buffer), x => ('00' + x.toString(16)).slice(-2)).join('');
  };
  reconnection = (content, confirmText) => {//重新连接
    let that = this;
    wx.showModal({
      title: '提示',
      content: content ? content : '',
      confirmText: confirmText ? confirmText : '确定',
      success(res) {
        if (res.confirm) {
          wx.closeBluetoothAdapter({
            success(res) {
              that.isOpen();
            }
          });
        } else {
          wx.navigateBack();
        }
      }
    });
  };
}
export { Bluetooth }