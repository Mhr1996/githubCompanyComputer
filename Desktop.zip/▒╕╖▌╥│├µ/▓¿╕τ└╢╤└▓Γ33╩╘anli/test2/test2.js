const app = getApp();
import { Bluetooth } from './bluetooth.js'
const bluetooth = new Bluetooth();
Page({

  data: {

  },

  onLoad: function (e) {

  },

  onReady: function () {

  },

  onShow: function () {

  },
  connect(){
    console.log(999)
    bluetooth.start({
      order: '244244AE010C7381ABD73604', mac_id: "B0:7E:11:E3:27:A3", cb: (res) => {
        console.log(res);
        
      }
    });
  }
})