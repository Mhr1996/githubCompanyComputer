<script>
import jsSHA from './jsSHA';
wx_js(signature,timestamp,nonceStr){
    var e=decodeURIComponent('jsapi_ticket='+signature+'&noncestr='+nonceStr+'&timestamp='+timestamp+'&url='+location.href.split("#")[0]),
      s=new jsSHA(e,"TEXT"),
      signature=s.getHash("SHA-1","HEX");
    return signature;
  }

let timestamp= that.timestamp(),nonceStr=that.nonceStr(),ticket=that.tool.wx_js(res.data.data.ticket,timestamp,nonceStr)
	console.log(timestamp+','+nonceStr+','+res.data.data.ticket)
	wx.config({
		debug: false, // 开启调试模式,调用的所有api的返回值会在客户端//alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
		appId: that.appid(), // 必填，公众号的唯一标识
		timestamp: timestamp, // 必填，生成签名的时间戳
		nonceStr:  nonceStr, // 必填，生成签名的随机串
		signature: ticket ,// 必填，签名，见附录1
		jsApiList: ['scanQRCode'] // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
	});
	wx.ready(function(){
		wx.scanQRCode({
			needResult: 1, // 默认为0，扫描结果由微信处理，1则直接返回扫描结果，
			scanType: ["qrCode","barCode"], // 可以指定扫二维码还是一维码，默认二者都有
			success: function (res) {
				that.scanner_onOff = 0;
				if(res.resultStr.indexOf('macno') != -1 && that.tool.getUrlParam('macno',null,res.resultStr)){
					that.$router.push({path:'/bingPhone/pay',query:{macno:that.tool.getUrlParam('macno',null,res.resultStr)}})
				}else{
					that.$toast.fail({message:'当前二维码无效',forbidClick: true});
					setTimeout(function(){WeixinJSBridge.call('closeWindow')},2000);
				}
			},
			complete(){
					if(that.scanner_onOff){
						WeixinJSBridge.call('closeWindow');
					}
			},
			error:function(err){
				alert(JSON.stringify(err));
			},

		});
	})
</script>