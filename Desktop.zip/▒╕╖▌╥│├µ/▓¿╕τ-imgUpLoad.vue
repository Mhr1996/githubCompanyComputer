<template>
  <div class="plr20 pt20">
    <div class='border-r1 shadow bw'>
      <div class='p24'>
        <textarea placeholder="我们有哪些做得不够好，请留言给我们！" name='content' class='pw100 h240' v-model="content"/>
      </div>
      <div class="pl24 font0 clearfix">
        <template>
          <div class='pic_wrap' v-for="(item,index) of imgLook">
            <div class="close flex_aj" @click.stop="delImg(index)">&times;</div>
            <img class="pic" :src="item" @click="handleBannerClick(index)"></img>
          </div>
        </template>
        <div class='pic_wrap' @click="chooseType">
          <img class="pic" src="@/assets/imgs/add.png"></img>
        </div>
      </div>
    </div>
    <input @change="fileChange($event)" type="file" id="upload_file" style="display: none"
           accept="image/*"/>
    <div class='pt110 plr30 pb20'>
      <div class="colw h100 flex_aj bgc1 font15 btn_tap border-r1" @click="handelSubmit">提交</div>
    </div>
  </div>
</template>
<script>
  export default {
    name: "feedback",
    data() {
      return {
        imgLook: [],
        imgFile: [],
        showGallary: false,
        gallary_num: 0,
        content:'',
        onOff:0
      }
    },
    created() {
    },
    methods: {
      chooseType() {
        document.getElementById('upload_file').click();
      },
      fileChange(e) {
        if(this.imgFile.length>6){
          this.$toast('最多上传六张图片');
          return false;
        }
        let that = this;
        let file = e.target.files[0];
        if (file) {
          this.imgFile.push(file);
          let reader = new FileReader();
          reader.readAsDataURL(file);
          reader.onload = function (e) {
            console.log(this)
            that.imgLook.push(this.result);
          }
        } else {
          console.log('无选择图片');
        }
      },
      delImg(index) {
        this.imgLook.splice(index, 1);
        this.imgFile.splice(index, 1);
      },
      handleBannerClick(index) {
        this.gallary_num = index;
        this.showGallary = true
      },
      handleGallaryClose() {
        this.showGallary = false
      },
      handelSubmit(){
        let that = this;
        if(this.onOff == 1)return false;
        if(this.Dlc.isNull(this.content)){
          this.$toast('你输入反馈内容');
        }else if(this.imgFile.length==0){
          this.$toast('请上传图片');
        }else{
          let formData = new FormData();
          formData.append('api_name','add_feedback');
          formData.append('content',this.content);
          this.imgFile.forEach((item,index)=>{
            formData.append('img[]',item);
          });
          this.onOff = 1;
          this.$toast.loading({
            duration:0,
            forbidClick:true,
            loadingType:'spinner',
            message:'提交中...'
          });
          this.Http.post('Wxsite/User/api',formData,'multipart/form-data').then((res) => {
            console.log(res);
            this.$toast.clear();
            if(res.data.code == 1){
              setTimeout(function(){
                that.$router.go(-1);
              },2000);
            }else{
              this.onOff = 0;
            }
            this.$toast(res.data.msg);
          });
        }
      }
    }
  }
</script>

<style scoped lang="scss">
  .pic_wrap {
    position: relative;
    width: 1.5rem;
    height: 1.5rem;
    border-radius: .1rem;
    margin-bottom: .2rem;
    margin-right: .14rem;
    overflow: hidden;
    float: left;
    .close {
      position: absolute;
      right: 0;
      top: 0;
      font-size: .32rem;
      width: .4rem;
      height: .4rem;
      background: rgba(0, 0, 0, .5);
      border-radius: 50%;
      color: #fff;
    }
    img.pic {
      width: 100%;
      height: 100%;
    }
    .delete {
      position: absolute;
      right: 0;
      top: 0;
      background: rgba(0, 0, 0, 0.5);
      width: .4rem;
      height: .4rem;
      border-radius: 50%;
    }
  }
</style>