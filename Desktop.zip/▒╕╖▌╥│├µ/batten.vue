<template>
  <div class="Batten">
    <div class="index" v-if="edition == ''">
      <div class="top">
        <div class="container">
          <div v-for="(item, index) in service_link" :key="index">
            <a :href="item.link" style="color:#fff!important">
              <img :src="item.img" style="width:24px;height:24px;"/>
              {{ item.title }}
            </a>
            <!-- <a
              :href="item.link"
              class="tb"
              v-else-if="item.title.indexOf('淘宝') > -1"
              style="color:#fff!important"
            >
              <img src="@/assets/imgs/ic_tb_01.png" />{{ item.title }}
            </a>
            <a :href="item.link" v-else style="color:#fff!important">{{
              item.title
            }}</a> -->
          </div>
          <div class="phone">
            <img src="@/assets/imgs/ic_dh.png" />{{
              company_info.service_hotline
            }}
          </div>
          <div>
            <a href="https://weibo.com/6434180108/profile?topnav=1&wvr=6"><img src="@/assets/imgs/ic_xlwb.png" /></a>
            <!-- <img src="@/assets/imgs/ic_txwb.png" /> -->
            <div @mouseover="wxblock()" @mouseout="wxblock()" style="margin-left: 10px;cursor: pointer;"><img src="@/assets/imgs/ic_wx.png" /></div>
          </div>
          <img v-show="wxoff" src="@/assets/imgs/wx.png" style="position: absolute; z-index: 296; right: 0; top: 30px;"/>
        </div>
      </div>
      <div class="center">
        <div class="container">
          <router-link tag="div" class="logo" to="/"
            ><img src="@/assets/imgs/logo.png"
          /></router-link>
          <ul>
            <li v-for="(item, index) in nav_list" :key="index" @mouseover="item.title=='产品中心'?productStatus():item.title=='新闻中心'?newsStatus():''">
              <!-- 判断内链外链 点击title 传递给当前页面轮播图 -->
              <a :href="item.connect" v-if="item.connect_type == 2">{{
                item.title
              }}</a>
              <router-link
                :to="{
                  path: item.connect,
                  query: { id: item.id }
                }"
                :class="{
                  active: option == (item.connect != '/' ? item.connect : '')
                }"
                v-else
                >{{ item.title }}</router-link
              >
            </li>
            <!-- ui图没有的栏目隐藏 -->
          </ul>
        </div>
        <!-- 产品中心下拉 -->
        <div
          class="bg_bluep"
          v-show="!ps && option == 'ProductCenter'"
          @mouseout="productClose()"
          @mouseover="productStatus()"
          style="height: 303px;"
        >
          <div
            style="background-color: rgba(54, 182, 249, 0.5);opacity: 0.7;width: 100%;height: 303px;left: 0;top: 0;    position: absolute;"
            :style="false ? 'height: 603px' : 'height: 303px;'"
          ></div>
          <div class="container" style="overflow: initial;height: 303px;justify-content: start; display: flex; flex-wrap: wrap;">
            <!-- <router-link to="Phototherapy" class="text_box" tag="div">
              <div class="name w100 bold">308光疗仪</div>
              <div class="info w100">氯化氙308nm准分子光治疗白癜风、银屑病</div>
              <img src="@/assets/imgs/p1.png" style="width:206px;height:206px;" />
            </router-link>
            <router-link to="MultiplyCap" class="text_box" tag="div">
              <div class="name w100 bold">激光生发帽</div>
              <div class="info w100">全球最轻激光生发帽，激活毛囊 防脱生发</div>
              <img src="@/assets/imgs/p2.png" />
            </router-link>
            <div class="text_box three">
              <div class="name w100 bold">UVB光疗仪</div>
              <div class="info w100">
                荷兰飞利浦紫外线灯管，辅助治疗白癜风、银屑病
              </div>
              <img src="@/assets/imgs/p3.png" />
            </div> -->
            <div v-for="(item,index) of product_list" v-if="index<6" class="text_box">
              <a :href="item.url" tag="div" v-if="item.url_type == 2">
                <div class="name w100 bold">{{ item.title }}</div>
                <div class="info w100">{{ item.introduce }}</div>
                <img :src="item.img" style="width:206px;height:206px;"/>
              </a>
              <router-link :to="item.url" tag="div" v-if="item.url_type == 1">
                <div class="name w100 bold">{{ item.title }}</div>
                <div class="info w100">{{ item.introduce }}</div>
                <img :src="item.img" style="width:206px;height:206px;" />
              </router-link>
            </div>
             
          </div>
        </div>
        <div
          class="news_head"
          v-show="!ns && option == 'newsCenter'"
          @mouseout="newsClose()"
          @mouseover="newsStatus()"
          style="position: relative; z-index: 2;"
        >
          <div class="container">
            <div class="new_b">
              <div @click="skipNews(4)">
                <img src="@/assets/imgs/new_1.png" />
                <span>企业新闻</span>
              </div>
              <div @click="skipNews(5)">
                <img src="@/assets/imgs/new_2.png" />
                <span>媒体报道</span>
              </div>
              <div @click="skipNews(6)">
                <img src="@/assets/imgs/new_3.png" />
                <span>视频中心</span>
              </div>
              <div @click="skipNews(8)">
                <img src="@/assets/imgs/new_4.png" />
                <span>产品咨询</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="phototherapy" v-if="edition == 'Phototherapy'">
      <!-- 308 -->
      <div class="top">
        <div class="container attend">
          <router-link tag="div" class="logo" to="/Phototherapy"
            ><img src="@/assets/imgs/ed2Logo.png"
          /></router-link>
          <router-link tag="div" to="/" class="jump">半岛家用官网</router-link>
          <a :href="item.url" v-if="item.url_type == 2" 
            v-for="(item, index) in product_list" 
            style="color:#fff;" 
            class="jump cf"
            :class="item.url == 'Phototherapy' ? 'active' : ''">{{
            item.title
          }}</a>
          <router-link
            tag="div"
            :to="item.url"
            class="jump"
            :class="item.url == 'Phototherapy' ? 'active' : ''"
            v-for="(item, index) in product_list"
            :key="'a'+index"
            v-if="item.url_type == 1"
            >{{ item.title }}</router-link
          >
          
          <!-- <router-link tag="div" to="/MultiplyCap" class="jump"
            >激光生发仪</router-link
          >
          <router-link tag="div" to="" class="jump">UVB光疗仪</router-link> -->
          <div v-for="(item, index) in service_link" :key="'b'+index">
             <a :href="item.link" style="color:#fff!important">
              <img :src="item.img" style="width:24px;height:24px;"/>
              {{ item.title }}
            </a>
            <!-- <a
              :href="item.link"
              class="tb"
              v-else-if="item.title.indexOf('淘宝') > -1"
              style="color:#fff!important"
            >
              <img src="@/assets/imgs/ic_tb_01.png" />{{ item.title }}
            </a>
            <a :href="item.link" v-else style="color:#fff!important">{{
              item.title
            }}</a> -->
          </div>
          <div class="phone">
            <img src="@/assets/imgs/ic_dh.png" />{{
              company_info.service_hotline
            }}
          </div>
          <!-- <div>
            <img src="@/assets/imgs/ic_xlwb.png" />
            <img src="@/assets/imgs/ic_txwb.png" />
            <img src="@/assets/imgs/ic_wx.png" />
          </div> -->
        </div>
      </div>
      <div class="center">
        <div class="container">
          <router-link tag="div" class="logo" to="/Phototherapy"
            ><img src="@/assets/imgs/ed2BigLogo.png"
          /></router-link>
          <ul>
            <li v-for="(item, index) in nav_list2" :key="'c'+index">
              <a :href="item.connect" v-if="item.connect_type == 2">{{
                item.title
              }}</a>
              <router-link
                :to="{
                  path: item.connect,
                  query: { id: item.id }
                }"
                :class="{ active: option == item.connect }"
                v-else
                >{{ item.title }}</router-link
              >
            </li>
          </ul>
          <!-- <div class="searchRow">
            <input type="" name="" />
            <div class="search"></div>
          </div> -->
        </div>
      </div>
    </div>
    <div class="MultiplyCap" v-if="edition == 'MultiplyCap'">
      <div class="top">
        <div class="container attend">
          <router-link tag="div" class="logo" to="/MultiplyCap"
            ><img src="@/assets/imgs/ed2Logo.png"
          /></router-link>
          <router-link tag="div" to="/" class="jump">半岛家用官网</router-link>
          <a :href="item.url" 
            v-if="item.url_type == 2" 
            v-for="(item, index) in product_list" 
            style="color:#fff;" 
            class="jump cf"
            :class="item.url == 'Phototherapy' ? 'active' : ''">{{
            item.title
          }}</a>
          <router-link
            tag="div"
            :to="item.url"
            class="jump"
            :class="item.url == 'MultiplyCap' ? 'active' : ''"
            v-for="(item, index) in product_list"
            :key="'d'+index"
            v-if="item.url_type == 1" 
            >{{ item.title }}</router-link
          >
          <!-- <router-link tag="div" to="/MultiplyCap" class="jump active"
            >激光生发仪</router-link
          >
          <router-link tag="div" to="" class="jump">UVB光疗仪</router-link> -->

          <div v-for="(item, index) in service_link" :key="'e'+index">
            <a :href="item.link" style="color:#fff!important">
              <img :src="item.img" style="width:24px;height:24px;"/>
              {{ item.title }}
            </a>
            <!-- <a
              :href="item.link"
              class="tb"
              v-else-if="item.title.indexOf('淘宝') > -1"
              style="color:#fff!important"
            >
              <img src="@/assets/imgs/ic_tb_01.png" />{{ item.title }}
            </a>
            <a :href="item.link" v-else style="color:#fff!important">{{
              item.title
            }}</a> -->
          </div>
          <div class="phone">
            <img src="@/assets/imgs/ic_dh.png" />{{
              company_info.service_hotline
            }}
          </div>
          <!-- <div>
            <img src="@/assets/imgs/ic_xlwb.png" />
            <img src="@/assets/imgs/ic_txwb.png" />
            <img src="@/assets/imgs/ic_wx.png" />
          </div> -->
        </div>
      </div>
      <div class="center">
        <div class="container">
          <router-link tag="div" class="logo" to="/MultiplyCap"
            ><img src="@/assets/imgs/multiplyCapLogo.png"
          /></router-link>
          <ul>
            <li v-for="(item, index) in nav_list3" :key="'f'+index">
              <a :href="item.connect" v-if="item.connect_type == 2">{{
                item.title
              }}</a>
              <router-link
                :to="{
                  path: item.connect,
                  query: { id: item.id }
                }"
                :class="{ active: option == item.connect }"
                v-else
                >{{ item.title }}</router-link
              >
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Batten",
  data() {
    return {
      ps: true,
      ns: true,
      param: {},
      wxoff:false,
      nav_list: [],
      nav_list2: [],
      nav_list3: [],
      product_list: [],
      company_info: {},
      service_link: []
    };
  },
  props: {
    option: {
      default: ""
    },
    edition: {
      default: ""
    }
  },
  created() {
    this.getNavList();
    this.getNavList2();
    this.getNavList3();
    this.getProductList();
    this.getCompanyInfo();
    this.getServiceLink();
  },
  methods: {
    getNavList() {
      this.param.api_name = "jy_banner_type";
      this.$http.post("/wxsite/Website/api", this.param).then(res => {
        // console.log(res);
        if (res.data.code == 1) {
          res.data.data.forEach((v,k)=>{
            v.connect=v.connect.replace(/\s+/g,""); 
          })

          this.nav_list = res.data.data;
        }
      });
    },
    getNavList2() {
      this.param.api_name = "slb_banner_type";
      this.$http.post("/wxsite/Website/api", this.param).then(res => {
        // console.log(res);
        if (res.data.code == 1) {
          this.nav_list2 = res.data.data;
        }
      });
    },
    getNavList3() {
      this.param.api_name = "sfm_banner_type";
      this.$http.post("/wxsite/Website/api", this.param).then(res => {
        // console.log(res);
        if (res.data.code == 1) {
          this.nav_list3 = res.data.data;
        }
      });
    },
    getProductList() {
      this.param.api_name = "product_list";
      this.param.page = 1;
      this.param.pagesize = 999;
      this.$http.post("/wxsite/Website/api", this.param).then(res => {
        // console.log(res);
        if (res.data.code == 1) {
          this.product_list = res.data.data;
        }
      });
    },
    getCompanyInfo() {
      this.param.api_name = "contact_pc";
      this.$http.post("/wxsite/Website/api", this.param).then(res => {
        // console.log(res);
        if (res.data.code == 1) {
          this.company_info = res.data.data;
        }
      });
    },
    getServiceLink() {
      this.param.api_name = "t_link_pc";
      this.$http.post("/wxsite/Website/api", this.param).then(res => {
        // console.log(res);
        if (res.data.code == 1) {
          this.service_link = res.data.data;
        }
      });
    },
    productStatus() {
      this.ps = false;
    },
    productClose() {
      this.ps = true;
    },
    newsStatus() {
      this.ns = false;
    },
    newsClose() {
      this.ns = true;
    },
    skipNews(index) {
      this.$emit("check", index);
    },
    wxblock(){
      this.wxoff=!this.wxoff;
    }
  }
};
</script>

<style lang="scss" scoped>
@import "@/assets/css/common.scss";
.top {
  height: 30px;
  background-color: #7ecef4;
  overflow: hidden;
  .container {
    text-align: right;
    div {
      display: inline-table;
      color: #fff;
      margin-left: 40px;
      line-height: 30px;
    }
  }
}

.center {
  height: 120px;
  position: relative;
  width: 100%;
  .container {
    overflow: hidden;
    height: 120px;
  }
  .logo {
    margin-top: 27px;
    cursor: pointer;
    display: inline-table;
    float: left;
  }
  ul {
    text-align: right;
    position: absolute;
    right: 0;
    bottom: 10px;
    width: 820px;
    margin-right: -10px;
    li {
      display: inline-table;
      width: 78px;
      height: 34px;
      line-height: 34px;
      margin-left: 45px;
      position: relative;
      cursor: pointer;
      //   padding: 10px 10px;
      box-sizing: border-box;
      text-align: center;
      a {
        display: inline-block;
        width: 100%;
        height: 100%;
      }
    }
    li:hover {
      color: #28a9ff;
      &:after {
        content: "";
        position: absolute;
        width: 58px;
        bottom: -4px;
        height: 2px;
        background-color: #28a9ff;
        left: 10px;
      }
    }
    .active {
      color: #28a9ff;
      &:after {
        content: "";
        position: absolute;
        width: 58px;
        bottom: -4px;
        height: 2px;
        background-color: #28a9ff;
        left: 10px;
      }
    }
  }
}
.phototherapy {
  .top {
    .logo {
      margin-left: 0px;
      float: left;
      img {
        height: 30px;
      }
    }
  }
  .attend {
    div {
      margin-left: 20px;
    }
    .jump {
      padding: 0 7px;
      cursor: pointer;
    }
    .active {
      background-color: #a7e4f9;
    }
  }
}
.MultiplyCap {
  .center {
    li {
      margin-left: 35px;
    }
  }
  .top {
    .logo {
      margin-left: 0px;
      float: left;
      img {
        height: 30px;
      }
    }
  }
  .attend {
    div {
      margin-left: 20px;
    }
    .jump {
      padding: 0 7px;
      cursor: pointer;
    }
    .active {
      background-color: #a7e4f9;
    }
  }
}
.w100 {
  width: 100%;
}
.bg_bluep {
  position: relative;
  z-index: 2;
  .container {
    display: flex;
    justify-content: space-between;
    &:after {
      content: "";
      position: absolute;
      top: -49px;
      left: 639px;
      width: 76px;
      height: 55px;
      z-index: 2;
      cursor: pointer;
    }
  }
  .text_box {
    display: block;
    width: 33.33%;
    height: 303px;
    display: flex;
    flex-direction: column;
    align-items: center;
    z-index: 2;
    cursor: pointer;
    .name {
      margin-top: 36px;
      /*padding-left: 70px;*/
      box-sizing: border-box;
      margin-bottom: 10px;
      font-size: 16px;
      color: #505153;
    }
    .info {
      /*padding-left: 70px;*/
      box-sizing: border-box;
      margin-bottom: 10px;
      color: #606061;
    }
  }
}

.searchRow {
  position: absolute;
  top: 12px;
  right: 0;
  width: 256px;
  display: flex;
  input {
    width: 206px;
    height: 31px;
    margin-right: 7px;
    border: 1px solid #ccc;
    border-radius: 3px;
    padding-left: 10px;
  }
  .search {
    width: 40px;
    height: 32px;
    background: url("~@/assets/imgs/search.png") no-repeat #0099ff;
    background-size: 26px 26px;
    background-position: center;
  }
}

.news_head {
  height: 111px;
  width: 100%;
  background: url("~@/assets/imgs/newsHead.png") repeat-x;
  .container {
    height: 111px;
    display: flex;
  }
  .new_b {
    margin: 0 auto;
    display: flex;
    justify-content: space-around;
    width: 70%;
    align-items: center;
    font-size: 16px;
    color: #505153;
    font-weight: bold;
    & div:hover {
      color: #4f72ca;
      cursor: pointer;
    }
    img {
      margin-right: 15px;
    }
  }
}
.bg_bluep .text_box{
  position: relative;
  &:nth-child(3):before{
    content:'';
    position: absolute;
    background: url("~@/assets/imgs/bg_2.png");
    width: 10px;
    height: 183px;
    top: 70px;
    right: 0;
  }
  &:after{
    content:'';
    position: absolute;
    background: url("~@/assets/imgs/bg_2.png");
    width: 10px;
    height: 183px;
    top: 70px;
    left: 0;
  }
}
/*.three{
  &:before{
    content:'';
    position: absolute;
    background: url("~@/assets/imgs/bg_2.png");
    width: 10px;
    height: 183px;
    top: 70px;
    right: 0;
  }
}*/
</style>
