import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
  	products: [
  		{
  			name: '马云',
  			price: 200,
  		},
  		{
  			name: '马化腾',
  			price: 150,
  		},
  		{
  			name: '马冬梅',
  			price: 23,
  		},
  		{
  			name: '马国良',
  			price: 180,
  		}
  	]
  },
  mutations: {
  	removeOne(state){
		state.products.forEach( pro =>{
			pro.price-=1;
		})
	}
  },
  getters:{
  	computedTwo(state){
  		var returnList=state.products.map(
			product => {
				return {
					name: product.name+"v6",
					price: product.price+"v2"
				}
			}
		);
		return returnList;
  	}
  },
  actions: {
  }
})
