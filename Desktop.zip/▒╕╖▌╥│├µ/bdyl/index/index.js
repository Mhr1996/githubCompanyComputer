const app = getApp()
Page({
    data: {
        background: ['../../image/banner.png', '../../image/banner.png', '../../image/banner.png'],
        indicatorDots: true,
        vertical: false,
        autoplay: true,
        circular: true,
        interval: 2000,
        duration: 500,
        previousMargin: 0,
        nextMargin: 0,
        off:false,
        iconList:null,
        dlcurl:'',
        bluetooth: null
    },

    onLoad: function(e) {
        let self = this

    },

    onShow: function() {
        console.log("index.js")
        let self = this
        //功能列表查询
        app.mt.gd(app.wxRequest,
          '/wxsite/Common/api', {
              api_name: 'function_app_list',
              type:2
          }, (res) => {
            self.setData({
                iconList: res
            })
          }, app.tools.error_tip
        );
        //最近光疗历史
        app.mt.gd(app.wxRequest,
            '/wxsite/Shair/api', {
                api_name: 'index'
            }, (res) => {
            }, app.tools.error_tip
        );
        console.log(app.globalData)
        self.setData({
            nickName: wx.getStorageSync('nickName'),
            avatarUrl: wx.getStorageSync('avatarUrl'),
            dlcurl: app.globalData.dlcurl,
            bluetooth: app.globalData.bluetooth
        });

        setInterval(()=>{
          self.setData({
            bluetooth: app.globalData.bluetooth
          });
        }, 5000);
    },

    listeningEvent(e) {
        this.onShow();
    }
})