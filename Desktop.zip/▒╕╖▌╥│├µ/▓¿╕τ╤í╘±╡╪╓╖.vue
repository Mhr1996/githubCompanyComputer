<template>
  <article class="wrap">
    <iframe id="mapPage" width="100%" height="100%" frameborder='0' src="http://apis.map.qq.com/tools/locpicker?search=1&type=1&key=OB4BZ-D4W3U-B7VVO-4PJWW-6TKDJ-WPB77&referer=myapp">
    </iframe>
    <div class="back bgc1 flex_aj shadow" @click="hide">
      <img :src="require('@/assets/imgs/back.png')" style='width:.6rem;'/>
    </div>
  </article>
</template>

<script>
    export default {
        name: "index",
        data() {
            return {}
        },
        created() {
          let that = this;
          window.addEventListener('message', function (e) {
            if (e.data && e.data.module == 'locationPicker') {
              let data = {
                lat:e.data.latlng.lat,
                lng:e.data.latlng.lng,
                address:e.data.poiaddress,
                poiname:e.data.poiname
              };
              that.$emit('getLocation',data);
            }
          }, false);
        },
        mounted() {

        },
        methods: {
          hide(){
            this.$emit('mapSearchVisible',false);
          }
        }
    }
</script>

<style scoped lang='scss'>
  .wrap{
    position: fixed;
    left: 0;
    top: 0;
    width: 100vw;
    height: 100vh;
    .back{
      position: fixed;
      bottom: .8rem;
      right: .2rem;
      width:1rem;
      height: 1rem;
      border-radius: 50%;
    }
  }
</style>
