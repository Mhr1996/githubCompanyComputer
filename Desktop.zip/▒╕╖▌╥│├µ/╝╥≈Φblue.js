const { regeneratorRuntime } = global
const app = getApp();
let [command, comunit] = ['', '']
// import CRC from './crc.js';
class Bluetooth {
  constructor(params) {
    this.options = {
      deviceId: '',                 // 设备唯一id
      serviceId: '',                // 主服务id
      notifyCharacteristicsId: '',  // 通知特征值
      writeCharacteristicsId: '',   // 写入特征值
      readCharacteristicsId: '',    // 读取特征值
      macId: '',        // 
      characteristicVal: ''    //监听特征值
    },
      this.search_err = 0
  }
  // 开启蓝牙模块
  openBLE() {
    let that = this
    return new Promise((resolve, reject) => {
      wx.openBluetoothAdapter({
        success: function (res) {
          wx.getBluetoothAdapterState({
            success(res) {
              wx.startBluetoothDevicesDiscovery({
                success: function (res) {
                  resolve(true)
                  console.log('搜索蓝牙设备初始化成功(wx.startBluetoothDevicesDiscovery):');
                },
                fail: function (err) {
                  console.log('搜索蓝牙设备初始化失败(wx.startBluetoothDevicesDiscovery):');
                }
              })
            }
          })
        },
        fail: function (err) {
          resolve(false)
          console.log('初始化蓝牙模块失败(wx.openBluetoothAdapter):');
          if (err.errCode == 10001) {
            wx.showModal({
              title: '提示',
              content: '蓝牙未打开，请打开蓝牙重试!',
              showCancel: false,
              success: function (res) {
                that.star(that.options.macId)
              }
            });
          }
        }
      });
    })
  };

  // 关闭蓝牙模块
  closeBLE() {
    //兼容--判断是否支持用户的手机。
    if (wx.closeBluetoothAdapter) {
      wx.closeBluetoothAdapter({
        success: function (res) {
          console.log('关闭蓝牙模块成功')
        },
        fail: function (res) {
          wx.hideLoading();
          console.log('关闭蓝牙模块失败:');
        }
      });
    } else {
      // 如果希望用户在最新版本的客户端上体验您的小程序，可以这样子提示
      wx.showModal({
        title: '提示',
        content: '当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。',
        showCancel: false,
      })
    }
  };

  // 监听蓝牙状态是否异常
  listenerBLE() {
    wx.onBluetoothAdapterStateChange(function (res) {
      if (!res.available) {
        wx.showModal({
          title: '提示',
          content: '连接过程中，请勿断开蓝牙或远离设备！',
          showCancel: false,
          success: function (res) {
            if (res.confirm) {
              wx.reLaunch({
                url: '../../' + getCurrentPages()[0].route,
              })
            }
          }
        });
      }
    })
  };

  // 开始搜索蓝牙设备
  // searchBLE(){
  //   wx.startBluetoothDevicesDiscovery({
  //     success: function (res) {
  //       console.log('搜索蓝牙设备初始化成功(wx.startBluetoothDevicesDiscovery):');
  //       //app.loading('蓝牙搜索中')
  //     },
  //     fail: function (err) {
  //       console.log('搜索蓝牙设备初始化失败(wx.startBluetoothDevicesDiscovery):');
  //     }
  //   })
  // };


  //  获取蓝牙设备
  getBluetoothDevices() {
    //要加个loading
    let that = this;
    that.search_err++
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        wx.getBluetoothDevices({
          success: function (res) {
            if (res.devices.length != 0) {
              console.log(res.devices)
              console.log(that.options.macId)
              let [search, status] = [0, true]
              try {
                res.devices.forEach(item => {
                  search++
				  let service_data=that.buf2hex(item.advertisData);
				  console.log(item.localName+':'+service_data.substring(8))
                  // console.log(item.localName+':'+that.buf2hex(item.advertisData))
                  //if (that.options.macId == that.buf2hex(item.advertisData)) {
                  if (that.options.macId == service_data.substring(8)) {
                    console.log(item)
                    that.options.deviceId = item.deviceId;
                    that.options.serviceId = item.advertisServiceUUIDs[0];
                    that.stopBluetoothDevices();
                    resolve(true)
                    status = true
                    throw new Error('设备到搜索')
                  } else if (res.devices.length == search) {
                    status = false
                    throw new Error('设备搜索不到')//找到跳出循环
                  }
                })
              } catch (e) {
                console.log(e)
                console.log(status)
                if (!status) {
                  wx.hideLoading()
                  if (that.search_err == 3) {
                    wx.showModal({
                      title: '提示',
                      content: '未发现蓝牙，请重新搜索',
                      success: function (res) {
                        that.search_err = 0;
                        // that.getBluetoothDevices()
                      }
                    })
                    resolve(false)
                  } else {
                    // wx.showModal({
                    //   title: '提示',
                    //   content: '未发现设备,请重新搜索',
                    //   success: function (res) {
                    //   }
                    // })
                    that.getBluetoothDevices()
                  }
                }
              }
            } else {
              wx.hideLoading()
              if (that.search_err == 3) {
                wx.showModal({
                  title: '提示',
                  content: '未发现蓝牙，请重新搜索',
                  success: function (res) {
                    that.search_err = 0;
                    //that.getBluetoothDevices()
                  }
                })
                resolve(false)
              } else {
                // wx.showModal({
                //   title: '提示',
                //   content: '未发现设备,请重新搜索',
                //   success: function (res) {
                //   }
                // })
                that.getBluetoothDevices()
              }
            }
          }
        })
      }, 1000);
    });
  }
  // 停止获取蓝牙设备
  stopBluetoothDevices() {
    wx.stopBluetoothDevicesDiscovery({
      success(res) {
        console.log(res)
      }
    })
  }

  // 连接设备
  createBLEConnection() {
    let deviceId = this.options.deviceId;
    return new Promise((resolve, reject) => {
      wx.createBLEConnection({
        deviceId, success(res) {
          console.log(res)
          if (res.errMsg == 'createBLEConnection:ok') {
            resolve(true)
          } else {
            resolve(false)
          }
        }
      })
    })
  }
  closeBLEConnection() {
    let deviceId = this.options.deviceId;
    wx.closeBLEConnection({
      deviceId,
      success(res) {
        console.log(res)
      }
    })
  }

  //  获取蓝牙设备所有服务
  getBLEDeviceServices(deviceId) {
    let that = this;
    wx.getBLEDeviceServices({
      // 这里的 deviceId 需要已经通过 createBLEConnection 与对应设备建立链接
      deviceId,
      success(res) {
        console.log('device services:', res.services)
        that.getBLEDeviceCharacteristics(deviceId, that.options.serviceId)
      }
    })
  }

  // 获取蓝牙设备某个服务中所有特征值
  getBLEDeviceCharacteristics(deviceId, serviceId) {
    let that = this;
    wx.getBLEDeviceCharacteristics({
      // 这里的 deviceId 需要已经通过 createBLEConnection 与对应设备建立链接
      deviceId,
      // 这里的 serviceId 需要在 getBLEDeviceServices 接口中获取
      serviceId,
      success(res) {
        console.log(res)
        console.log('device getBLEDeviceCharacteristics:', res.characteristics)
        try {
          res.characteristics.forEach(function (item) {
            if (item.properties.notify) {
              that.options.notifyCharacteristicsId = item.uuid
              that.notifyBLECharacteristicValueChange(deviceId, serviceId, item.uuid)
              console.log(item.uuid)
            }
            if (item.properties.write) {
              that.options.writeCharacteristicsId = item.uuid
              throw new Error('跳出循环')//后找到的跳出循环
            }
          })
        } catch (e) {
          console.log(e)
        }
      }
    })
  }

  // 订阅特征值
  notifyBLECharacteristicValueChange(deviceId, serviceId, characteristicId) {
    let that = this;
    wx.notifyBLECharacteristicValueChange({
      state: true, // 启用 notify 功能
      // 这里的 deviceId 需要已经通过 createBLEConnection 与对应设备建立链接
      deviceId,
      // 这里的 serviceId 需要在 getBLEDeviceServices 接口中获取
      serviceId,
      // 这里的 characteristicId 需要在 getBLEDeviceCharacteristics 接口中获取
      characteristicId: characteristicId,
      success(res) {
        console.log('notifyBLECharacteristicValueChange success', res.errMsg)
        that.onBLECharacteristicValueChange()
      }
    })
  }

  // 监听特征值回调
  onBLECharacteristicValueChange(num) {
    let [that, number] = [this, ''];
    return new Promise((resolve, reject) => {
      wx.onBLECharacteristicValueChange(function (res) {
        //console.log(`characteristic ${res.characteristicId} has changed, now is ${res.value}`)
        console.log(that.buf2hex(res.value))
        that.options.characteristicVal = that.buf2hex(res.value)
        if (num) {
          num++
          number = that.buf2hex(res.value).substring(4, 6)
          if (number == '85') {
            that.closeBLEConnection()
            resolve(true)
          } else {
            if (num > 7) {
              resolve(false)
            }
          }
        }
      })
    })
  }

  // 写入
  writeBLECharacteristicValue(instruct, deviceId, serviceId, writeCharacteristicsId) {
    console.log(deviceId, serviceId, writeCharacteristicsId)
    // let data = '55ffceaa01010000000' + instruct + CRC.crc16('55ffceaa01010000000' + instruct)
	let data=instruct;
    console.log(data)
    let that = this;
    let buffer = new ArrayBuffer(data.length);
    let dataView = new DataView(buffer);
    for (var i = 0; i < data.length / 2; i++) {
      dataView.setUint8(i, '0x' + data.substr(i * 2, 2));
    }
    return new Promise((resolve, reject) => {
      wx.writeBLECharacteristicValue({//
        deviceId,
        serviceId,
        characteristicId: writeCharacteristicsId,
        value: buffer,
        success(res) {
          console.log('writeBLECharacteristicValue success', res.errMsg)
          resolve(true)
          //that.onBLECharacteristicValueChange()
        },
        fail(res) {
          console.log('fail', res.errMsg)
          resolve(false)
        }
      })
    })
  }

  //异或检验
  hexxor(command) {
    for (let i = 0; i < command.length / 2; i++) {
      let cunit = parseInt(command.substr(i * 2, 2), 16)
      if (comunit != '') {
        comunit = parseInt(comunit ^ cunit)
      } else {
        comunit = parseInt(command.substr(i * 2, 2), 16)
      }
    }
    command = (command + comunit.toString(16)).toUpperCase()
    comunit = ''
    return command
  }

  cutting3(str) { //低字节转换
    let arr = [],
      i = 0;
    for (let ss = 0; ss < str.length; ss += 2) {
      arr[arr.length] = str.substr(i, 2);
      i += 2;
    }
    return arr.reverse().join('');
  }


  buf2hex(buffer) {
    return Array.prototype.map.call(new Uint8Array(buffer), x => ('00' + x.toString(16)).slice(-2)).join('');
  };

  async star(macId) {
    app.loading('蓝牙搜索中')
    let that = this;
    this.options.macId = macId
    await this.closeBLE()
    let open = await this.openBLE()
    if (open) {
      let getDevices = await this.getBluetoothDevices()
      console.log(getDevices)
      return await new Promise((resolve, reject) => {
        if (getDevices) {
          that.createBLEConnection().then(res => {
            wx.hideLoading()
            resolve(res)
          })
        } else {
          resolve(getDevices)
        }
      })
    }

  }
  notify() {
    let that = this;
    this.getBLEDeviceServices(this.options.deviceId)
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // console.log(that.options.characteristicVal)
        // if (that.options.characteristicVal) {
        //   resolve(that.options.characteristicVal)
        // } else {
        //   resolve(false)
        // }
		resolve(true)
      }, 2000)
    })
  }
  // async notify() {
  //   await this.getBLEDeviceCharacteristics(this.options.deviceId, this.options.serviceId)
  // }

  async write(instruct) {
    let that = this;
    let write = await this.writeBLECharacteristicValue(instruct, this.options.deviceId, this.options.serviceId, this.options.writeCharacteristicsId)
    return new Promise((resolve, reject) => {
      if (write) {
        let num = 1
        that.onBLECharacteristicValueChange(num).then(res => {
          resolve(res)
        })
      } else {
        resolve(false)
      }

    })
  }

}

export default new Bluetooth()