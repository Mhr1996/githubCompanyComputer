<button class="verBtn" :class="{active:!sendStatus}" @click="sendVer">
	{{sendStatus? `获取验证码` : `${verSecond}秒后重新获取`}}
</button>
data(){
	return{
		verText:"获取验证码33",
		sendStatus:true,
		verSecond:60
	}
},
methods:{
	sendVer(){
		if (this.sendStatus) {
			this.sendStatus=false;
			
			let startT=setInterval(()=>{
				if (this.verSecond!=0) {
					this.verSecond--;
					return;
				}
				this.sendStatus=true;
				clearInterval(startT); 
			},1000);
		}
	}
}