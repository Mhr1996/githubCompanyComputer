<!--
 * @Description: 
 * @Author: 曹小心
 * @Date: 2019-06-03 15:32:58
 * @LastEditTime: 2019-06-08 14:31:35
 -->
<template>
  <div class="cont container">
    <div class="scroll">
      <div class="equipment_box">
        <div class="equipment">
          <div class="equipment_cont">
            <p>设备名称：{{detail.device_name}} <span class="err" v-if="detail.stock_status==2">缺货</span></p>
            <p>
              <i>设备编号：</i>{{detail.macno}}
            </p>
            <p>
              <i>设备地址：</i>{{detail.address}}
            </p>
          </div>
          <div class="triangle" :style="{'border-top-color':detail.line_status_name=='在线'?'':'#ccc'}">
            <span>{{detail.line_status_name}}</span>
          </div>
        </div>
      </div>
      <div class="cont_list" style="line-height: 20px;">
        <van-checkbox-group v-model="result">
          <label for class="li" v-for="(item,index) in detail.goods" :key="index" style="position: relative;">
            <img :src="item.img" alt>
            <div class="checkbox">
              <van-checkbox shape="square" :name="item"
                            :disabled="isOpen == 1 && (openNumber.indexOf(item.number)<0 || item.type!=1)"></van-checkbox>
              <div class="ellipsis">
                <p class="ellipsis">{{item.title?item.title:'暂无名称'}}</p>
                <dd class="pay ellipsis">￥{{item.price}}</dd>
              </div>
            </div>
            <img :src="require('@/assets/img/empty.png')" class="emptyIco" v-show="item.type!=2">
          </label>
        </van-checkbox-group>
      </div>
    </div>
    <Btn @tapFn="complete" v-show="isOpen==1">完成补货</Btn>
    <Btn @tapFn="sure" v-show="isOpen==0">{{sureText}}</Btn>
  </div>
</template>

<script type="text/ecmascript-6">
  import Btn from "base/btn/btn";
  import Equipment from "base/equipment/equipment";
  import {Dialog} from "vant";
  import {api, apiMall} from "api/http.js";

  export default {
    components: {Btn, Equipment},
    data() {
      return {
        result: [],
        sureText: "开柜",
        isShow: true,
        detail: {},
        isOpen: 0,
        openNumber: []
      };
    },
    created() {
      this.deviceGoods();
      this.initWebSocket();
    },
    methods: {
      sure() {
        console.log(this.result);
        this.$dialog.confirm({
          title: '提示',
          message: this.result.length > 0 ? '是否打开柜子？' : '是否打开所有柜子',
          overlay: true,
          lockScroll: true,
        }).then(() => {
          let ids = [];
          let number = [];
          this.result.map(item => {
            ids.push(item.id);
            number.push(item.number);
          });
          let data = {
            api_name: 'buhuoDoor',
            token: this.dlc.gain('_token'),
            shop_token: this.dlc.gain("shop_token"),
            device_id: this.$route.query.device_id
          };
          if (ids.length > 0) {
            data.ids = ids.join(',');
            this.openNumber = number;
            data.number = number.join(',');
          }else{
            let openNumber = [];
            this.detail.goods.map(item=>{
              openNumber.push(item.number);
            });
            this.openNumber = openNumber;
          }
          api.post(apiMall + "/wxsite/shop/api", data).then((res) => {
            console.log(res);
            if (res.code == 1) {
              let order = 'connectinfo_szhzgzg_' + this.dlc.gain('shop_id');
              console.log(order);
              this.$toast.loading({
                duration: 0,
                forbidClick: true,
                loadingType: 'spinner',
                message: '正在开柜...'
              });
              this.websocketsend(order);
            }
          });
        });
      },
      complete() {//完成补货
        if(this.result.length>0){
          let ids = [];
          this.result.map(item => {
            ids.push(item.id);
          });
          console.log(ids);
          let data = {
            api_name: 'complete',
            token: this.dlc.gain('_token'),
            shop_token: this.dlc.gain("shop_token"),
            device_id: this.$route.query.device_id,
            network_id:this.detail.network_id,
            ids:ids.join(',')
          };
          console.log(data);
          api.post(apiMall + "/wxsite/shop/api", data).then((res) => {
            console.log(res);
            this.$dialog.alert({
              title: '提示',
              message: res.msg,
            }).then(()=>{
              this.$router.go(-1);
            });
          });
        }else{
          this.$dialog.confirm({
            title: '提示',
            message: '请选择补货商品',
            overlay: true,
            lockScroll: true,
            confirmButtonText:'继续补货',
            cancelButtonText:'返回'
          }).then(() => {}).catch(()=>{
            this.$router.go(-1);
          });
        }
      },
      async deviceGoods() {
        let res = await api.post(apiMall + "/wxsite/shop/api", {
          api_name: "deviceGoods",
          token: this.dlc.gain('_token'),
          shop_token: this.dlc.gain("shop_token"),
          device_id: this.$route.query.device_id,
          page: 1,
          size: 999
        });
        console.log(res);
        if (res.code == 1) {
          this.detail = res.data;
        } else {
          this.$toast(res.msg);
        }
      },
      initWebSocket() {
        const skUrl = this.dlc.socketHost;
        this.websockTimer = null;
        this.websock = new WebSocket(skUrl);
        this.websock.onmessage = this.websocketonmessage;
        this.websock.onopen = this.websocketonopen;
        this.websock.onerror = this.websocketonerror;
        this.websock.onclose = this.websocketclose;
      },
      websocketonopen() {
        let that = this;
        this.websockTimer = setInterval(() => {
          that.websocketsend('connectinfo_szhzgzg_0');
        }, 15000);
        console.log('socket连接成功');
      },
      websocketonerror() {
        this.initWebSocket();
      },
      websocketonmessage(data) {
        console.log('socket返回');
        this.$toast.clear();
        let res = JSON.parse(data.data);
        if (res.code == 1) {
          this.$dialog.alert({
            title: '提示',
            message: '箱子已经打开',
          }).then(() => {
            this.result = [];
            this.isOpen = 1;
          });
        }
      },
      websocketsend(data) {//数据发送
        console.log('数据发送');
        this.websock.send(data);
      },
      websocketclose() {
        console.log('断开连接');
      }
    },
    beforeRouteLeave(to, from, next) {
      if (this.websock) {
        this.websocketclose();
        clearInterval(this.websockTimer);
      }
      next();
    },
    computed: {},
    mounted() {
    }
  };
</script>

<style scoped lang="scss">
  @import "assets/sass/equipment.scss";
  @import "assets/sass/shopList.scss";

  .container .btn {
    position: fixed;
    bottom: 0px;
    left: 50%;
    transform: translateX(-50%);
  }

  .scroll {
    margin-bottom: 140px;
  }

  .cont .cont_list img.emptyIco {
    position: absolute;
    left: 0;
    top: 0;
    width: 55px;
    height: 55px;
    background-color: transparent;
    box-shadow: none;
  }
</style>
