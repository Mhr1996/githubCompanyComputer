const app = getApp()
Page({
    data: {
        lispic: [],
        lispic_path: [],
        description: '',
        textLength: 0,
        checked_question: '',
        on_off: 0
    },

    onLoad: function(e) {
        let self = this
        self.setData({
            order_id: e.record_id || '',
            shop_name: e.shop_name || '',
            use_time: e.use_time || ''
        })
    },

    onShow: function() {
        let self = this
        app.wxRequest(
            '', {
                HTTP_API: 'vv/feedback/api/index/feedbackQuestions',
                token: wx.getStorageSync('token')
            },
            function(res) {
                console.log('常见问题', res)
                if (res.data.code == 1) {
                    self.setData({
                        questions: res.data.data.normal_question,
                        oid_must: res.data.data.oid_must
                    })
                } else {
                    app.tools.error_tip(res.data.msg)
                }
            }
        )
    },

    checkText: function(e) {
        let self = this
        self.setData({
            description: e.detail.value,
            textLength: e.detail.value.length
        })
        if (e.detail.value.length > 140) {
            return false
        }
    },

    checkboxChange: function(e) {
        let self = this
        self.setData({
            checked_question: e.detail.value.join(',')
        })
    },

    removeOrder: function() {
        let self = this
        self.setData({
            order_id: ''
        })
    },

    deletePic: function(e) { //删除图片
        let self = this
        let lispic = this.data.lispic
        let lispic_path = this.data.lispic_path
        lispic.splice(e.currentTarget.dataset.index, 1)
        lispic_path.splice(e.currentTarget.dataset.index, 1)
        self.setData({
            lispic: lispic,
            lispic_path: lispic_path
        })
    },

    uploadPic: function(e) { //上传图片
        let self = this
        app.uploadFile(1, function(flag, idx, msg, data) {
            if (flag == 1) {
                console.log(msg)
                let res = msg.tempFilePaths
                if (self.data.lispic.length < 5) {
                    self.setData({
                        lispic: self.data.lispic.concat(res)
                    })
                } else {
                    wx.showModal({
                        title: '提示',
                        confirmColor: '#e9c426',
                        content: '最多只能上传5张图片...',
                        showCancel: false
                    })
                    wx.setStorageSync('allowPicNum', 0)
                    return false
                }
            } else if (flag == 2) {
                console.log(msg)
                if (self.data.lispic_path.length < 5) {
                    self.data.lispic_path.push(msg.url)
                }
                console.log(self.data.lispic_path)
            }
        }, {}, '', 5 - self.data.lispic_path.length)
    },

    formSubmit: function(e) {
        let self = this
        let pictures = self.data.lispic_path.join(',')
        console.log(pictures)

        if (self.data.oid_must == 1 && self.data.order_id == '') {
            wx.showModal({
                title: '提示',
                confirmColor: '#e9c426',
                content: '请选择你的一条订单进行故障申报',
                showCancel: false
            })
            return false
        } else if (self.data.checked_question == '' && self.data.description == '') {
            wx.showModal({
                title: '提示',
                confirmColor: '#e9c426',
                content: '请选择或者描述你的问题',
                showCancel: false
            })
            return false
        }

        if (self.data.on_off) return false
        self.setData({
            on_off: 1
        })

        wx.showLoading({
            title: '提交中...'
        })
        app.wxRequest(
            '', {
                HTTP_API: 'vv/feedback/api/index/submitFeedback',
                token: wx.getStorageSync('token'),
                oid: self.data.order_id,
                content: self.data.description,
                question: self.data.checked_question,
                pic: pictures
            },
            function(res) {
                console.log(res)
                wx.hideLoading()
                if (res.data.code == 1) {
                    wx.showModal({
                        title: '提示',
                        confirmColor: '#e9c426',
                        content: '故障申报成功',
                        showCancel: false,
                        success: function() {
                            wx.navigateBack()
                        }
                    })
                } else {
                    self.setData({
                        on_off: 0
                    })
                    app.tools.error_tip(res.data.msg)
                }
            })
    },

    goOrderList: function() {
        let self = this
        wx.redirectTo({
            url: '/pages/record_list/index?is_report=1'
        })
    }
})