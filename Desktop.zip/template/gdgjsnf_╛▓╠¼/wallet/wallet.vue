<template>
	<div class="wallet plr_20 bz pt15">
		<div class="info co2 bz">
			<p class="mt10">可提现金额（元）</p>
			<p class="price">￥1000.00</p>
			<div class="btn mt10">提现</div>
			<div class="csb mt15" style="color: #764800"><div>已提现金额：￥500.00</div><div>总收益：￥1500.00</div></div>
		</div>
		<div class="csb center mt15">
			<div><img src="@/assets/imgs/ic01.png" alt=""><p>提现记录</p></div>
			<div><img src="@/assets/imgs/ic02.png" alt=""><p>提现记录</p></div>
		</div>
	</div>
</template>

<script>
	export default{
		name:"wallet",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.wallet{
		min-height: 100vh;
		/*background-color: #f5f5f5;*/
	}
	.info{
		background: url('~@/assets/imgs/ic03.png') no-repeat;
		background-size: 100% 100%;
		height: 3rem;
		padding: .3rem ;
		.price{
			font-size: .48rem;
			margin-top: .2rem;
		}
		.btn{
			width: 1.4rem;
			height: .5rem;
			line-height: .5rem;
			text-align: center;
			border-radius: .3rem;
			border:1px solid #f6a820;
		}
	}
	.center{
		div{
			width: 3rem;
			height: 3rem;
			display: flex;
			justify-content: space-around;
			flex-direction: column;
			padding: .3rem 0;
			box-sizing: border-box;
			@include box-shadow-abroad(0 0.04rem 0.1rem 0.02rem #eaeaea);
		}
		img{
			width: 1.2rem;
			height: 1.2rem;
			display: inline-table;
			margin: 0 auto;
		}
	}
</style>