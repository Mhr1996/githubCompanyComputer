<template>
	<div class="myBonus">
		<div class="csb center">
			<div v-for="(g,index) of title" class="w50 tabText lh50" :class="{'active':g.active}" :key="index" @click="tabT(index)">{{g.name}}</div>
		</div>
		<div v-show="title[0].active" class="cgf2 mlr_15 mt40 relative pb20" style="margin-top: 1.4rem;">
			<div class="priceShow">
				<div class="cgf br50 co2 bonusPrice">
					<p class="bold mb10">75000</p>
					<p class="center">推广金</p>
				</div>
			</div>
			<img src="@/assets/imgs/i2_03.png" alt="推广奖金列表" class="w100" style="margin-top: 1.5rem;">
			<div class="mt15">
				<div class="flex wrap center fz16 bold">
					<div class="w33">商家名</div>
					<div class="w33">添加时间</div>
					<div class="w33">奖励金额</div>
				</div>
				<div class="flex wrap mt10 center">
					<div class="w33">南城桑拿房</div>
					<div class="w33">2019-10-21</div>
					<div class="w33">1500元</div>
				</div>
			</div>
		</div>
		<div v-show="title[1].active" class="cgf2 mlr_15 mt40 relative pb20" style="margin-top: 1.4rem;">
			<div class="priceShow">
				<div class="cgf br50 co2 bonusPrice">
					<p class="bold mb10">75000</p>
					<p class="center">推广金</p>
				</div>
			</div>
			<img src="@/assets/imgs/i2_04.png" alt="奖金达成情况" class="w100" style="margin-top: 1.5rem;">
			<div class="mt15">
				<div class="flex wrap center fz16 bold">
					<div class="w33">商家名</div>
					<div class="w33">添加时间</div>
					<div class="w33">奖励金额</div>
				</div>
				<div class="flex wrap mt10 center">
					<div class="w33">南城桑拿房</div>
					<div class="w33">2019-10-21</div>
					<div class="w33">1500元</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default{
		name:"myBonus",
		components:{
		},
		data(){
			return {
				title:[
					{
						name:'推广奖金',
						active:true,
					},
					{
						name:'任务达成奖金',
						active:false,
					}
				]
			}
		},
		created(){

		},
		methods:{
			tabT(i){
				this.title.forEach((item,index)=>{
					item.active=false;
				})
				this.title[i].active=true;
			}
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.myBonus{
		min-height: 100vh;
		/*background-color: #f5f5f5;*/
		background: -webkit-linear-gradient(top,#f7cd4e,#f6aa22); /* Safari 5.1-6.0 */
	    background: -o-linear-gradient(top,#f7cd4e,#f6aa22); /* Opera 11.1-12.0 */ 
	    background: -moz-linear-gradient(top,#f7cd4e,#f6aa22); /* Firefox 3.6-15 */
	    background: linear-gradient(top,#f7cd4e,#f6aa22); /* 标准语法 */
	}

	.tabText{
		color: #ba890b;
		font-size: .32rem;
	}
	.tabText.active{
		color: #764800;
		font-weight: bold;
		font-size: .32rem;
	}
	.cgf2{
		background-color: #fcf9f1;
		@include br(.3rem);
	}
	.priceShow{
		width:3rem;
		height: 3rem;
		@include br(50%);
		background: url('~@/assets/imgs/i1_03.png') center;
		position: absolute;
		z-index: 10;
		left: 50%;
		top: -1.5rem;
		margin-left: -1.5rem;
		background-size: 100%;
	}
	.bonusPrice{
	    width: 2.2rem;
	    height: 2.2rem;
	    position: absolute;
	    left: .45rem;
	    top: .35rem;
	}
	.bold.mb10{
		font-size: 0.6rem; padding-top: .6rem; text-align: center;
	}
</style>