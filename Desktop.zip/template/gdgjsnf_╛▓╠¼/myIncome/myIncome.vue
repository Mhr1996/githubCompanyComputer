<template>
	<div class="myIncome oh bz pt10 plr_15">
		<div class="item-1 mb10">
			订单收益
		</div>
		<div class="item-1 mb10">
			商城收益
		</div>
		<div class="item-1 mb10">
			套餐收益
		</div>
	</div>
</template>

<script>
	export default{
		name:"myIncome",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.myIncome{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
</style>