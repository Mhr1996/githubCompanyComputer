<template>
	<div class="deviceList">
		<van-search
		    v-model="value"
		    placeholder="请输入搜索订单编号或商家名"
		    show-action
		    shape="round"
		    background="#f5f5f5"
		    @search="onSearch"
		    @cancel="onCancel"
		  />
		<div class="plr_15 mlr_15 mb15 cgf">
			<div class="ptb_15 c9 bbef csb">
				<span>设备编号:12313123</span> <span class="online co2">在线</span>
			</div>
			<div class="pt15">
				<div class="pb10"><span class="mr5">所属商家：</span>南城桑拿房</div>
				<div class="pb10"><span class="mr5">商家地址：</span>南城步行街附近</div>
				<div class="pb10"><span class="mr5">设备营业额：</span>20元</div>
				<div class="pb10"><span class="mr5">设备收益：</span>20元</div>
				<div class="pb10"><span class="mr5">添加时间：</span>2019.10.21 15:02</div>
			</div>
		</div>
		<div class="plr_15 mlr_15 mb15 cgf">
			<div class="ptb_15 c9 bbef csb">
				<span>设备编号:12313123</span> <span class="online c9">离线</span>
			</div>
			<div class="pt15">
				<div class="pb10"><span class="mr5">所属商家：</span>南城桑拿房</div>
				<div class="pb10"><span class="mr5">商家地址：</span>南城步行街附近</div>
				<div class="pb10"><span class="mr5">设备营业额：</span>20元</div>
				<div class="pb10"><span class="mr5">设备收益：</span>20元</div>
				<div class="pb10"><span class="mr5">添加时间：</span>2019.10.21 15:02</div>
			</div>
		</div>
		<div class="plr_15 mlr_15 mb15 cgf">
			<div class="ptb_15 c9 bbef csb">
				<span>设备编号:12313123</span> <span class="online co2">在线</span>
			</div>
			<div class="pt15">
				<div class="pb10"><span class="mr5">所属商家：</span>南城桑拿房</div>
				<div class="pb10"><span class="mr5">商家地址：</span>南城步行街附近</div>
				<div class="pb10"><span class="mr5">设备营业额：</span>20元</div>
				<div class="pb10"><span class="mr5">设备收益：</span>20元</div>
				<div class="pb10"><span class="mr5">添加时间：</span>2019.10.21 15:02</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default{
		name:"deviceList",
		components:{
		},
		data(){
			return {
				value:''
			}
		},
		created(){

		},
		methods:{
			onSearch(){
				console.log('onSearch')
			},
			onCancel(){
				console.log('onCancel')
			}
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.deviceList{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.van-search__content{
		background-color:#fff;
	}
</style>