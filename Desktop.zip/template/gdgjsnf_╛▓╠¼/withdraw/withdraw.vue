<template>
	<div class="withdraw bz plr_15 pt10 oh">
		<div class="item-1 mb10 csb">
			<div class="mr10">提现金额</div> 
			<input type="text" placeholder="请输入" class="flex1 tr">
		</div>
		<div class="item-1 mb10 csb">
			<div class="mr10">提现人</div> 
			<input type="text" placeholder="请输入" class="flex1 tr">
		</div>
		<div class="item-1 mb10 csb">
			<div class="mr10">开户银行</div> 
			<input type="text" placeholder="请输入" class="flex1 tr">
		</div>
		<div class="item-1 mb10 csb">
			<div class="mr10">所属支行</div> 
			<input type="text" placeholder="请输入" class="flex1 tr">
		</div>
		<div class="item-1 mb10 csb">
			<div class="mr10">银行卡号</div> 
			<input type="text" placeholder="请输入" class="flex1 tr">
		</div>
		<div class="item-1 mb10 csb">
			<div class="mr10">联系电话</div> 
			<input type="text" placeholder="请输入" class="flex1 tr">
		</div>
		<div class="submitBtn2">申请提现</div>
	</div>
</template>

<script>
	export default{
		name:"withdraw",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.withdraw{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
</style>