<template>
	<div class="promoCode oh bz plr_20 pt20">
		<div class="cca ac cgf br bz p20">
			<img src="@/assets/imgs/title.png" alt="" style="width: 3.5rem;">
			<p class="center bold mt20">扫码成为商家</p>
		</div>
	</div>
</template>

<script>
	export default{
		name:"promoCode",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.promoCode{
		min-height: 100vh;
		background-color: #f6a820;
	}
</style>