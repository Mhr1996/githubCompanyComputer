<template>
	<div class="merchantList">
		<van-search
		    v-model="value"
		    placeholder="请输入搜索订单编号或商家名"
		    show-action
		    shape="round"
		    background="#f5f5f5"
		    @search="onSearch"
		    @cancel="onCancel"
		  />
		<div class="plr_15 mlr_15 mb15 cgf">
			<div class="pt15">
				<div class="pb10"><span class="mr5">商家名：</span>南城桑拿房</div>
				<div class="pb10"><span class="mr5">联系电话：</span>131111111111</div>
				<div class="pb10"><span class="mr5">商家设备数：</span>5</div>
				<div class="pb10"><span class="mr5">添加时间：</span>2019-10-21 15:02:37</div>
			</div>
			<div class="bbef pb10 mb10 fz12 c9">
				<img src="@/assets/imgs/ic04.png" alt="" style="width:.2rem;" class="mr5">东莞市南城区高盛科技园101
			</div>
			<div class="csa pb10 center">
				<div class="cca2">
					<p class="co2 fz18 pb5">1000元</p>
					<p class="fz12">营业额</p>
				</div>
				<div class="cca2">
					<p class="co2 fz18 pb5">1000元</p>
					<p class="fz12">我的分润</p>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default{
		name:"merchantList",
		components:{
		},
		data(){
			return {
				value:''
			}
		},
		created(){

		},
		methods:{
			onSearch(){
				console.log('onSearch')
			},
			onCancel(){
				console.log('onCancel')
			}
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.merchantList{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.van-search__content{
		background-color:#fff;
	}
</style>