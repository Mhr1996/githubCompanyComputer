<template>
	<div class="mySpace">
		<div class="csb bg_y ptb_30">
			<div class="cca2 w50 center">
				<div class="fz30">100</div>
				<div class="ptb_10">今日收益（元）</div>
			</div>
			<div class="cca2 w50 center">
				<div class="fz30">100</div>
				<div class="ptb_10">今日收益（元）</div>
			</div>
		</div>
		<div class="head_info cf">
			<div class="mauto csb" style="width: 80%;">
				<div class="cca2 w50 center">
					<div class="fz18">30</div>
					<div class="pt5">商家数量（个）</div>
				</div>
				<div class="cca2 w50 center">
					<div class="fz18">30</div>
					<div class="pt5">设备数量（台）</div>
				</div>
			</div>
		</div>
		<div class="list">
			<ul>
				<router-link tag="li" to="mySpace" class="order border-bottom">
					<div class="icon"></div>我的收益
				</router-link>
				<router-link tag="li" to="mySpace" class="aide border-bottom">
					<div class="icon"></div>我的奖金
				</router-link>
				<router-link tag="li" to="mySpace" class="bphone border-bottom">
					<div class="icon"></div>我的钱包 <!-- <span class="r">{{oD.mobile}}</span> -->
				</router-link>
				<router-link tag="li" to="mySpace" class="Repair border-bottom">
					<div class="icon"></div>商家列表
				</router-link>
				<a class="link border-bottom" href="tel:13764567708">
					<div class="icon"></div>设备列表 <span class="r"></span>
				</a>
				<router-link tag="li" to="mySpace" class="about border-bottom">
					<div class="icon"></div>我的推广码
				</router-link>
				<router-link tag="li" to="mySpace" class="xgmm border-bottom">
					<div class="icon"></div>修改密码
				</router-link>
			</ul>
		</div>
		<div class="submitBtn2">退出登录</div>
	</div>
</template>

<script>
	export default{
		name:"mySpace",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.mySpace{
		min-height: 100vh;
		/*background-color: #f5f5f5;*/
	}
	.list{
		margin-top: .5rem;
		padding-left: .5rem;
		ul{
			    padding-left: .72rem;
			li,a{
				display:block;
				color: #333;
				height: 1.2rem;
				line-height: 1.35rem;
				margin-right: .2rem;
				background:url('~@/assets/imgs/right.png') no-repeat;
				background-position: 97%;
    			background-size: .15rem;
    			padding-right: .6rem;
    			box-sizing: border-box;
    			.r{
    				color: $g9;
    			}
			}
			a.link{
				background:none;
			}
		}
	}
	.order, .bphone, .Repair, .link, .about, .aide, .xgmm{
		.icon{
			background:url('~@/assets/imgs/icon.png') no-repeat 100%;
			width: .4rem;
		    height: 0.42rem;
		    background-size: .36rem;
		    vertical-align: middle;
		    display: inline-table;
		    margin-right: .2rem;
		    margin-left: -.7rem;
		        margin-top: -.1rem;
		}
	}
	
	.order{.icon{background-position-y: .07rem; } }
	.aide{.icon{background-position-y:  -.86rem; } }
	.bphone{.icon{background-position-y:  -1.88rem; } }
	.Repair{.icon{background-position-y:  -2.84rem; } }
	.link{.icon{background-position-y: -3.8rem; } }
	.about{.icon{background-position-y: -4.8rem; } }
	.xgmm{.icon{background-position-y: -5.8rem; } }

	.bg_y{
		background: -webkit-linear-gradient(left,#f6a820,#f7d051); /* Safari 5.1-6.0 */
	    background: -o-linear-gradient(left,#f6a820,#f7d051); /* Opera 11.1-12.0 */ 
	    background: -moz-linear-gradient(left,#f6a820,#f7d051); /* Firefox 3.6-15 */
	    background: linear-gradient(left,#f6a820,#f7d051); /* 标准语法 */
	    color: #764800;
	}

	.head_info{
		background: url('~@/assets/imgs/bg.jpg') no-repeat 100%;
		background-size: 100% 100%;
		width: 100%;
		height: 1.1rem;
	}
</style>