<template>
	<div class="incomeDetails bz oh pt10">
		<div class="cgf plr_12 mlr_15">
			<div class="bbef totems ptb_12 csb" style="height: 1rem;">
				<div class="cca2 h100">
					<span class="">推广收益</span>
					<span class="c9 fz12">2019.10.22 14:09</span>
				</div>
				<span class="cca fz18 bold">-￥100</span>
			</div>
		</div>
		<div class="cgf plr_12 mlr_15">
			<div class="bbef totems ptb_12 csb" style="height: 1rem;">
				<div class="cca2 h100">
					<span class="mb10">推广收益</span>
					<span class="c9 fz12">2019.10.22 14:09</span>
				</div>
				<span class="cca fz18 bold">-￥100</span>
			</div>
		</div>
		<div class="cgf plr_12 mlr_15">
			<div class="bbef totems ptb_12 csb" style="height: 1rem;">
				<div class="cca2 h100">
					<span class="mb10">推广收益</span>
					<span class="c9 fz12">2019.10.22 14:09</span>
				</div>
				<span class="cca fz18 bold">-￥100</span>
			</div>
		</div>
		<div class="cgf plr_12 mlr_15">
			<div class="bbef totems ptb_12 csb" style="height: 1rem;">
				<div class="cca2 h100">
					<span class="mb10">推广收益</span>
					<span class="c9 fz12">2019.10.22 14:09</span>
				</div>
				<span class="cca fz18 bold">-￥100</span>
			</div>
		</div>
	</div>
</template>

<script>
	export default{
		name:"incomeDetails",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.incomeDetails{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.cca{
		color:#ef4a4a;
	}
</style>