<template>
	<div class="packageIncome">
		<van-search
		    v-model="value"
		    placeholder="请输入搜索订单编号或商家名"
		    show-action
		    shape="round"
		    background="#f5f5f5"
		    @search="onSearch"
		    @cancel="onCancel"
		  />
		<div class="plr_15 mlr_15 mb15 cgf">
			<div class="ptb_15 c9 bbef">
				订单编号:12313123
			</div>
			<div class="pt15">
				<div class="pb10"><span class="mr5">商家名称：</span>南城桑拿房体验馆</div>
				<div class="pb10"><span class="mr5">套餐名：</span>南城桑拿房30次套餐</div>
				<div class="pb10"><span class="mr5">套餐价格：</span>￥20</div>
				<div class="pb10"><span class="mr5">收益分润：</span>￥20</div>
				<div class="pb10"><span class="mr5">购买时间：</span>2019-10-21 15:02:37</div>
			</div>
		</div>
		<div class="plr_15 mlr_15 mb15 cgf">
			<div class="ptb_15 c9 bbef">
				订单编号:12313123
			</div>
			<div class="pt15">
				<div class="pb10"><span class="mr5">商家名称：</span>南城桑拿房体验馆</div>
				<div class="pb10"><span class="mr5">套餐名：</span>南城桑拿房30次套餐</div>
				<div class="pb10"><span class="mr5">套餐价格：</span>￥20</div>
				<div class="pb10"><span class="mr5">收益分润：</span>￥20</div>
				<div class="pb10"><span class="mr5">购买时间：</span>2019-10-21 15:02:37</div>
			</div>
		</div>
		<div class="plr_15 mlr_15 mb15 cgf">
			<div class="ptb_15 c9 bbef">
				订单编号:12313123
			</div>
			<div class="pt15">
				<div class="pb10"><span class="mr5">商家名称：</span>南城桑拿房体验馆</div>
				<div class="pb10"><span class="mr5">套餐名：</span>南城桑拿房30次套餐</div>
				<div class="pb10"><span class="mr5">套餐价格：</span>￥20</div>
				<div class="pb10"><span class="mr5">收益分润：</span>￥20</div>
				<div class="pb10"><span class="mr5">购买时间：</span>2019-10-21 15:02:37</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default{
		name:"packageIncome",
		components:{
		},
		data(){
			return {
				value:''
			}
		},
		created(){

		},
		methods:{
			onSearch(){
				console.log('onSearch')
			},
			onCancel(){
				console.log('onCancel')
			}
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.packageIncome{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.van-search__content{
		background-color:#fff;
	}
</style>