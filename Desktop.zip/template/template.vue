<template>
	<div class="drug">
		<batten-handle></batten-handle>
 		<root-handle></root-handle>
	</div>
</template>

<script>
import BattenHandle from '@/components/batten'
import RootHandle from '@/components/root'
	export default{
		name:"drug",
	  	components:{
	  		BattenHandle,
	  		RootHandle
	  	}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
</style>