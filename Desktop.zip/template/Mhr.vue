<template>
	<div class="faultRepair" v-for="(item,index) of dataList" :key="index">
		for(var i=0;i<50;i++){  $('tbody tr').eq(i).find('td').eq(10).find('input').val(15);$('tbody tr').eq(i).find('td').eq(11).find('input').val(4);}

		
		@所有人  大家从现在起做项目都要在桌面放个文件夹最好叫“项目资料”。里面备注这个公众号或者小程序的“名称”还有“菜单地址”迁移之后的“域名”，还有你电脑的对应的”文件路径“。这样以后你们请假才能安心走好请大家花多少少时间去做下这个事情，方便你我他

		console.log('%c' + agb.splicingNo.substr(14, 2), 'color:red;');
		#马宏瑞
		mahongrui = mahongrui@mhr
		svn账号密码

		svn://120.76.46.167/h5game/java       鉴于我们公司那些java每次都不发svn，以后对接java项目如果没有svn可以放在这里。

		@所有人
		加薪的标准吧，转正后每半年可以提薪一次。
		1.在团队里面的付出（包括帮同事解决难题，分享技术，分享代码）
		2.负责的项目质量和效率
		3.上班的时长（指的是矿工、早退、请假综合来算）
		代码仓库：
		svn://120.76.46.167/h5game/java

		http://yapi.app.xiaozhuschool.com
		所有权限账号 家麒：308493169@qq.com  123456

		//赠药
		http://localhost:8088/#/agreement?keyword=give
		//24h咨询协议
		http://localhost:8088/#/agreement?keyword=consult

		https://www.rongcloud.cn/docs/android.html#base_function_private
		单聊

		小程序
		1 小程序注册完成后，加载页面，触发onLoad方法。
 
		2 页面载入后触发onShow方法，显示页面。
 
		3 首次显示页面，会触发onReady方法，渲染页面元素和样式，一个页面只会调用一次。
 
		4 当小程序后台运行或跳转到其他页面时，触发onHide方法。
 
		5 当小程序有后台进入到前台运行或重新进入页面时，触发onShow方法。
 
		6 当使用重定向方法wx.redirectTo(OBJECT)或关闭当前页返回上一页wx.navigateBack()，触发onUnload

		1.//数组
		splice(index,1)
		
		this.xxxxx.forEach((item, index) => {
			if(typeof item.checked == 'undefined') {
				this.$set(item, 'checked', false);
			}
			if(index==0){
				this.$set(item, 'checked', true);
			}
		})

		:class="{'active': item.checked}"
		selectProduct(item) {
			this.calculateList.forEach((item, index) => {
				item.checked=false;
			})
			item.checked=true;
		}

		2.//时间转换
		for(let i=0;i<res.data.list.length;i++){
			res.data.list[i].ctime=vis.$tool.handleDate(Number(res.data.list[i].ctime),'ss');
		}
		
		setVal(e) {
		    let self = this,
		      text = e.detail.value;
		    console.log(e)
		    self.setData({
		      [e.currentTarget.dataset.name]: text
		    })
		    console.log(self.data)
		}
		

		3.//tab切换 头部切换
		switchTitle
        <div :class="{'active':isActive==index}" 
			v-for="(g,index) of type" 
			:key="index"
			@click="isActive=index">
				{{g.name}}
		</div>

		isActive:'0',
		type:[{name: '48V'}, {name: '60V'} ]

		4.//图片上传
		import ImgUp from '@/components/ImgUpLoad'
		<img-up width="1.6rem" height="1.6rem" file="faultUp" @setImgFile="setImgFile" @delImgFile="delImgFile"></img-up>
		ImgUp

		setImgFile(imgFile){
	    	let formData = new FormData();
	    	formData.append('api_name','uploadPic');
	        formData.append('img',imgFile[imgFile.length-1]);
	        this.$toast.loading({duration:0, forbidClick:true, mask:true, loadingType:'spinner', message:'提交中...'});
			this.$http.post('/outside/User/api',formData,'multipart/form-data').then(res => {
				this.$toast.clear();

	        	if (res.code==1) {
	        		this.imgId[this.imgId.length]=res.data.id;
	        		this.imgSrc[this.imgSrc.length]=res.data.path;
	        		console.log(this.imgSrc)
	        		console.log(this.imgId)
	        		console.log(this.imgId.join())
	        	}else{
		        	this.$toast(res.msg);
	        	}
      		})
	    },
	    delImgFile(index){
	    	this.imgSrc.splice(index,1);
	    }


		5.//下拉列表
        <van-list
			  v-model="loading"
			  :finished="finished"
			  finished-text="没有更多了"
			  :offset="100"
			  @load="getList"
			>
			v-for="(g,index) of orderList" :key="index"
		</van-list>

		data(){
			return {
				finished : false,
				loading  : false,
				orderList: [],
				page     : 1
			}
		}
		
		6.//询问
		let vis=this;
	    vis.$dialog.confirm({
			title: '提示',
			message: '设置为默认银行卡吗？'
		}).then(() => {
		  	
		}).catch(() => {
		  // on cancel
		});

		7.//下拉框
		<script>
			{
				sltList:[],
				sltShow:false,
				sltedName:'',
                sltedActive: '' //选择的级别
            }
            onChange(value, index) {
                this.sltedName=value.agent_role;
                this.sltedActive=value.level;
                this.sltShow=false;
            },
            cancelH(){
                this.sltShow=false;
            }
		</script>
        <van-popup v-model="sltShow" position="bottom">
        	<van-picker :columns="sltList" @confirm="onChange" @cancel="cancelH" value-key="agent_role" show-toolbar/>
    	</van-popup>

    	8.//地图

		<tmap :markerIcon="markerIcon" :marker="mapMarker" :center="center" ref="oMap" :locationImg="locationImg">
			<slot></slot>
		</tmap>

		import Tmap from '@/components/tmap'

		data(){
			return {
				markerIcon: require("@/assets/imgs/icon1.png"),
				locationImg: require("@/assets/imgs/ic43.png"),//中心点图标
				mapMarker: [
					// {
					// 	// 标注点ID
					// 	id: 1,
					// 	// 标注点名称
					// 	name: "汤包",
					// 	// 标注点经纬度
					// 	lat: "22.993054",
					// 	lng: "113.707691",
					// 	// 标注点点击事件
					// 	f: () => {
					// 		console.log(1);
					// 	}
				 //    },
				],
				center: {}
			}
		}

		vis.$refs['oMap'].init();

		rd.forEach((item, index) => {
		    item.f=(item)=>{
		        vis.clickDevice=item;
		    }
		})

		9.//导航
		navigation
		if (vis.scanSource==2) {
            window.location.href = `https://apis.map.qq.com/tools/poimarker?type=0&marker=coord:${ cm.lat },${ cm.lng };title:${ cm.name };addr:${ cm.address }&key=N6RBZ-AJN35-AACI2-Q2ICF-HYV6O-JRBBZ&referer=myapp`;
        }else{
            wx.openLocation({
                latitude: cm.lat*1, // 纬度，浮点数，范围为90 ~ -90
                longitude: cm.lng*1, // 经度，浮点数，范围为180 ~ -180。
                name: cm.name, // 位置名
                address: cm.address, // 地址详情说明
                scale: 14// 地图缩放级别,整形值,范围从1~28。默认为最大
            });
        }

        10.//微信支付
        WeixinJSBridge.invoke(
            'getBrandWCPayRequest', {
                appId: rd.appId,     //公众号名称，由商户传入     
                timeStamp: rd.timeStamp,         //时间戳，自1970年以来的秒数     
                nonceStr: rd.nonceStr, //随机串     
                package: rd.package,     
                signType: rd.signType,         //微信签名方式：     
                paySign: rd.paySign //微信签名 
            },
            function(jso){
                if(jso.err_msg == "get_brand_wcpay_request:ok"){
                    vis.stateOff=true;
                }else{
                    vis.$toast.fail("支付失败，请重新支付！");
                }
            }
        );

        11.//
        go(){
			let vis=this;
			vis.$router.push({
				path:'/devOps/maintainingRecords',
				query:{
					id: vis.id,
					macno: vis.deviceNo,
					address: vis.rd.address
				}
			})
		},
	</div>
</template>

<script>
var app = new Vue({
    el: '#app',
    data: {},
    created() {},
    computed:{},
    methods:{
    }
})


//1.设置分享出去的url 不一定是当前url
wx.ready(()=>{
        // 2. 分享接口
        // 2.1 监听“分享给朋友”，按钮点击、自定义分享内容及分享结果接口
    wx.onMenuShareAppMessage({
        title: '一起加入新界零售吧！', // 分享标题
        desc: '', // 分享描述
        link: `${baseApi}/h5/vue/#/personal/invite/join?id=${vis.userId}`, // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
        imgUrl: 'http://szshg.a.xiaozhuschool.com/static/images/0243a65b40247dda658b843159c5d76.png', // 分享图标
        success: res => {},
        cancel: res => {
            vis.$toast('已取消')
        },
        fail: err => {alert(JSON.stringify(err))}
    })
    // 2.2 监听“分享到朋友圈”按钮点击、自定义分享内容及分享结果接口
    wx.onMenuShareTimeline({
        title: '一起加入新界零售吧！', // 分享标题
        link: `${baseApi}/h5/vue/#/personal/invite/join?id=${vis.userId}`, // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
        imgUrl: 'http://szshg.a.xiaozhuschool.com/static/images/0243a65b40247dda658b843159c5d76.png', // 分享图标
        success: res => {},
        cancel: res => {vis.$toast('已取消')},
        fail: err => {alert(JSON.stringify(err))}
    })
})

</script>

//加载层
vis.$toast.loading({duration:0, forbidClick:true, mask:true,loadingType:'spinner', message:'加载中...'});
// 持续展示
vis.$toast({duration: 0, forbidClick: true, message: 'xxx'});
setTimeout(()=>{ vis.$toast.clear(); vis.$router.go(-1) },3000)