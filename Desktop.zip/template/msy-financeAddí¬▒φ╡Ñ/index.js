const app = getApp()
import {
  uploadFile
} from '../../utils/dlc.js';

Page({
    data: {
        host: app.globalData.dlcurl,
        startTime: '请选择',
        hms: '请选择',
        costName: '',
        costAmount: '',
        explain: '',
        lispic:[]
    },

    onLoad: function (e) {
        let self = this

    },

    onShow: function () {
        let self = this
    },
    
    setVal(e){
      let self = this, text = e.detail.value;
      console.log(e)
      self.setData({
        [e.currentTarget.dataset.name]: text
      })
      console.log(self.data)
    },

    submit(){
      let self = this,
      vf = [
          [self.data.costName, 0 ,"费用名称不能为空"], 
          [self.data.costAmount, 1], 
          [self.data.startTime, 0, "产生时间不能为空"],
          [self.data.hms, 0, "产生时间不能为空"]
        ];

      if (app.mt.jd(vf , app.tools.error_tip)){
        console.log(self.data.startTime + " " + self.data.hms+":00");
        app.mt.gd(app.wxRequest, '/api/store/addStoreCost',{
          costImgs: self.data.lispic.join(','),
          costName: self.data.costName,
          costAmount: self.data.costAmount,
          generationTime: self.data.startTime + " " + self.data.hms+":00",
          explain: self.data.explain
        }, res => {
          wx.showToast({
            title: '提交成功',
            icon: 'success',
            duration: 2000,
            success:()=>{
              wx.navigateBack({
                delta: 1
              })
            }
          });
        }, app.tools.error_tip);
      }
    },

    uploadPic:function(){//
      let self=this
      wx.chooseImage({
        count: 9,
        sizeType: ['original', 'compressed'],
        success: function(res) {
          var tfp = res.tempFilePaths;
          tfp.forEach((item)=>{
            uploadFile(item).then(img => {
              self.setData({
                lispic: self.data.lispic.concat(img)
              });
            }).catch(err => {
              console.log(err);
            });
          });
        }
      })
    },

    delImg(e){
      let self=this , l = this.data.lispic;
      l.splice(e.currentTarget.dataset.id,1);
      self.setData({
        lispic: l
      })
    }
})