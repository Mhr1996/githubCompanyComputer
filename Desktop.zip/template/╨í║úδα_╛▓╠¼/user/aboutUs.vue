<template>
	<div class="aboutUs">
		<div class="flex fc ptb_50 cca2">
			<img src="@/assets/imgs/title.png" alt="" class="mauto br50">
			<p>asdsd</p>
		</div>
		<div class="p15 mlr_15" v-html="rd.content"> </div>
	</div>
</template>

<script>
	import { getAboutUs } from '@/api'
	export default{
		name:"aboutUs",
		components:{
		},
		data(){
			return {
				rd:{}
			}
		},
		created(){
	        let vis=this;
	        getAboutUs({}).then(res=>{
	            if(res.code==1){
	            	vis.rd=res.data;
	            }else{
	                vis.$toast(res.msg)
	            }
	        })
		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.aboutUs{
		min-height: 100vh;
		/*background-color: #f5f5f5;*/
	}
	.mauto.br50{
		width:1.8rem;
		height:1.8rem;
	}
</style>