<template>
	<div class="processed center">
		<img src="@/assets/imgs/icon12.png" alt="" style="width:2.2rem;height:2.2rem;" class="mt70 mb40">
		<p class="mb15">申请退款成功！</p>
		<p class="mb15">押金退出后将不可以继续使用换电，</p>
		<p class="mb15">押金在2~7个工作日到账</p>
		<div class="returnBtn">返回首页</div>
	</div>
</template>

<script>
	export default{
		name:"processed",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.processed{
		min-height: 100vh;
		/*background-color: #f5f5f5;*/
	}
	.returnBtn{
		height: .9rem;
		width: 90%;
		margin: 0 auto;
		color: #999;
		text-align: center;
		line-height: .9rem;
		@include br(.9rem);
		border:.02rem solid #999;
		margin-top: .8rem;
	}
</style>