<template>
	<div class="troubleshooting oh">
		<div class="cgf lh40 cgf center csb mb15">
			<div class="h100 c9 fz16 w50">待维修</div>
			<div class="h100 c9 fz16 w50 active">维修成功</div>
		</div>
		<div class="p12 cgf m15 br oh">
			<div class="lh40 csb">
				<p>设备编号：<span class="c9">12312312</span></p><span class="cr">电池放入失败</span>
			</div>
			<div class="lh40">
				<p>设备地址：<span class="c9">广东省高速科技园</span></p>
			</div>
			<div class="lh40 c9 bbeb">
				<p>设备柜号：<span>16</span></p>
			</div>
			<div class="btn lh40 cb2 brde r mt10 br center plr_4" style="width:1.8rem;border-color:#70b7fe;border-radius: .40rem;">查看维修记录</div>
		</div>
	</div>
</template>

<script>
	export default{
		name:"troubleshooting",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.troubleshooting{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.active{
		color: #1a8cfe;
		position: relative;
		&:after{
			position:absolute;
			content: '';
			position: bottom center;
			@include br(.3rem);
		    bottom: 0;
		    width: 1rem;
		    left: 50%;
		    margin-left: -.5rem;
		    height: .06rem;
		    background-color: #1a8cfe;
		}
	}
</style>