<template>
	<div class="buyPackages oh plr_15">
		<div class="csb mt15 cgf br plr_15 bgImg" style="height:1.5rem;">
			<div class="cca2">
				<p class="fz18 mb15">套餐类型：次卡</p>
				<p class="c9 fz13">次数:10</p>
			</div>
			<div class="fz22 cp">￥75.00</div>
		</div>
		<div class="csb mt15 cgf br plr_15 bgImg" style="height:1.5rem;">
			<div class="cca2">
				<p class="fz18 mb15">套餐类型：次卡</p>
				<p class="c9 fz13">次数:10</p>
			</div>
			<div class="fz22 cp">￥75.00</div>
		</div>
		<div class="csb mt15 cgf br plr_15 bgImg" style="height:1.5rem;">
			<div class="cca2">
				<p class="fz18 mb15">套餐类型：次卡</p>
				<p class="c9 fz13">次数:10</p>
			</div>
			<div class="fz22 cp">￥75.00</div>
		</div>
	</div>
</template>

<script>
	export default{
		name:"buyPackages",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.buyPackages{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.bgImg{
		@include bm('~@/assets/imgs/icon16.png',100%,100%);
	}
</style>