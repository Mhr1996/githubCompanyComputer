<template>
	<div class="walletDetails oh">
		<div class="cgf m15">
			<div class="p15 bbeb lh30 ptb_10">
				<div class="csb">
					<div>交押金</div><div class="cp fz20">-￥100</div>
				</div>
				<div class="csb">
					<div class="fz12 c9">微信支付</div><div class="c9">2019-9-5 13:47:20</div>
				</div>
			</div>
			<div class="p15 bbeb lh30 ">
				<div class="csb">
					<div>交押金</div><div class="cp fz20">-￥100</div>
				</div>
				<div class="csb">
					<div class="fz12 c9">微信支付</div><div class="c9">2019-9-5 13:47:20</div>
				</div>
			</div>
			<div class="p15 bbeb lh30 ">
				<div class="csb">
					<div>交押金</div><div class="cp fz20">-￥100</div>
				</div>
				<div class="csb">
					<div class="fz12 c9">微信支付</div><div class="c9">2019-9-5 13:47:20</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default{
		name:"walletDetails",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.walletDetails{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
</style>