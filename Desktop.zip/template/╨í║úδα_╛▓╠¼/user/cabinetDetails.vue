<template>
	<div class="cabinetDetails oh">
		<div class="p12 cgf m15 br oh">
			<div class="lh40 csb">
				<p>设备编号：<span class="c9">12312312</span></p>
			</div>
			<div class="lh40">
				<p>设备地址：<span class="c9">广东省高速科技园</span></p>
			</div>
			<div class="lh40 c9 bbeb">
				<p>设备柜号：<span>16</span></p>
			</div>
			<div>
				<div class="sign lh40 pl15">补货电池类型</div>
				<div class="csb lh40">
					<span>48V</span><div><img src="@/assets/imgs/pitchon.png" style="width:.44rem;"></div>
				</div>
				<div class="csb lh40">
					<span>60V</span><div><img src="@/assets/imgs/radio.png" style="width:.44rem;"></div>
				</div>
			</div>
		</div>
		<div class="submitBtn2">完成补货</div>
	</div>
</template>

<script>
	export default{
		name:"cabinetDetails",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.cabinetDetails{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.sign{
		position: relative;
		&:after{
			position:absolute;
			content: '';
			width: .1rem;
			height: .3rem;
			background-color: #1c8dfe;
			left: 0;
			top: .24rem;
			@include br(.1rem);
		}
	}
</style>