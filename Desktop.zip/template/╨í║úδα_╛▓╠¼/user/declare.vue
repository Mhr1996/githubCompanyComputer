<template>
	<div class="declare pt15 bz">
		<div class="plr_15">
			<p class="fz18">请选择故障原因</p>
			<div class="csa wrap mtb_10 lh30">
				<div class="pl24 radio active">电池未弹出来</div> <div class="pl24 radio">外壳损坏</div><div class="pl24 radio">外壳损坏</div>
			</div>
			<div class="plr_15 brde bst br">
				<div class="csb bbeb lh40"><span>设备编号</span><span>12312</span></div>
				<div class="csb lh40"><span>设备柜号</span><span>12312</span></div>
			</div>
			<div class="cgf lh24 brde bst br p12 mt10">
				<textarea name="" id="" class="w100" cols="30" rows="5" placeholder="请输入您的问题，我们会及时处理！"></textarea>
				<img-up width="1.6rem" height="1.6rem" file="faultUp" @setImgFile="setImgFile" @delImgFile="delImgFile"></img-up>
				<div class="c9">温馨提示：最多只能上传4张图片</div>
			</div>
			<div class="submitBtn2">提交</div>
		</div>
	</div>
</template>

<script>
	import ImgUp from '@/components/ImgUpLoad'
	export default{
		name:"declare",
		components:{
			ImgUp
		},
		data(){
			return {
				imgSrc:[]
			}
		},
		created(){

		},
		methods:{
			setImgFile(imgFile){
		    	this.imgFile=imgFile;
		    	let formData = new FormData();
		        formData.append('img',this.imgFile[this.imgFile.length-1]);
		    },
		    delImgFile(index){
		    	this.imgSrc.splice(index,1);
		    }
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.declare{
		min-height: 100vh;
		/*background-color: #f5f5f5;*/
	}
	.radio{
		@include bm('~@/assets/imgs/radio.png',.36rem,.36rem);
		background-position: left;
	}
	.radio.active{
		@include bm('~@/assets/imgs/icon10.png',.36rem,.36rem);
		background-position: left;
	}
</style>