<template>
	<div class="myBattery oh">
		<div class="mt20 mlr_15 cf bgImg br p15 bz">
			<div class="csb">
				<div>电池编号：{{rd.batteryNo}}</div><div>电池电压：{{rd.typeName}}V</div>	
			</div>
			<div class="ccc h100">
				<p style="font-size:.8rem;" class="mb10">{{rd.electric}}%</p>
				<p>电池电量</p>
			</div>
		</div>
		<div class="submitBtn2" style="position:fixed;bottom:0;left:50%;margin-left:-40%;">归还电池</div>
	</div>
</template>

<script>
    import { getUserBattery } from '@/api'
	export default{
		name:"myBattery",
		components:{
		},
		data(){
			return {
				rd:{}
			}
		},
		created(){
			let vis=this;
            getUserBattery({}).then(res=>{
                if(res.code==1){
                	vis.rd=res.data;
                }else{
                    vis.$toast(res.msg)
                }
            })
		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.myBattery{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.bgImg{
		height:3rem;
		background: -webkit-linear-gradient(left,#70b7fe,#1b8cfe); /* Safari 5.1-6.0 */
	    background: -o-linear-gradient(left,#70b7fe,#1b8cfe); /* Opera 11.1-12.0 */ 
	    background: -moz-linear-gradient(left,#70b7fe,#1b8cfe); /* Firefox 3.6-15 */
	    background: linear-gradient(left,#70b7fe,#1b8cfe); /* 标准语法 */
	}
</style>