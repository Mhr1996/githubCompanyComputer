<template>
	<div class="myPackage bz oh plr_15">
		<div class="ptb_50 mtb_50 center">
			<img src="@/assets/imgs/icon35.png" alt="" class="mauto mb15 w240">
			<p style="color:#1a8cfe;">您还未购买套餐！</p>
		</div>
		<div class="submitBtn2">购买套餐</div>
		<van-list
			  v-model="loading"
			  :finished="finished"
			  finished-text="没有更多了"
			  :offset="100"
			  @load="getList"
			>
			<div class="csb mt15 cgf br plr_15 bgImg" style="height:1.5rem;" v-for="(g,index) of orderList" :key="index">
				<div class="cca2">
					<p class="fz18 mb15">套餐类型：次卡</p>
					<p class="c9 fz13">次数:10</p>
				</div>
				<div class="fz22 cp">￥75.00</div>
			</div>
		</van-list>
	</div>
</template>

<script>
    import { getUserCards } from '@/api'
	export default{
		name:"myPackage",
		components:{
		},
		data(){
			return {
				finished : false,
				loading  : false,
				orderList: [],
				page     : 1
			}
		},
		created(){
		},
		methods:{
			getLlist(){
				let vis=this;
	            getUserCards({
	                page:vis.page,
	                limit:10
	            }).then(res=>{
	                if(res.code==1){
	                    if (res.code == 1) {
	                        let rd=res.data.list;
	                        for(let i=0;i<rd.length;i++){
	                            rd[i].createat=vis.$tool.handleDate(Number(rd[i].ctime),'ss');
	                        }
	                        vis.orderList=[...vis.orderList,...rd];
	                        if (rd.length<10) {
	                            vis.finished = true
	                        }
	                        vis.page++;
	                    }else{
	                        vis.$toast(res.msg);
	                        vis.finished = true;
	                    }
	                    vis.loading = false;
	                }else{
	                    vis.$toast(res.msg)
	                }
	            })
			}
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.myPackage{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.w240{
		width:2.4rem;
	}
	.bgImg{
		@include bm('~@/assets/imgs/icon16.png',100%,100%);
	}
</style>