<template>
	<div class="modifyMobile oh">
		<div class="flex lh50 mb10 mlr_15 mt15 cgf plr_10">
			<span>手机号：</span><input type="text" class="flex1" v-model="mobile" placeholder="请输入新手机号">
		</div>
		<div class="flex lh50 mb10 mlr_15 mt15 cgf plr_10 relative">
			<span>验证码：</span><input type="text" class="flex1" placeholder="请输入验证码">
			<validate @click="getCode"></validate>
		</div>
		<div class="submitBtn2">确认</div>
	</div>
</template>

<script>
	import validate from '@/components/validate'
	export default{
		name:"modifyMobile",
		components:{
			validate
		},
		data(){
			return {
				mobile:''
			}
		},
		created(){

		},
		methods:{
			sendVer(){
				let self=this;
				this.$http.post("/Wxsite/User/api",{
					api_name:"sendCode"
					,mobile :this.mobile
				}).then(res => {
					if (res.code == 1) {
						self.$toast("发送成功，请注意查收");
					}else{
						self.$toast(res.msg);
					}
				})
			},
			getCode(cb){
				let re=/^1[0-9]{10}$/;
				if(!re.test(this.mobile)){
					this.$toast("手机号格式不正确!");
					return;
				}
				//cb(this.sendVer);
			}
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.modifyMobile{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.verBtn{
		background-color:#1a8cfe;
		color: #fff;
		width: 1.8rem;
		height: .6rem;
		line-height: .6rem;
		text-align: center;
		@include br(.6rem);
		top: .2rem;
		right: .1rem;
	}
</style>