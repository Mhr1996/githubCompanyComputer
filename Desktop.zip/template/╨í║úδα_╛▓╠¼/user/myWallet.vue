<template>
	<div class="myWallet oh">
		<router-link class="pl rj icon1" to="/user/myPackage">
			<div>我的套餐</div>
		</router-link>
		<div class="pl csb rj icon2">
			<div>押金</div><div>未交</div>
		</div>
		<div class="pl csb rj icon3">
			<div>明细</div><div>去看看</div>
		</div>
	</div>
</template>

<script>
	export default{
		name:"myWallet",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.myWallet{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.pl.rj{
		padding-left: 1rem;
    	padding-right: .6rem;
	}
	.rj {
	    background-image: url('~@/assets/imgs/more.png');
	    background-repeat: no-repeat;
	    background-size: 6px 11px;
	    background-position: 6.5rem;
	}
	.icon1{
		position: relative;
		&:after{
			@include after();
			width: .4rem;
			height: .4rem;
			background: url('~@/assets/imgs/icon18.png');
			background-size: 100% 100%;
			margin-top: -.2rem;
			left: .3rem;
		}
	}
	.icon2{
		position: relative;
		&:after{
			@include after();
			width: .4rem;
			height: .4rem;
			background: url('~@/assets/imgs/icon20.png');
			background-size: 100% 100%;
			margin-top: -.2rem;
			left: .3rem;
		}
	}
	.icon3{
		position: relative;
		&:after{
			@include after();
			width: .4rem;
			height: .4rem;
			background: url('~@/assets/imgs/icon19.png');
			background-size: 100% 100%;
			margin-top: -.2rem;
			left: .3rem;
		}
	}
</style>