<template>
	<div class="deviceDetails">
		<div class="mt20 mlr_15 cf bgImg br p15 bz">
			<div class="ccc h2">
				<p style="font-size:.8rem;" class="mb10">48V</p>
			</div>
			<div class="csb">
				<div>￥10.00</div><div>剩余：3</div>	
			</div>
		</div>
		<div class="mt20 mlr_15 cf bgImg br p15 bz">
			<div class="ccc h2">
				<p style="font-size:.8rem;" class="mb10">48V</p>
			</div>
			<div class="csb">
				<div>￥10.00</div><div>剩余：3</div>	
			</div>
		</div>
		<div class="mt20 mlr_15 cf bgImg br p15 bz grey">
			<div class="ccc h2">
				<p style="font-size:.8rem;" class="mb10">48V</p>
			</div>
			<div class="csb">
				<div>￥10.00</div><div>剩余：3</div>	
			</div>
		</div>
		<div class="c9 lh30 fc jc center bottomInfo w100" ><img src="@/assets/imgs/icon32.png" class="mr5" alt="">请选择电瓶电压，避免无法使用</div>
	</div>
</template>

<script>
	export default{
		name:"deviceDetails",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.deviceDetails{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.bgImg{
		background: -webkit-linear-gradient(left,#70b7fe,#1b8cfe); /* Safari 5.1-6.0 */
	    background: -o-linear-gradient(left,#70b7fe,#1b8cfe); /* Opera 11.1-12.0 */ 
	    background: -moz-linear-gradient(left,#70b7fe,#1b8cfe); /* Firefox 3.6-15 */
	    background: linear-gradient(left,#70b7fe,#1b8cfe); /* 标准语法 */
	}
	.bgImg.grey{
		background: -webkit-linear-gradient(left,#e6e6e6,#cccccc); /* Safari 5.1-6.0 */
	    background: -o-linear-gradient(left,#e6e6e6,#cccccc); /* Opera 11.1-12.0 */ 
	    background: -moz-linear-gradient(left,#e6e6e6,#cccccc); /* Firefox 3.6-15 */
	    background: linear-gradient(left,#e6e6e6,#cccccc); /* 标准语法 */
	}
	.bottomInfo{
		position: fixed;
		bottom: 0;
		left: 0;
		z-index: 10;
		img{
			width:.32rem;
		}
	}
</style>