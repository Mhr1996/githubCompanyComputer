<template>
	<div class="feedback">
		<div class="cgf p12 lh24">
			<textarea name="" id="" class="w100" cols="30" rows="5" placeholder="请输入您发聩的问题，并留下您的联系方式，我们 会尽快联系您！"></textarea>
			<img-up width="1.6rem" height="1.6rem" file="faultUp" @setImgFile="setImgFile" @delImgFile="delImgFile"></img-up>
			<div class="c9">温馨提示：最多只能上传4张图片</div>
		</div>
		<div class="submitBtn2">提交</div>
	</div>
</template>

<script>
	import ImgUp from '@/components/ImgUpLoad'
	export default{
		name:"feedback",
		components:{
			ImgUp
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			setImgFile(imgFile){
		    	this.imgFile=imgFile;

		    	let formData = new FormData();

		        formData.append('img',this.imgFile[this.imgFile.length-1]);
				//       this.$toast.loading({duration:0, forbidClick:true, mask:true, loadingType:'spinner', message:'提交中...'});
				// this.$http.post('/wxsite/user/ajaxImg',formData,'multipart/form-data').then(res => {
				// 	this.$toast.clear();

				//       	if (res.data.code==1) {
				//       		this.imgSrc[this.imgSrc.length]=res.data.data.img;
				//       	}else{
				//        	this.$toast(res.data.msg);
				//       	}
				//    		})
		    },
		    delImgFile(index){
		    	this.imgSrc.splice(index,1);
		    }
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.feedback{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
</style>