<template>
	<div class="nearby">
		<tmap :markerIcon="markerIcon" :marker="mapMarker" :center="center" ref="oMap" :locationImg="locationImg">
			<div class="top cgf p10 bst2 lh30 bz br" v-if="clickDevice.deviceNo">
				<p class="c9">设备编号：<span class="c3">{{clickDevice.deviceNo}}</span></p>
				<p class="c9">可换{{isActive == 0 ? '48V' : '60V'}}电池数量：<span class="c3">{{clickDevice.fortyEightNum||clickDevice.sixtyNum}}</span></p>
				<div class="ellipsis">
					<img src="@/assets/imgs/address.png" alt="" class="mr10" style="width: .24rem;">{{clickDevice.address}}
				</div>
				<img src="@/assets/imgs/icon8.png" alt="" class="dh" @click="navigation()">
			</div>
			<div class="left cca cgf">
				<div class="ccc"><img src="@/assets/imgs/icon33.png" alt=""></div>
				<div 
					:class="{'active':isActive==index}" 
					v-for="(g,index) of type" 
					:key="index"
					@click="changeType(g,index)">
						{{g.type}}
				</div>
			</div>
			<div class="right cca">
				<router-link class="ccc" tag="div" to="/user/messageCenter">
					<img src="@/assets/imgs/icon6.png" alt="" style="width:.59rem">
				</router-link>
				<div class="ccc" @click="scan"><img src="@/assets/imgs/icon4.png" alt="" style="width:.54rem"></div>
				<router-link class="ccc" tag="div" to="/user/personalCenter">
					<img src="@/assets/imgs/icon5.png" alt="" style="width:.54rem">
				</router-link>
			</div>
			<div class="bottom">
				<img src="@/assets/imgs/sec.png">
			</div>
		</tmap>
		<!-- <section id="Map" class="vh100"></section> -->
	</div>
</template>

<script>
	import Tmap from '@/components/tmap'
    import { getMapDeviceList, getStyle, getTicket } from '@/api'
	export default{
		name:"nearby",
		components:{
			Tmap
		},
		data(){
			return {
				isActive:'0',
				type:[],
				markerIcon: require("@/assets/imgs/icon1.png"),
				locationImg: require("@/assets/imgs/ic43.png"),//中心点图标
				mapMarker: [
					// {
					// 	// 标注点ID
					// 	id: 1,
					// 	// 标注点名称
					// 	name: "汤包",
					// 	// 标注点经纬度
					// 	lat: "22.993054",
					// 	lng: "113.707691",
					// 	// 标注点点击事件
					// 	f: () => {
					// 		console.log(1);
					// 	}
				 //    },
				],
				center: {},
				clickDevice:{}
			}
		},
		created(){
			let vis=this;
            vis.center.lat =22.991642;
            vis.center.lng =113.706844;

            getTicket({}).then(res=>{
                if(res.code==1){
                	let timestamp= (new Date().getTime() / 1000).toFixed(0)
                    ,nonceStr=Math.random().toString(36).substr(2),
                    ticket=vis.$tool.wx_js(res.data.ticket,timestamp,nonceStr);

                    wx.config({
                        debug: false, // 开启调试模式,调用的所有api的返回值会在客户端//alert出来，若要查  看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
                        appId: 'wx9222384d464233a1', // 必填，公众号的唯一标识
                        timestamp: timestamp, // 必填，生成签名的时间戳
                        nonceStr:  nonceStr, // 必填，生成签名的随机串
                        signature: ticket ,// 必填，签名，见附录1
                        jsApiList: [
                            'scanQRCode',
                            'getLocation',
                            'openLocation'
                        ] //    必填，需要使用的JS接口列表，所有JS接口列表见附录2
                    });
                }else{
                    vis.$toast(res.msg)
                }
            })

            vis.getDeviceStyle();
            vis.getMapList();
		},
		mounted: function () {
		},
		methods:{
			navigation(){
				let cm = this.clickDevice;
				wx.openLocation({
	                latitude: cm.lat*1, // 纬度，浮点数，范围为90 ~ -90
	                longitude: cm.lng*1, // 经度，浮点数，范围为180 ~ -180。
	                name: '', // 位置名
	                address: cm.address, // 地址详情说明
	                scale: 14// 地图缩放级别,整形值,范围从1~28。默认为最大
	            });
			},
			scan(){
				let vis=this;
				wx.ready(()=>{
                    wx.scanQRCode({
	                    needResult: 1, // 默认为0，扫描结果由微信处理，1则直接返回扫描结果，
	                    scanType: ["qrCode","barCode"], // 可以指定扫二维码还是一维码，默认二者都有
	                    success: function (ret) {
	                    	//扫一扫
	                    	console.log(ret)
	                    },
	                    complete(){
	                        if(this.scanner_onOff){
	                            WeixinJSBridge.call('closeWindow');
	                        }
	                    },
	                    error:function(err){
	                        alert(JSON.stringify(err));
	                    },
	                });
                })
			},
			getDeviceStyle(){
				let vis=this;
	            getStyle({}).then(res=>{
	                if(res.code==1){
	                	vis.type=res.data;
	                }else{
	                    vis.$toast(res.msg)
	                }
	            })
			},
			changeType(item,index){
				this.isActive=index;
				this.getMapList();
			},
			getMapList(){
				let vis=this;
	            getMapDeviceList({
	                lat: vis.center.lat,
	                lng: vis.center.lng,
	                type: vis.isActive==0 ? '48' : '60'
	            }).then(res=>{
	            	let rd=res.data;
	                if(res.code==1){
						rd.forEach((item, index) => {
	                        item.f=(item)=>{
	                        	console.log("点击")
	                            vis.clickDevice=item;
	                        }
	                    })
	                	vis.mapMarker=rd;
	                	vis.$refs['oMap'].init();
	                }else{
	                    vis.$toast(res.msg)
	                }
	            })
			}
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.nearby{
		min-height: 100vh;
		/*background-color: #f5f5f5;*/
	}
	#Map{
		width: 100%;
		height: 100vh;
	}
	.top{
		position: fixed;
		top: .4rem;
		z-index: 10;
		left: 4%;
		width: 92%;
		margin:0 auto;
		.dh{
			width: .94rem;
			position: absolute;
			right: .2rem;
			top: .5rem;
			z-index: 10;
		}
	}
	.left{
		position: fixed;
		left: 4%;
		top: 40%;
		height: 2.5rem;
		text-align: center;
		display: flex;
		justify-content: space-around;
		flex-wrap: wrap;
		flex-direction: column;
		width: .8rem;
		z-index:10;
		img{
			width: .38rem;
		}
		div{
			width: 100%;
			height: 33.33%;
			line-height: .81rem;
		}
		.active{
			background-color: #1a8cfe;
			color: #fff;
		}
	}
	.right{
		position: fixed;
		right: 4%;
		top: 40%;
		width: .94rem;
		text-align: center;
		display: flex;
		justify-content: space-around;
		flex-wrap: wrap;
		flex-direction: column;
		z-index:10;
		div{
			width: 100%;
			height: .94rem;
			background-color: #fff;
			border-radius: 50%;
			margin-bottom: .3rem;
		}
	}
	.bottom{
		height:1.38rem;
		border-top-left-radius: 1.38rem;
		border-top-right-radius: 1.38rem;
		background-color: #f5f5f5;
		position: fixed;
		bottom: 0;
		z-index: 10;
		left: 0;
		width: 100%;
		text-align: center;
		img{
			width:1.94rem;height:1.94rem;
			margin-top: -.97rem;
		}
	}
</style>