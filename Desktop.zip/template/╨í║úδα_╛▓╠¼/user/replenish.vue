<template>
	<div class="replenish oh">
		<div class="csb info m15 br">
			<div class="center w50 cf">
				<p class="fz20 mb10">90</p>
				<div>设备数量(台)</div>
			</div>
			<div class="center w50 cf">
				<p class="fz20 mb10">180</p>
				<div> 补货记录(单) </div>
			</div>
		</div>
		<div class="csa">
			<img src="@/assets/imgs/replenish.jpg" style="width:3rem;">
			<img src="@/assets/imgs/device.jpg" style="width:3rem;">
		</div>
	</div>
</template>

<script>
	export default{
		name:"replenish",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.replenish{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.info{
		height:3rem;
		background: -webkit-linear-gradient(left,#70b7fe,#1b8cfe); /* Safari 5.1-6.0 */
	    background: -o-linear-gradient(left,#70b7fe,#1b8cfe); /* Opera 11.1-12.0 */ 
	    background: -moz-linear-gradient(left,#70b7fe,#1b8cfe); /* Firefox 3.6-15 */
	    background: linear-gradient(left,#70b7fe,#1b8cfe); /* 标准语法 */
	    position: relative;
	    &:after{
	    	position:absolute;
	    	content: '';
	    	width: .02rem;
	    	height: .8rem;
	    	background-color: #fff;
	    	left: 50%;
	    	top: 50%;
	    	margin-top: -.4rem;
	    	opacity: .5;
	    }
	}
</style>