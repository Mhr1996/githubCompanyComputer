<template>
	<div class="order">
		<div class="csb cgf lh40 mb12">
			<div class="w50 center cb">已完成</div>
			<div class="w50 center c6 cb">异常</div>
		</div>
		<div class="mlr_10 mt10 cgf br bz plr_15">
			<div class="csb bbeb lh50">
				<div>电池编号：003</div>
				<span class="cb">已完成</span>	
			</div>
			<div class="c9 lh50">
				<img src="@/assets/imgs/icon28.png" alt="" style="width:.25rem;" class="mr10">2019-9-5 10:40:07
			</div>
		</div>
	</div>
</template>

<script>
	export default{
		name:"order",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.order{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
</style>