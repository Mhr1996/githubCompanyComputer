<template>
	<div class="onState">
		<div class="cca h5">
			<img src="@/assets/imgs/icon13.png" alt="" style="width:2.2rem;height: 2.2rem;">
		</div>
		<p class="center">仓门打开失败</p>
		<div class="submitBtn2">确认</div>
		<div class="greyBtn">重新打开</div>
		<div class="cr fault">故障上报</div>
	</div>
</template>

<script>
	export default{
		name:"onState",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.onState{
		min-height: 100vh;
		@include bm('~@/assets/imgs/bg.jpg', 100%, 100%);
	}
	.greyBtn{
		margin: -.6rem auto 1rem auto;
	    height: 0.88rem;
	    line-height: 0.88rem;
	    text-align: center;
	    font-size: 0.32rem;
	    color: #999;
	    border-radius: 1rem;
	    -ms-border-radius: 1rem;
	    -moz-border-radius: 1rem;
	    -webkit-border-radius: 1rem;
	    width: 80%;
	    @include br(.88rem);
	    border:.02rem solid #999;
	    display: block;
	}
	.fault{
		padding: .4rem;
		position: fixed;
		bottom: 0;
		left: 50%;
		margin-left: -.94rem;
	}
</style>