<template>
	<div class="maintainingRecords">
		<div class="cgf plr_12 lh40 mb15">
			<p>设备编号：<span class="c9">12341234</span></p>
			<p>地址：<span class="c9">广东省东莞东莞多久多久低级</span></p>
		</div>
		<div class="m15">
			<div class="lh40 pl15 sign">
				维修记录描述
			</div>
			<div class="cgf p12 lh24">
				<p>充电线坏掉，但是我在维修过程中发现充电线已经 用完，下次拿好充电线再来继续维修，充电线坏掉，但是我在维修过程中发现充电线已经</p>
				<img-up width="1.6rem" height="1.6rem" file="faultUp" @setImgFile="setImgFile" @delImgFile="delImgFile"></img-up>
				<div class="c9">温馨提示：最多只能上传4张图片</div>
			</div>
			<div class="submitBtn2">提交记录</div>
		</div>
	</div>
</template>

<script>
	import ImgUp from '@/components/ImgUpLoad'
	export default{
		name:"maintainingRecords",
		components:{
			ImgUp
		},
		data(){
			return {
				imgSrc:[]
			}
		},
		created(){

		},
		methods:{
			setImgFile(imgFile){
		    	this.imgFile=imgFile;

		    	let formData = new FormData();

		        formData.append('img',this.imgFile[this.imgFile.length-1]);
		  //       this.$toast.loading({duration:0, forbidClick:true, mask:true, loadingType:'spinner', message:'提交中...'});
				// this.$http.post('/wxsite/user/ajaxImg',formData,'multipart/form-data').then(res => {
				// 	this.$toast.clear();

		  //       	if (res.data.code==1) {
		  //       		this.imgSrc[this.imgSrc.length]=res.data.data.img;
		  //       	}else{
			 //        	this.$toast(res.data.msg);
		  //       	}
	   //    		})
		    },
		    delImgFile(index){
		    	this.imgSrc.splice(index,1);
		    }
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.maintainingRecords{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.sign{
		position: relative;
		&:after{
			position:absolute;
			content: '';
			width: .1rem;
			height: .3rem;
			background-color: #1c8dfe;
			left: 0;
			top: .24rem;
			@include br(.1rem);
		}
	}
</style>