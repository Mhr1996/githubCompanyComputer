<template>
	<div class="personalCenter oh">
		<div class="m15  oh">
			<router-link class="center mb15 titleInfo" tag="div" to="/user/personalData">
				<img :src="title" class="titlePink mt30" style="width:1.6rem;">
				<p class="mt10 cf">{{name}}</p>
			</router-link>
			<router-link class="flex lh50 ac mt10" tag="div" to="/user/myBattery">
				<img src="@/assets/imgs/icon21.png" style="height:.38rem;" class="mr10">
				<div class="bbeb flex1 csb">我的电池<img src="@/assets/imgs/more.png"></div>
			</router-link>
			<router-link class="flex lh50 ac mt10" tag="div" to="/user/myWallet">
					<img src="@/assets/imgs/icon22.png" style="height:.32rem;" class="mr10">
					<div class="bbeb flex1 csb">我的钱包<img src="@/assets/imgs/more.png"></div>
			</router-link>
			<div class="flex lh50 ac mt10">
				<img src="@/assets/imgs/icon23.png" style="height:.42rem;" class="mr10">
				<div class="bbeb flex1 csb">我的订单<img src="@/assets/imgs/more.png"></div>
			</div>
			<div class="flex lh50 ac mt10">
				<img src="@/assets/imgs/icon24.png" style="height:.38rem;" class="mr10">
				<div class="bbeb flex1 csb">意见反馈<img src="@/assets/imgs/more.png"></div>
			</div>
			<div class="flex lh50 ac mt10">
				<img src="@/assets/imgs/icon25.png" style="height:.42rem;" class="mr10">
				<div class="bbeb flex1 csb">用户指南<img src="@/assets/imgs/more.png"></div>
			</div>
			<div class="flex lh50 ac mt10">
				<img src="@/assets/imgs/icon26.png" style="height:.42rem;" class="mr10">
				<div class="bbeb flex1 csb">关于我们<img src="@/assets/imgs/more.png"></div>
			</div>
		</div>
	</div>
</template>

<script>
	export default{
		name:"personalCenter",
		components:{
		},
		data(){
			return {
				title: this.$tool.getStore('headImg') || require('@/assets/imgs/title.png'),
				name: this.$tool.getStore('nickName') || '通宵达旦'
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.personalCenter{
		min-height: 100vh;
		/*background-color: #f5f5f5;*/
	}
	.flex>img{
		width:.42rem;
	}
	.titleInfo{
		height:3.27rem;
		background: url('~@/assets/imgs/bg2.png') no-repeat;
		background-size: 100% 100%;
	}
	.bbeb.flex1.csb img{
		height:.3rem;
	}
</style>