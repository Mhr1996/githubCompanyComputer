<template>
	<div class="bindPhone">
		<div class="head"><img src="@/assets/imgs/title.png" class="titlePink mtb_100"></div>
		<div class="info mb40">
			<div class="row mb10 cgf oh op8 phone">
				<input type="text" placeholder="请输入手机号" v-model="phone" Fv="2">
			</div>
			<div class="relative">
				<div class="row mb10 cgf oh op8 verCode">
					<input type="text" placeholder="请输入验证码" v-model="code" Fv="0"  FvInfo="请输入验证码">
				</div>
				<validate @click="getCode"></validate>
			</div>
			
		</div>
		<div class="center cf mb10" v-if="type==1">
			<span @click="onOff=!onOff">
				<img src="@/assets/imgs/icon34.png" alt="" v-show="onOff" style="width:.36rem;">
				<img src="@/assets/imgs/radio2.png" alt="" v-show="!onOff" style="width:.36rem;">
				已阅读
			</span>
			<router-link class="bold" to="userProtocol" tag="span">用户协议</router-link>
		</div>
		<button class="submitBtn2" @click="submit" style="width: 90%; color:#1a8cfe;margin-top:0px;">登录</button>
	</div>
</template>

<script>
    import { sendCode, login } from '@/api'
	import validate from '@/components/validate'
	export default{
		name:"bindPhone",
		components:{
			validate
		},
		data(){
			return {
				type:1,
				phone:"",
				code:"",
				onOff:false
			}
		},
		created(){
			if(!window.sessionStorage.getItem('loginType')){
				window.sessionStorage.setItem('loginType', this.$route.query.loginType || 1);
			}
		},
		methods:{
			sendVer(){
				let vis=this;
	            sendCode({
	                phone: vis.phone
	            }).then(res=>{
	                if(res.code==1){
	                	vis.$toast("发送成功，注意查收!");
	                }else{
	                    vis.$toast(res.msg)
	                }
	            })
			},
			getCode(cb){
				let re=/^1[0-9]{10}$/;
				if(!re.test(this.phone)){
					this.$toast("手机号格式不正确!");
					return;
				}
				cb(this.sendVer);
			},
			submit(){
				let vis = this;
				if(!vis.onOff){this.$toast("请阅读用户协议!");return;}
				if(vis.$tool.formVerification()){
					vis.$toast.loading({duration:0, forbidClick:true, mask:true,loadingType:'spinner', message:'加载中...'});
					 login({
						phone: vis.phone
						,code: vis.code
						,openId: vis.$tool.getStore("openId")
						,headImg: vis.$tool.getStore("headImg")
						,nickName: vis.$tool.getStore("nickName")
					}).then(res=>{
						vis.$toast.clear();
		                if(res.code==1){
		                	switch (window.sessionStorage.getItem('loginType')){
	                            case 1:
	                                router.replace({path: '/user/nearby'})
	                                break;
	                            case 2: //运维
	                                router.replace({path: '/devOps/devOps'})
	                                break;
	                            case 3: //补货
	                                break;
	                        }
		                }else{
		                    vis.$toast(res.msg)
		                }
		            })
				}
			}
		}

	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';

	.bindPhone{
		padding: 0 .46rem;
		margin: 0 auto;
		background: url('~@/assets/imgs/login.jpg') no-repeat;
		background-size: 100% 100%;
		min-height: 100vh;
	}
	.head{
		display: flex;
		img{
			width: 1.8rem;
			height: 1.8rem;
			display: block;
			margin: 2rem auto;
		}
	}
	.verBtn{
		z-index: 10;
		font-size:.26rem;
		width:1.9rem;    
		border-radius: 1rem;
    	right: .06rem;
    	color:#1a8cfe;
    	background-color:#fff;
	}
	.info{
		padding: 0 .28rem;
		box-sizing: border-box;
		.row{
			height: 0.8rem;
			line-height: 0.8rem;
			position: relative;
			padding-left: .3rem;
			padding-right: .3rem;

			@include br(1rem);
			@include box-shadow-abroad(0 0rem 0.02rem 0.02rem #ececec);
			input{
				width: 100%;
				color: #666;
				background-color: #fff;
			}
		}
	}
	.submitBtn2{
		background:#e9f4ff;
	}


	input::-webkit-input-placeholder,
	  textarea::-webkit-input-placeholder {
	    /* WebKit browsers */
	    color: #ccc;
	  }
	 
	  input:-moz-placeholder,
	  textarea:-moz-placeholder {
	    /* Mozilla Firefox 4 to 18 */
	    color: #ccc;
	  }
	 
	  input::-moz-placeholder,
	  textarea::-moz-placeholder {
	    /* Mozilla Firefox 19+ */
	    color: #ccc;
	  }
	 
	  input:-ms-input-placeholder,
	  textarea:-ms-input-placeholder {
	    /* Internet Explorer 10+ */
	    color: #ccc;
	   }
</style>