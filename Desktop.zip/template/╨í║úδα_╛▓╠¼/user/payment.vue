<template>
	<div class="payment oh">
		<div  class="mt20 mlr_15 cf bgImg br p15 bz">
			<div class="ccc h100">
				<p style="font-size:.8rem;" class="mb20">￥10.00</p>
				<p>电池编号001</p>
			</div>
		</div>
		<div class="mt20 cgf mlr_15 plr_15">
				<div class="lh50 pl15 sign">
					请选择支付方式
				</div>
				<div class="csb lh50"  @click="onOff=!onOff">
					<div><img src="@/assets/imgs/icon14.png" alt="" class="mr10" style="width:.42rem;height:.38rem;">微信支付</div>
					<div>
						<img src="@/assets/imgs/pitchon.png" alt="" style="width:.36rem;" v-show="onOff">
						<img src="@/assets/imgs/radio.png" alt="" style="width:.36rem;" v-show="!onOff">
					</div>
				</div>
		</div>
		<div class="submitBtn2">立即支付</div>
	</div>
</template>

<script>
	export default{
		name:"payment",
		components:{
		},
		data(){
			return {
				onOff:true
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.payment{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.bgImg{
		height:3rem;
		background: -webkit-linear-gradient(left,#70b7fe,#1b8cfe); /* Safari 5.1-6.0 */
	    background: -o-linear-gradient(left,#70b7fe,#1b8cfe); /* Opera 11.1-12.0 */ 
	    background: -moz-linear-gradient(left,#70b7fe,#1b8cfe); /* Firefox 3.6-15 */
	    background: linear-gradient(left,#70b7fe,#1b8cfe); /* 标准语法 */
	}
	.sign{
		position: relative;
		&:after{
			position:absolute;
			content: '';
			width: .1rem;
			height: .3rem;
			background-color: #1c8dfe;
			left: 0;
			top: .34rem;
			@include br(.1rem);
		}
	}
</style>