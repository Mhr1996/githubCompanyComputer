<template>
	<div class="messageCenter oh pt15 bz">
		<van-list
			  v-model="loading"
			  :finished="finished"
			  finished-text="没有更多了"
			  :offset="100"
			  @load="getList"
			>
			<div class="cgf br mlr_15 p15 mb15" v-for="(g,index) of orderList" :key="index">
				<p class="mb15">{{g.ctime | handleDate()}}</p>
				<p class="lh30">
					{{g.content}}
				</p>
			</div>
		</van-list>
	</div>
</template>

<script>
	import { messageList } from '@/api'
	export default{
		name:"messageCenter",
		components:{
		},
		data(){
			return {
				finished : false,
				loading  : false,
				orderList: [],
				page     : 1
			}
		},
		created(){
		},
		methods:{
			getList(){
				let vis=this;
				messageList({
				    page:vis.page,
				    limit:10
				}).then(res=>{
				    if(res.code==1){
				        if (res.code == 1) {
				            let rd=res.data.list;
				            vis.orderList=[...vis.orderList,...rd];
				            if (rd.length<10) {
				                vis.finished = true
				            }
				            vis.page++;
				        }else{
				            vis.$toast(res.msg);
				            vis.finished = true;
				        }
				        vis.loading = false;
				    }else{
				        vis.$toast(res.msg)
				    }
				})
			}
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.messageCenter{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
</style>