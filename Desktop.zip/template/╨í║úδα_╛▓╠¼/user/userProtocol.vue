<template>
	<div class="userProtocol p15 bz">
		<div class="cgf p15 br bz" v-html="content" v-show="content!=''">
			
		</div>
	</div>
</template>

<script>
	import { getAgreement } from '@/api'
	export default{
		name:"userProtocol",
		components:{
		},
		data(){
			return {
				content:''
			}
		},
		created(){
            let vis=this;
            getAgreement({}).then(res=>{
                if(res.code==1){
                	vis.content=res.data;
                }else{
                    vis.$toast(res.msg)
                }
            })

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.userProtocol{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
</style>