<template>
	<div class="deviceList oh">
		<div class="cgf br bz plr_12 m15">
			<div class="csb lh40">
				<div>设备编号：xxx</div><div class="status fz16 c9">离线</div>
			</div>
			<div class="lh40">
				<div class="c9">设备名称：xxxxxxxx</div>
			</div>
			<div class="flex bbeb p12 c9">
				<img src="@/assets/imgs/address.png" style="height:.3rem;" class="mr5">
				<div class="flex1 lh24">
					广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东
				</div>
			</div>
			<div class="lh40 csb">
				<div>48V电池数量：10</div><div>60V电池数量：10</div>
			</div>
		</div>
		<div class="cgf br bz plr_12 m15">
			<div class="csb lh40">
				<div>设备编号：xxx</div><div class="status fz16 c9">离线</div>
			</div>
			<div class="lh40">
				<div class="c9">设备名称：xxxxxxxx</div>
			</div>
			<div class="flex bbeb p12 c9">
				<img src="@/assets/imgs/address.png" style="height:.3rem;" class="mr5">
				<div class="flex1 lh24">
					广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东
				</div>
			</div>
			<div class="lh40 csb">
				<div>48V电池数量：10</div><div>60V电池数量：10</div>
			</div>
		</div>
		<div class="cgf br bz plr_12 m15">
			<div class="csb lh40">
				<div>设备编号：xxx</div><div class="status fz16 c9">离线</div>
			</div>
			<div class="lh40">
				<div class="c9">设备名称：xxxxxxxx</div>
			</div>
			<div class="flex bbeb p12 c9">
				<img src="@/assets/imgs/address.png" style="height:.3rem;" class="mr5">
				<div class="flex1 lh24">
					广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东广东
				</div>
			</div>
			<div class="lh40 csb">
				<div>48V电池数量：10</div><div>60V电池数量：10</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default{
		name:"deviceList",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.deviceList{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
</style>