<template>
	<div class="cabinet">
		<div class="cgf plr_12 lh40 mb15">
			<p>设备编号：<span class="c9">12341234</span></p>
			<p>地址：<span class="c9">广东省东莞东莞多久多久低级</span></p>
		</div>
		<div class="cgf p15">
			<p>选择柜子号开柜</p>
			<div class="wrap csa mtb_15">
				<div v-for="(item,index) of list" class="single cb">{{item}}</div>
			</div>
			<div class="csa">
				<div class="cgb cf w40 lh40 center" style="border-radius: .8rem;">一键全开</div>
				<div class="cgb2 cf w40 lh40 center" style="border-radius: .8rem;">选择开柜</div>	
			</div>
		</div>
		<div class="submitBtn2">填写维修记录</div>
	</div>
</template>

<script>
	export default{
		name:"cabinet",
		components:{
		},
		data(){
			return {
				list:[]
			}
		},
		created(){
			for(let i=1;i<25;i++){
				this.list[this.list.length]=i;
			}
		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.cabinet{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.single{
		width: .97rem;
		height: .97rem;
		text-align: center;
		border:.02rem solid #dce1ef;
		line-height: .97rem;
		margin-bottom: .2rem;
	}
</style>