<template>
	<div class="personalData oh">
		<div class="pl plr_15">
			<div>昵称</div><div class="c6">将阿基</div>
		</div>
		<div class="pl plr_15">
			<div>性别</div>
			<div class="flex c6">
				<div class="radio mr10 active">男</div><div class="radio mr10">女</div>
			</div>
		</div>
		<div class="pl plr_15">
			<div>生日</div><div class="c6">1992.12.18</div>
		</div>
		<div class="pl plr_15">
			<div>电话</div><div class="c6">13431116997 <img src="@/assets/imgs/more.png" alt="" class="ml10" style="width: .13rem;"></div>
		</div>
	</div>
</template>

<script>
	export default{
		name:"personalData",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.personalData{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.radio{
		padding-left: .5rem;
		background: url('~@/assets/imgs/radio.png') no-repeat;
		background-size:.36rem .36rem;
		background-position: center left;
	}
	.radio.active{
		background-image: url('~@/assets/imgs/pitchon.png')
	}
</style>