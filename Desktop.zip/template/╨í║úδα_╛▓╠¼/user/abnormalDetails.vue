<template>
	<div class="abnormalDetails">
		<div class="center flex jc ac abnormal cf relative"><img src="@/assets/imgs/icon30.png" alt="" class="mr10" style="width: .42rem;">异常</div>
		<div class="mlr_15 plr_15 cgf pb20" style="padding-top: 1.5rem; margin-top: -1.5rem;z-index: 10;">
			<div class="cr fz24 center pb30">5元</div>
			<div class="csb lh40">
				<span class="c6">旧电池编号</span>
				<span>659262</span>
			</div>
			<div class="csb lh40">
				<span class="c6">订单编号</span>
				<span>435345</span>
			</div>
			<div class="csb lh40">
				<span class="c6">租借时间</span>
				<span>2019年9月5日09:26:12</span>
			</div>
			<div class="csb lh40">
				<span class="c6">设备编号</span>
				<span>34534534</span>
			</div>
			<div class="csb lh40">
				<span class="c6">设备地址</span>
				<span>广东省</span>
			</div>
		</div>
		<div class="submitBtn2">异常申报</div>
	</div>
</template>

<script>
	export default{
		name:"abnormalDetails",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.abnormalDetails{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.abnormal{
		z-index: 11;
		height:3rem;
		background: url('~@/assets/imgs/icon29.png') no-repeat;
		background-size:100% 100%;
	}
</style>