<template>
	<div class="faultDetails oh">
		<div class="cgf br p12 m10">
			<div class="csb lh40">
				<span class="c9">设备编号</span> <span></span>
			</div>
			<div class="csb lh40">
				<span class="c9">设备柜号</span> <span></span>
			</div>
			<div class="csb lh40">
				<span class="c9">设备地址</span> <span></span>
			</div>
			<div class="csb lh40">
				<span class="c9">报障类型</span> <span></span>
			</div>
			<div class="lh40">
				<span class="c9">报障描述</span>
				<p>
					服务条款体报道，服务条款内容第二季度最后一周实服务条款内容的生产速度。服务条款内容，服务条款内容服务条款内容，服务条款内容。
				</p>
			</div>
			<div class="lh40">
				<span class="c9">描述图片</span>
				<div class="fsa">
					<img src="@/assets/imgs/title.png" style="width:32%;">
					<img src="@/assets/imgs/title.png" style="width:32%;">
					<img src="@/assets/imgs/title.png" style="width:32%;">
				</div>
			</div>
		</div>
		
	</div>
</template>

<script>
	export default{
		name:"faultDetails",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.faultDetails{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
</style>