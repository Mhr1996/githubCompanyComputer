<template>
	<div class="deposit">
		<div class="cgf center ac">
			<img src="@/assets/imgs/icon31.png" alt="" style="width:7rem;" class="mt40">
			<div class="flex lh50 w90 mauto">
				<span class="cf price mr10">60</span><span class="bold">押金(可退)</span>
			</div>
			<div class="submitBtn2">退回押金</div>
		</div>
	</div>
</template>

<script>
	export default{
		name:"deposit",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.deposit{
		min-height: 100vh;
		/*background-color: #f5f5f5;*/
	}

	.price{
		background: url('~@/assets/imgs/icon27.png') no-repeat;
		background-size:100%;
		width: 1.3rem;
	    font-size: .40rem;
	    padding-left: .3rem;
	    box-sizing: border-box;
	}
</style>