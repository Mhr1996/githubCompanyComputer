<template>
	<div class="devOps oh">
		<div class="cgf plr_15 mt50" style="margin-top: 1.6rem;">
			<div class="center">
				<img class="br50 mb10" src="@/assets/imgs/title.png">
				<p>运维员：姓名</p>	
			</div>
			<div class="lh75 bbeb"><img src="@/assets/imgs/icon1.jpg" class="mr10">设备列表</div>
			<div class="lh75 bbeb"><img src="@/assets/imgs/icon2.jpg" class="mr10">故障维修</div>
			<div class="lh75 bbeb"><img src="@/assets/imgs/icon3.jpg" class="mr10">设备调试</div>
		</div>
	</div>
</template>

<script>
	export default{
		name:"devOps",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.devOps{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.br50{
		width: 2rem;
		height: 2rem;
		margin-top: -1rem;
	}
	.bbeb img{
		width: .6rem;
		height: .6rem;
	}
</style>