<template>
	<div class="activationDevice">
		<div class="bbef csb plr_15 lh50 h50 cgf">
			<span>设备编号</span><input type="text" placeholder="请输入设备编号" class="flex1 c6 tr">
		</div>
		<div class="bbef csb plr_15 lh50 h50 cgf">
			<span>设备名称</span><input type="text" placeholder="请输入设备名称" class="flex1 c6 tr">
		</div>
		<div class="bbef csb plr_15 lh50 h50 cgf">
			<span>设备地址</span>
			<span class="flex1 tr c9">请输入</span>
			<img src="@/assets/imgs/ic34.png" alt="" class="img">
		</div>
		<div class="bbef csb plr_15 lh50 h50 cgf">
			<span>所属运营商</span>
			<span class="flex1 tr c9">点击选择运营商</span>
			<img src="@/assets/imgs/ic34.png" alt="" class="img">
		</div>
		<div class="submitBtn2 bold">激活设备</div>
	</div>
</template>

<script>
	export default{
		name:"activationDevice",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.activationDevice{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
</style>