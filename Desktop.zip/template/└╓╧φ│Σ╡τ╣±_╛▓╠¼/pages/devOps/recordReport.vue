<template>
	<div class="recordReport pt10 bz oh">
		<div class="cgf mb10 plr_15 ci lh40 h40">
			设备编号:123123
		</div>
		<div class="cgf p15">
			<p class="mb10">请选择记录来源</p>
			<div class="mb10 oh bz">
				<span class="item ib brde br">平台分配</span><span class="item ib brde br">运营商分配</span><span class="item ib brde br">用户电话反馈</span><span class="item ib brde br">其他</span>
			</div>
			<textarea name="" id="" cols="30" rows="10" class="w100 brde p15 bz br" placeholder="请输入...">
				
			</textarea>
			<img-up width="1.6rem" height="1.6rem" file="faultUp" @setImgFile="setImgFile" @delImgFile="delImgFile"></img-up>
			<div class="c9">最多上传4张</div>
		</div>
		<div class="submitBtn2 bold">提交</div>
	</div>
</template>

<script>
	import ImgUp from '@/components/ImgUpLoad'
	export default{
		name:"recordReport",
		components:{
			ImgUp
		},
		data(){
			return {
				imgId:[],
				imgSrc:[],
			}
		},
		created(){

		},
		methods:{
			setImgFile(imgFile){
		    	let formData = new FormData();
		    	formData.append('api_name','uploadPic');
		        formData.append('img',this.imgFile[this.imgFile.length-1]);
		        this.$toast.loading({duration:0, forbidClick:true, mask:true, loadingType:'spinner', message:'提交中...'});
				this.$http.post('/outside/User/api',formData,'multipart/form-data').then(res => {
					this.$toast.clear();

		        	if (res.code==1) {
		        		this.imgId[this.imgId.length]=res.data.id;
		        		this.imgSrc[this.imgSrc.length]=res.data.path;
		        		console.log(this.imgSrc)
		        		console.log(this.imgId)
		        		console.log(this.imgId.join())
		        	}else{
			        	this.$toast(res.msg);
		        	}
	      		})
		    },
		    delImgFile(index){
		    	this.imgSrc.splice(index,1);
		    }
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.recordReport{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.item{
		padding: .06rem .15rem; 
		margin-right: .15rem;
	}
</style>