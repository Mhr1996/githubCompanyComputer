<template>
	<div class="index bz oh">
		<div class="mt10 ">
			<div class="bbef flex cgf mb3 ptb_15 left right">
				<div class="center w33">
					<img src="@/assets/imgs/ic2.png" alt="" class="h6 mb10">
					<p>激活设备</p>
				</div>
				<div class="center w33">
					<img src="@/assets/imgs/ic3.png" alt="" class="h6 mb10">
					<p>故障维修</p>
				</div>
				<div class="center w33">
					<img src="@/assets/imgs/ic5.png" alt="" class="h6 mb10">
					<p>设备调试</p>
				</div>
			</div>
			<div class="bbef flex cgf mb10 ptb_15 left">
				<div class="center w33">
					<img src="@/assets/imgs/ic6.png" alt="" class="h6 mb10">
					<p>激活设备</p>
				</div>
				<div class="center w33">
					<img src="@/assets/imgs/ic7.png" alt="" class="h6 mb10">
					<p>故障维修</p>
				</div>
			</div>
		</div>
		<div class="submitBtn2">退出登录</div>
	</div>
</template>

<script>
	export default{
		name:"index",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.index{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.h6{
		height: .6rem;
	}
	.left{
		position: relative;
		&:after{
			@include after();
			top: 25%;
			left: 33.33%;
			width: .02rem;
			height: .8rem;
			background-color: #dcdcdc;
		}
	}
	.right{
		position: relative;
		&:before{
			position: absolute;
		    content: '';
		    z-index: 10;
		    top: 25%;
		    right: 33.33%;
		    width: .02rem;
		    height: .8rem;
		    background-color: #dcdcdc;
		}
	}
</style>