<template>
	<div class="troubleshooting oh">
		<div class="cgf lh40 cgf center csb mb15">
			<div class="h100 c9 fz16 w50" :class="{active:g.checked}" v-for="( g , index ) of list" :key="index" @click="switchTab(index)">{{g.name}}</div>
		</div>
		<div class="p12 cgf m15 br oh">
			<div class="csb mb10 bbef">
				<div class="pb10"><span class="mr5">设备编号：</span>222</div>
				<div class="cr pb10"> 开柜失败</div>
			</div>
			<div class="ptb_10"><span class="mr5">所属商家：</span>shop_name</div>
			<div class="pt10 pb20 bbef"><span class="mr5">设备地址：</span>广东东莞南城高盛科技大厦工商银行</div>
			<router-link 
				:to="{path:'Mt_FaultDetails'}" 
				class="btn lh40 brde r mt10 br center plr_5 btn2 cf"
			>
				立即维修
			</router-link>
		</div>
	</div>
</template>

<script>
	export default{
		name:"troubleshooting",
		components:{
		},
		data(){
			return {
				list:[
					{
						name:'待维修',
						checked:true,
						id:1
					},
					{
						name:'维修成功',
						checked:false,
						id:2
					}
				],
				finished : false,
				loading  : false,
				orderList: [],
				page     : 1
			}
		},
		created(){

		},
		methods:{
			getList(status='2'){
				let vis=this;
				vis.$http.post("/outside/staff/api",{
					api_name:"feedbackList",
					status:status,
					page: vis.page
				}).then(res => {
					if (res.code == 1) {
						let rd=res.data;
						vis.orderList=[...vis.orderList,...rd];
						if (rd.length<10) {
							vis.finished = true
						}
						vis.page++;
					}else{
						vis.$toast(res.msg);
						vis.finished = true;
					}
					vis.loading = false;
				})
			},
			switchTab(index){
				this.list.forEach((item,index) => {
	                item.checked=false;
	            });
				this.list[index].checked=true;

				this.page=1;
				this.orderList=[];
				// if(index==0){
				// 	this.getList();
				// }else{
				// 	this.getList('1');
				// }
			},
			navigation(g){
				let vis=this,map=vis.bMapTransQQMap(g.device_lng,g.device_lat);
				wx.openLocation({
                    latitude: map.lat*1, // 纬度，浮点数，范围为90 ~ -90
                    longitude: map.lng*1, // 经度，浮点数，范围为180 ~ -180。
                    name: g.shop_name, // 位置名
                    address: g.device_address, // 地址详情说明
                    scale: 14// 地图缩放级别,整形值,范围从1~28。默认为最大
                });
			},
	        bMapTransQQMap(lng,lat){ //百度转腾讯
	            let x_pi = 3.14159265358979324 * 3000.0 / 180.0;
	            let x = lng - 0.0065;
	            let y = lat - 0.006;
	            let z = Math.sqrt(x * x + y * y) - 0.00002 * Math.sin(y * x_pi);
	            let theta = Math.atan2(y, x) - 0.000003 * Math.cos(x * x_pi);
	            let lngs = z * Math.cos(theta);
	            let lats = z * Math.sin(theta);
	            return {
	                lng: lngs,
	                lat: lats
	            }
	        }
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.troubleshooting{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.active{
		color: #28b28b;
		position: relative;
		&:after{
			position:absolute;
			content: '';
			position: bottom center;
			@include br(.3rem);
		    bottom: 0;
		    width: .6rem;
		    left: 50%;
		    margin-left: -.3rem;
		    height: .08rem;
		    background-color: #28b28b;
		}
	}
	.btn1{
		width:1.8rem;
		background-color:#fff5e4;
		border-radius: .40rem;
		border: 0px solid;
		margin-right: .2rem;
	}
	.btn2{
		width:1.8rem;
		background-color:#f6a820;
		border-radius: .40rem;
		border: 0px solid;
	}
</style>