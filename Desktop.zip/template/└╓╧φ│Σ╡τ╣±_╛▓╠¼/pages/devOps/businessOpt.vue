<template>
	<div class="businessOpt oh bz">
		<van-search
		    v-model="name"
		    placeholder="请输入搜索的商家名"
		    show-action
		    shape="round"
		    background="#f5f5f5"
		    @search="onSearch"
		    @cancel="onCancel"
		/>
		<div class="mlr_15 cgf br p15 bz oh mb10 c6">
			<div class="mb15"> 商家名: 地址 </div>
			<div class="mb15"> 联系电话: 地址 </div>
			<div class="mb15"> 商家地址: 100元 </div>
			<div> 代理商: 100元 </div>
		</div>
		<div class="submitBtn2 bold">确认</div>
	</div>
</template>

<script>
	export default{
		name:"businessOpt",
		components:{
		},
		data(){
			return {
				name:''
			}
		},
		created(){

		},
		methods:{
			getList(){
				let vis=this;
				vis.$http.post("/outside/agent/api",{
					api_name:"shopList",
					name: vis.name,
					page: vis.page
				}).then(res => {
					if (res.code == 1) {
						let rd=res.data;
						for(let i=0;i<rd.length;i++){
							rd[i].ctime=vis.$tool.handleDate(Number(rd[i].ctime*1000),'.hm');
						}
						vis.orderList=[...vis.orderList,...rd];
						if (rd.length<10) {
							vis.finished = true
						}
						vis.page++;
					}else{
						vis.$toast(res.msg);
					}
					vis.loading = false;
				})
			},
			onSearch(){
				this.page=1;
				this.orderList.length=0;
				this.getList();
			},
			onCancel(){
				this.page=1;
				this.orderList.length=0;
				this.getList();
			}
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.businessOpt{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
</style>