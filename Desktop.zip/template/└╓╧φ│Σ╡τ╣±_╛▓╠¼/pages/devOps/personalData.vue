<template>
	<div class="personalData">
		<div class="bbef csb plr_15 lh50 h50 cgf">
			<span>账号</span><input type="text" placeholder="请输入账号" class="flex1 c6 tr">
		</div>
		<div class="bbef csb plr_15 lh50 h50 cgf">
			<span>运维员名称</span><input type="text" placeholder="请输入运维员名称" class="flex1 c6 tr">
		</div>
		<div class="bbef csb plr_15 lh50 h50 cgf">
			<span>所属代理商</span><input type="text" placeholder="请输入所属代理商" class="flex1 c6 tr">
		</div>
		<div class="bbef csb plr_15 lh50 h50 cgf">
			<span>手机号码</span><input type="text" placeholder="请输入手机号码" class="flex1 c6 tr">
		</div>
		<div class="bbef csb plr_15 lh50 h50 cgf">
			<span>修改密码</span>
			<img src="@/assets/imgs/ic34.png" alt="" class="img">
		</div>
	</div>
</template>

<script>
	export default{
		name:"personalData",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.personalData{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
</style>