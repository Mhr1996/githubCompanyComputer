<template>
	<div class="deviceDebug bz oh">
		<div class="cgf p15 mt10 bz">
			<div class="lh40 h40 plr_10 c9">
				设备编号: <span class="c3">12312312321</span>
			</div>
			<div class="lh40 h40 plr_10 c9">
				设备地址: <span class="c3">广东东莞南城高盛科技大厦工商银行02号</span>
			</div>
		</div>
		<div class="plr_15 mlr_10 h40 lh40 c6">
			请选择需要调试的具体柜号:
		</div>
		<div class="cgf plr_30">
			<div class="csb wrap">
				<div v-for="(g,index) of list" :key="index" class="boxNum brde br mlr_5_ mtb_10">
					{{g.id}}
				</div>
			</div>
			<div class="w100 lh40 h40 br40 center mtb_30 cr" style="border: 1px solid #ff0000;">开柜</div>
			<div class="csb pb30">
				<div class="cf w45 lh40 h40 br40 cgr center">插座通电</div>
				<div class="cf w45 lh40 h40 br40 cgy center">插座断电</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default{
		name:"deviceDebug",
		components:{
		},
		data(){
			return {
				list:[]
			}
		},
		created(){
			for(let i=1;i<25;i++){
				this.list[this.list.length]={
					id:i ,
					checked: false
				};
			}
		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.deviceDebug{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.boxNum{
		width: .8rem;
		height: .8rem;
		line-height: .8rem;
		text-align:center;
	}
	.br40{
		@include br(.4rem);
	}
	.cgr{
		background-color: #28b28b;
	}
	.cgy{
		background-color: #fcbc00;
	}
</style>