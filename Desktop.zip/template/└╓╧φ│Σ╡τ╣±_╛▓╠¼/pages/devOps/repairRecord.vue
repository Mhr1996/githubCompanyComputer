<template>
	<div class="repairRecord oh bz">
		<div class="cgf p15 mt10">
			<div class="lh40 h40 plr_10 c9">
				设备编号: <span class="c3">12312312321</span>
			</div>
			<div class="lh40 h40 plr_10 c9">
				设备地址: <span class="c3">广东东莞南城高盛科技大厦工商银行02号</span>
			</div>
		</div>
		<div class="plr_15 mlr_10 h40 lh40 c6">
			维修记录描述
		</div>
		<div class="cgf p15">
			<div class="brde br p15">
				<textarea name="" id="" cols="30" rows="10" class="w100  bz" placeholder="请描述您的维系记录内容"></textarea>
				<img-up width="1.6rem" height="1.6rem" file="faultUp" @setImgFile="setImgFile" @delImgFile="delImgFile"></img-up>
			</div>
			<div class="plr_15 h40 lh40 c9">*温馨提示:最多只能上传4张图片</div>
		</div>
		<div class="submitBtn2">提交记录</div>
	</div>
</template>

<script>
	import ImgUp from '@/components/ImgUpLoad'
	export default{
		name:"repairRecord",
		components:{
			ImgUp
		},
		data(){
			return {
				imgId:[],
				imgSrc:[]
			}
		},
		created(){

		},
		methods:{
			setImgFile(imgFile){
	    	let formData = new FormData();
	    	formData.append('api_name','uploadPic');
	        formData.append('img',this.imgFile[this.imgFile.length-1]);
	        this.$toast.loading({duration:0, forbidClick:true, mask:true, loadingType:'spinner', message:'提交中...'});
			this.$http.post('/outside/User/api',formData,'multipart/form-data').then(res => {
				this.$toast.clear();

	        	if (res.code==1) {
	        		this.imgId[this.imgId.length]=res.data.id;
	        		this.imgSrc[this.imgSrc.length]=res.data.path;
	        		console.log(this.imgSrc)
	        		console.log(this.imgId)
	        		console.log(this.imgId.join())
	        	}else{
		        	this.$toast(res.msg);
	        	}
      		})
	    },
	    delImgFile(index){
	    	this.imgSrc.splice(index,1);
	    }
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.repairRecord{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
</style>