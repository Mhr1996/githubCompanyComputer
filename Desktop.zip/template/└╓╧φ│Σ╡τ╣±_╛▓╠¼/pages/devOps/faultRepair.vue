<template>
	<div class="faultRepair oh">
		<div class="cgf br plr_15 m10">
			<div class="csb lh40 bbef">
				<span class="mr10 c9">设备编号:</span><input type="text" class="flex1 tr" disabled="disabled">
			</div>
			<div class="csb lh40">
				<span class="mr10">设备地址:</span><input type="text" class="flex1 tr" disabled="disabled">
			</div>
			<div class="csb lh40">
				<span class="mr10">报障原因:</span><input type="text" class="flex1 tr" disabled="disabled">
			</div>
			<div class="csb lh40">
				<span class="mr10">报障时间:</span><input type="text" class="flex1 tr" disabled="disabled">
			</div>
			<div class="csb lh40">
				<span class="mr10">维修状态:</span><input type="text" class="flex1 tr" disabled="disabled" :value="1?'维修成功':'暂未处理'">
			</div>
			<div class="lh40">
				<span>报障描述</span>
				<p></p>
			</div>
			<!-- <div class="lh40" v-if="rd.img.length>0">
				<span class="c9">描述图片</span>
				<div class="fsa">
					<img :src="g==''?offImg:g" style="width:32%; height:2rem;" v-for="(g,index) of rd.img" :key="index">
				</div>
			</div> -->
			<div class="csa mt20 pb30 bz">
				<div class="w40 br center lh36 cf" style="background-color:#28b28b; border-radius: .36rem;"  @click="go">填写维修记录</div>
				<div class="w40 br center lh36 cf" style="background-color:#f6a820; border-radius: .36rem;"  @click="sweep">调试设备</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default{
		name:"faultRepair",
		components:{
		},
		data(){
			return {
				rd:{
					img:[]
				},
				offImg: require('@/assets/imgs/add.jpg')
			}
		},
		created(){
			let vis=this;
			vis.$http.post("/outside/staff/api",{
				api_name:"feedbackInfo",
				id:vis.$route.query.id
			}).then(res => {
				if (res.code == 1) {
					res.data=res.data;
					res.data.ctime=vis.$tool.handleDate(Number(res.data.ctime*1000),'ss');
					vis.rd=res.data;
				}else{
					vis.$toast(res.msg);
				}
			})
		},
		methods:{
			go(){
				let vis=this;
				vis.$router.push({
					path:'/Mt_MaintenanceRecord',
					query:{
						id: vis.$route.query.id,
						macno: vis.rd.macno,
						address: vis.rd.device_address
					}
				})
			},
			sweep(){
				let vis=this;
				vis.$http.post("/outside/User/api",{
					api_name:"getTicket"
				}).then(res => {
					if (res.code == 1) {
						let timestamp= (new Date().getTime() / 1000).toFixed(0)
	                    ,nonceStr=Math.random().toString(36).substr(2),
	                    ticket=vis.$tool.wx_js(res.data,timestamp,nonceStr);

	                    console.log(res.data,ticket);
	                    wx.config({
	                        debug: false, // 开启调试模式,调用的所有api的返回值会在客户端//alert出来，若要查  看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
	                        appId: 'wx89604713d6c55662', // 必填，公众号的唯一标识
	                        timestamp: timestamp, // 必填，生成签名的时间戳
	                        nonceStr:  nonceStr, // 必填，生成签名的随机串
	                        signature: ticket ,// 必填，签名，见附录1
	                        jsApiList: [
	                            'scanQRCode',
	                            'getLocation',
	                            'openLocation'
	                        ] //    必填，需要使用的JS接口列表，所有JS接口列表见附录2
	                    });

	                    wx.ready(()=>{
	                        wx.scanQRCode({
			                    needResult: 1, // 默认为0，扫描结果由微信处理，1则直接返回扫描结果，
			                    scanType: ["qrCode","barCode"], // 可以指定扫二维码还是一维码，默认二者都有
			                    success: function (ret) {
			                        let macno=ret.resultStr.split("macno=")[1];
		                        	vis.$router.push({
		                        		path:'/Mt_DeviceInfo',
		                        		query:{macno}
		                        	})
			                    },
			                    complete(){
			                        if(this.scanner_onOff){
			                            WeixinJSBridge.call('closeWindow');
			                        }
			                    },
			                    error:function(err){
			                        alert(JSON.stringify(err));
			                    },
			                });
	                    })
					}else{
						vis.$toast(res.msg);
					}
				})
			}
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.faultRepair{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
</style>