<template>
	<div class="amamasmded">
	</div>
</template>

<script>
	export default{
		name:"amamasmded",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.amamasmded{
		min-height: 100vh;
		/*background-color: #f5f5f5;*/
	}
</style>