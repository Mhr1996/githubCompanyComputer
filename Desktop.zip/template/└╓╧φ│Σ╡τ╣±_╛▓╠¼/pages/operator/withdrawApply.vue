<template>
	<div class="withdrawApply oh bz">
		<div class="cgf br mlr_15 mt15">
			<div class="bbef  plr_15 h50 cca2 ptb_10">
				<div class="csb">
					<span>提现金额</span><div class="flex1 tl bold cr">￥200</div>
				</div>
				<div class="cr">
					手续费:2元(0.5%) , 实际到账:198元
				</div>
			</div>
			<div class="bbef csb plr_15 lh50 h50">
				<span>提现人</span><input type="text" placeholder="(不可编辑，即运营商联系人姓名)" class="flex1 c6 tr">
			</div>
			<div class="bbef csb plr_15 lh50 h50">
				<span>开户银行</span><input type="text" placeholder="请输入开户银行" class="flex1 c6 tr">
			</div>
			<div class="bbef csb plr_15 lh50 h50">
				<span>所属支行</span><input type="text" placeholder="请输入所属支行" class="flex1 c6 tr">
			</div>
			<div class="bbef csb plr_15 lh50 h50">
				<span>银行卡号</span><input type="text" placeholder="请输入银行卡号" class="flex1 c6 tr">
			</div>
			<div class="csb plr_15 lh50 h50">
				<span>联系电话</span><input type="text" placeholder="请输入联系电话" class="flex1 c6 tr">
			</div>
		</div>
		<div class="submitBtn2">确认</div>
	</div>
</template>

<script>
	export default{
		name:"withdrawApply",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.withdrawApply{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
</style>