<template>
	<div class="editPassword pt10 bz oh ">
		<div class="info">
			<div class="flex row border-bottom br phone cgf mb10">
				<input type="text" placeholder="请输入手机号" v-model="phone" Fv="0" FvInfo="手机号不能为空">
			</div>
			<div class="flex row border-bottom br cgf mb10 pw verCode">
				<input type="password" placeholder="请输入验证码" v-model="pw2" Fv="0" FvInfo="验证码不能为空">
				<validate @click="getCode"></validate>
			</div>
			<div class="flex row border-bottom br cgf mb10 pw">
				<input type="password" placeholder="重复密码" v-model="pw3" Fv="0" FvInfo="重复密码不能为空">
			</div>
		</div>
		<div class="submitBtn2">确认</div>
	</div>
</template>

<script>
	import validate from '@/components/validate'
	export default{
		name:"editPassword",
		components:{
			validate
		},
		data(){
			return {
				phone:'',
				pw2:'',
				pw3:'',
			}
		},
		created(){

		},
		methods:{
			sendVer(){
				let vis=this;
	            sendCode({
	                phone: vis.phone
	            }).then(res=>{
	                if(res.code==1){
	                	vis.$toast("发送成功，注意查收!");
	                }else{
	                    vis.$toast(res.msg)
	                }
	            })
			},
			getCode(cb){
				let re=/^1[0-9]{10}$/;
				if(!re.test(this.phone)){
					this.$toast("手机号格式不正确!");
					return;
				}
				cb(this.sendVer);
			}
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.editPassword{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.info{
		padding: 0 .28rem;
		box-sizing: border-box;
		background-color: #f8f8f8;
		.row{
			height: 1rem;
			line-height: 1rem;
			position: relative;
			padding-left: .9rem;
			&:after{
				position:absolute;
				content: '';
				width: .02rem;
				height: .24rem;
				background-color: #bfbfbf;
				left: .9rem;
				top:50%;
				margin-top: -.12rem;
			}
			input{
				flex:1;
				padding-left: .3rem;
			}
		}
		.phone{
		 	background: url('~@/assets/imgs/s.png') no-repeat .3rem #fff;
		 	background-size: 0.3rem;
		}
		.verCode{
			background: url('~@/assets/imgs/s.png') no-repeat .3rem #fff;
			background-size: 0.3rem;
		}
		.pw{
			background: url('~@/assets/imgs/s.png') no-repeat .3rem #fff;
			background-size: 0.3rem;
		}
	}
	.verBtn{
		z-index: 10;
		font-size:.26rem;
		width:1.9rem;    
		border-radius: 1rem;
    	right: .06rem;
    	color:#fff;
    	background-color:#28b28b;
    	top:.15rem;
	}
</style>