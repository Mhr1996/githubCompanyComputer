<template>
	<div class="withdrawRecord oh bz pt15">
		<div class="mlr_15 cgf br p15 bz oh mb15 c9">
			<div class="csb mb10">
				<div>
					提现人: <span class="c3">那么</span>
				</div>
				<span class="co">提现中</span>
			</div>
			<div class="mb10"> 银行卡号: <span class="c3">23090418515162</span> </div>
			<div class="mb10"> 提现金额: <span class="cr">100元</span> </div>
			<div> 申请时间: <span class="c3">2019-12-30 15:40:24</span> </div>
		</div>
		<div class="mlr_15 cgf br p15 bz oh mb15 c9">
			<div class="csb mb10">
				<div>
					提现人: <span class="c3">那么</span>
				</div>
				<span class="co">提现中</span>
			</div>
			<div class="mb10"> 银行卡号: <span class="c3">23090418515162</span> </div>
			<div class="mb10"> 提现金额: <span class="cr">100元</span> </div>
			<div> 申请时间: <span class="c3">2019-12-30 15:40:24</span> </div>
		</div>
		<div class="mlr_15 cgf br p15 bz oh mb15 c9">
			<div class="csb mb10">
				<div>
					提现人: <span class="c3">那么</span>
				</div>
				<span class="co">提现中</span>
			</div>
			<div class="mb10"> 银行卡号: <span class="c3">23090418515162</span> </div>
			<div class="mb10"> 提现金额: <span class="cr">100元</span> </div>
			<div> 申请时间: <span class="c3">2019-12-30 15:40:24</span> </div>
		</div>
	</div>
</template>

<script>
	export default{
		name:"withdrawRecord",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.withdrawRecord{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
</style>