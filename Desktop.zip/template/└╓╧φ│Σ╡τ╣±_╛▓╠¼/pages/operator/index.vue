<template>
	<div class="index oh bz">
		<div class=" mtb_10 mlr_10 p15 bz cf br wrap flex" style="background-color:#28b28b;">
			<div class="w50 center h50 cca2 ptb_6 bz">
				<p class="bold fz18">10258</p>
				<span>今日收益(元)</span>
			</div>
			<div class="w50 center h50 cca2 ptb_6 bz">
				<p class="bold fz18">258</p>
				<span>今日营业额(元)</span>
			</div>
			<div class="w50 center h50 cca2 ptb_6 bz">
				<span>总收益(元)</span>
				<p class="bold fz18">10258</p>
			</div>
			<div class="w50 center h50 cca2 ptb_6 bz">
				<span>总营业额(元)</span>
				<p class="bold fz18">10258</p>
			</div>
		</div>
		<div class="mb10 csf mlr_10 p15 bz br cgf flex center">
			<div class="h100 cca2 w50">
				<p class="fz22 bold mb10">10258</p>
				<span>设备数量(台)</span>
			</div>
			<div class="h100 cca2 w50">
				<p class="fz22 bold mb10">10258</p>
				<span>实施占用率(%)</span>
			</div>
		</div>

		<div class="cca2 mb10 csf mlr_10 plr_15 bz br cgf">
			<div class="lh60 h60 bbef csb ">
				<span>个人资料</span><img src="@/assets/imgs/ic34.png" alt="">
			</div>
			<div class="lh60 h60 bbef csb ">
				<span>我的收益</span><img src="@/assets/imgs/ic34.png" alt="">
			</div>
			<div class="lh60 h60 bbef csb ">
				<span>我的钱包</span><img src="@/assets/imgs/ic34.png" alt="">
			</div>
			<div class="lh60 h60 csb ">
				<span>设备列表</span><img src="@/assets/imgs/ic34.png" alt="">
			</div>
		</div>

		<div class="submitBtn2 bold">退出登录</div>
	</div>
</template>

<script>
	export default{
		name:"index",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.index{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
</style>