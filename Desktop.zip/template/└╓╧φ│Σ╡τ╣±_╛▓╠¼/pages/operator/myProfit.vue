<template>
	<div class="myProfit oh bz">
		<div class="cgf m10 br center separate relative">
			<div class="flex ladder relative">
				<div class="w50 h80 cca2 ptb_10 bz">
					<p>今日收益(元)</p>
					<span class="fz22 bold">0.00</span>
				</div>
				<div class="w50 h80 cca2 ptb_10 bz">
					<p>今日营业额(元)</p>
					<span class="fz22 bold">0.00</span>
				</div>
			</div>
			<div class="flex ladder relative">
				<div class="w50 h80 cca2 ptb_10 bz">
					<p>昨日收益(元)</p>
					<span class="fz22 bold">0.00</span>
				</div>
				<div class="w50 h80 cca2 ptb_10 bz">
					<p>昨日营业额(元)</p>
					<span class="fz22 bold">0.00</span>
				</div>
			</div>
			<div class="flex ladder relative">
				<div class="w50 h80 cca2 ptb_10 bz">
					<p>上月收益(元)</p>
					<span class="fz22 bold">0.00</span>
				</div>
				<div class="w50 h80 cca2 ptb_10 bz">
					<p>上月营业额(元)</p>
					<span class="fz22 bold">0.00</span>
				</div>
			</div>
			<div class="flex ladder relative">
				<div class="w50 h80 cca2 ptb_10 bz">
					<p>总收益(元)</p>
					<span class="fz22 bold">0.00</span>
				</div>
				<div class="w50 h80 cca2 ptb_10 bz">
					<p>总营业额(元)</p>
					<span class="fz22 bold">0.00</span>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default{
		name:"myProfit",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.myProfit{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.separate{
		&:after{
			position: absolute;
		    left: 50%;
		    content: '';
		    top: 10%;
		    width: .02rem;
		    height: 80%;
		    z-index: 10;
		    background-color: #eeeeee;
		}
	}
	.ladder{
		&:after{
			position: absolute;
		    left: 15%;
		    content: '';
		    bottom:0;
		    width: 70%;
		    height: .02rem;
		    z-index: 10;
		    background-color: #eeeeee;
		}
	}
</style>