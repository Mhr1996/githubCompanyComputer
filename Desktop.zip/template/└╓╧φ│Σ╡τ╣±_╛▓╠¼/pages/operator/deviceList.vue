<template>
	<div class="deviceList oh bz">
		<van-search
		    v-model="name"
		    placeholder="请输入搜索的商家名"
		    show-action
		    shape="round"
		    background="#f5f5f5"
		    @search="onSearch"
		    @cancel="onCancel"
		/>
	  	<div class="csb lh50 h50 c9 mlr_15 cgf bold mb5">
	  		<div :class="{'active':isActive==index}" class="flex1 center" 
			v-for="(g,index) of type" 
			:key="index"
			@click="isActive=index">
				{{g.name}}
			</div>
	  	</div>
		<div class="mlr_15 cgf br p15 bz oh mb10 c6">
			<div class="csb mb15">
				<div> 设备编号: 123123 </div>
				<span class="co">在线</span>
			</div>
			<div class="mb15"> 设备地址: 地址 </div>
			<div class="mb15"> 设备营业额: 100元 </div>
			<div class="mb15"> 收益分润: 100元 </div>
			<div> 添加时间: 2019-12-30 15:40:24 </div>
		</div>
		<div class="mlr_15 cgf br p15 bz oh mb10 c6">
			<div class="csb mb15">
				<div> 设备编号: 123123 </div>
				<span class="co">在线</span>
			</div>
			<div class="mb15"> 设备地址: 地址 </div>
			<div class="mb15"> 设备营业额: 100元 </div>
			<div class="mb15"> 收益分润: 100元 </div>
			<div> 添加时间: 2019-12-30 15:40:24 </div>
		</div>
	</div>
</template>

<script>
	export default{
		name:"deviceList",
		components:{
		},
		data(){
			return {
				name:'',
				isActive:'0',
				type:[{name: '在线'}, {name: '离线'}, {name: '异常'} ],
				finished : false,
				loading  : false,
				orderList: [],
				page     : 1
			}
		},
		created(){

		},
		methods:{
			getList(){
				let vis=this;
				vis.$http.post("/outside/agent/api",{
					api_name:"shopList",
					name: vis.name,
					page: vis.page
				}).then(res => {
					if (res.code == 1) {
						let rd=res.data;
						for(let i=0;i<rd.length;i++){
							rd[i].ctime=vis.$tool.handleDate(Number(rd[i].ctime*1000),'.hm');
						}
						vis.orderList=[...vis.orderList,...rd];
						if (rd.length<10) {
							vis.finished = true
						}
						vis.page++;
					}else{
						vis.$toast(res.msg);
					}
					vis.loading = false;
				})
			},
			onSearch(){
				this.page=1;
				this.orderList.length=0;
				this.getList();
			},
			onCancel(){
				this.page=1;
				this.orderList.length=0;
				this.getList();
			}
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.deviceList{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.active{
		color: #28b28b;
		position: relative;
		&:after{
			position: absolute;
		    left: 0;
		    content: '';
		    z-index: 10;
			width: .3rem;
			height: .06rem;
			background-color: #28b28b;
			bottom: 0;
			left: 50%;
			margin-left: -.15rem;
		}
	}
</style>