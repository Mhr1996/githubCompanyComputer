<template>
	<div class="withdrawInfo pt15 bz oh">
		<div class="cgf br mlr_15">
			<div class="bbef csb plr_15 lh50 h50">
				<span>提现人</span><input type="text" placeholder="(不可编辑，即运营商联系人姓名)" class="flex1 c6 tr">
			</div>
			<div class="bbef csb plr_15 lh50 h50">
				<span>开户银行</span><input type="text" placeholder="请输入开户银行" class="flex1 c6 tr">
			</div>
			<div class="bbef csb plr_15 lh50 h50">
				<span>所属支行</span><input type="text" placeholder="请输入所属支行" class="flex1 c6 tr">
			</div>
			<div class="bbef csb plr_15 lh50 h50">
				<span>银行卡号</span><input type="text" placeholder="请输入银行卡号" class="flex1 c6 tr">
			</div>
			<div class="csb plr_15 lh50 h50">
				<span>联系电话</span><input type="text" placeholder="请输入联系电话" class="flex1 c6 tr">
			</div>
		</div>
		<div class="submitBtn2">确认</div>
	</div>
</template>

<script>
	import { superJoggle } from '@/api'
	export default{
		name:"withdrawInfo",
		components:{
		},
		data(){
			return {
			}
		},
		created(){
			let vis=this;
		},
		methods:{
            submit(){
            	let vis=this;
            	if(vis.$tool.formVerification()){
            		superJoggle({
						api_name: 'deviceEdit',
						macno: vis.macno,
						color: vis.color,
						title: vis.select[2].title,
						store_id: vis.select[1].store_id,
						hatch_id: vis.select[2].id
					}).then(res=>{
					    if(res.code==1){
					    	vis.$toast('设置成功!');
					    	setTimeout(()=>{
					    		vis.$router.go(-1);
					    	},3000);
					    }else{
					        vis.$toast(res.msg)
					    }
					})
            	}
            }
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.withdrawInfo{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.img{
		width: .24rem;padding: .2rem 0;
	}
	.editBtny{
		padding: .1rem;
		background-color: #fcbc00;
		color: #fff;
		line-height: .2rem;
	}
</style>