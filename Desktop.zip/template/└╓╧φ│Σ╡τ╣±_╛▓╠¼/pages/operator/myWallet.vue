<template>
	<div class="myWallet bz oh">
		<div class="br mlr_15 pt30 plb_50 content mt15 cf bz">
			<p class="center fz45 mb5">￥10000</p>
			<div class="center mb10">可提现金额(元)</div>
			<div class="center mb10">
				<span class="withdrawBtn ib">提现</span>
			</div>
			<div class="csb w70 mauto center pt10 border_">
				<div class="cca2">
					<p class="mb10">已提现金额(元)</p>
					<span class="fz24">0.00</span>
				</div>
				<div class="cca2">
					<p class="mb10">总收益(元)</p>
					<span class="fz24">0.00</span>
				</div>
			</div>
		</div>
		<div class="cgf br mlr_15 mt10">
				<div class="csb plr_15 lh50 h50">
				<span>提现记录</span>
				<img src="@/assets/imgs/ic34.png" alt="" class="img">
			</div>
		</div>
	</div>
</template>

<script>
	export default{
		name:"myWallet",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.myWallet{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.content{
		background: url('~@/assets/imgs/ic1.png') no-repeat;
		background-size: 100% 100%;
		height: 4.16rem;
	}
	.fz45{
		font-size: .8rem;
	}
	.withdrawBtn{
		background-color: #fff;
		color: #28b28b;
		padding: .06rem .24rem ;
		@include br(.2rem);
	}
	.border_{
		border-top: 1px solid #fff;
		position: relative;
		&:after{
			@include after();
			width: 1px;
		    height: 100%;
		    background-color: #fff;
		    left: 50%;
		    top: 0;
		}
	}
</style>