import router from '../../router.js'
import { getToken } from '@/api'
//微信支付宝授权
export function author() {
    if(isWX_Allipay() == 'WX'){  // 微信客户端
        router.replace({path: '/login'})
        // if(!getUrlParam('code')){
        //     window.location.replace("https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx34f9014a32bf5e44&redirect_uri="+encodeURIComponent(window.location.href)+"&response_type=code&scope=snsapi_userinfo&state=1#wechat_redirect");
        // }else if(getUrlParam('code')){
        //     let params = {
        //         code : getUrlParam('code')
        //     }
        //     getToken(params).then(res=>{
        //         //获取openID 将openID存起来
        //         router.replace({path: '/login'})
        //     }).catch(()=>{})
        // }
    }else{
        alert('请在微信环境下使用');
    }
}

export const getUrlParam = (name,url) => {//获取url参数
    url = url || window.location.href
    if(url.includes(name)){
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)"); //构造一个含有目标参数的正则表达式对象
        var r = url.split('?')[1].substr(0).match(reg); //匹配目标参数
        if (r != null) return unescape(r[2]);
        return null; //返回参数值
    }
    return false
};

/*
* 路由地址截取
* @param  {string}  name        要获取路由？的后面参数名
* 这个主要用作在外部js使用,支付宝授权的时候会将拼接规则带在路由后面。
*/
export const getUrlKey = (name) => {
    return  decodeURIComponent((new RegExp('[?|&]' + name + '=' + '([^&;]+?)(&|#|;|$)').exec(location.href) || [, ""])[1].replace(/\+/g, '%20')) || ''
};

//判断是否未微信或者支付宝浏览器
export const isWX_Allipay = () => {
    if (window.navigator.userAgent.toLowerCase().match(/MicroMessenger/i) == 'micromessenger') {
        return 'WX';
    } else if (window.navigator.userAgent.toLowerCase().match(/AlipayClient/i) == 'alipayclient') {
        return 'Allipay';
    } else {
        return 'Others';
    }
}