import axios from 'axios';
import qs from 'qs';
import store from '@/store'
import router from '../../router.js'
import tool from './tool.js'
import { author } from "./author"
//设置超时时间
axios.defaults.timeout = 20000;
axios.defaults.baseURL = process.env.NODE_ENV === "development" ? 'http://szmqndj.app.xiaozhuschool.com' : ''

//对外接口
export function request({
    method,
    url,
    params,
    form
}) {
    // 请求参数类型
    let formData = form ? "multipart/form-data" : "application/x-www-form-urlencoded;charset=UTF-8"
    axios.defaults.headers.post['Content-Type'] = formData;

    // if(tool.getStore("login_token")){
    //     console.log("有token 进入")
    //     params.token = tool.getStore("login_token");
    //     if(/Bs_/g.test(router.history.current.name)){
    //         console.log("匹配1")
    //         params.token = tool.getStore("business_token");
    //     }else if(/Mt_/g.test(router.history.current.name)){
    //         console.log("匹配2")
    //         params.token = tool.getStore("maintain_token");
    //     }else{
    //         console.log("匹配3")
    //         params.token = tool.getStore("agent_token");
    //     }
    // }

    if (method == 'get') {
        return get(url, params);
    } else if (method == 'post') {
        return post(url, params);
    } else if (method == 'postJson') {
        return postJson(url, params);
    }
}

// 封装get方法
function get(url, params) {
    return new Promise((resolve, reject) => {
        axios.get(url, params).then(res => {
            try {
                resolve(res.data);
            } catch (error) {
                throw error.data
            }
        }).catch(err => {
            reject(err.data);
        })
    });
}

// 封装post方法
function post(url, params) {
    return new Promise((resolve, reject) => {
        axios.post(url, params?qs.stringify(params):'').then(res => {
            resolve(res.data);
        }).catch(err => {
            reject(err);
        })

    });
}

// 封装post方法
function postJson(url, params) {
    return new Promise((resolve, reject) => {
        axios.post(url, params).then(res => {
            resolve(res.data);
        }).catch(err => {
            reject(err);
        })

    });
}

//请求拦截(请求发出前处理请求)
/* axios.interceptors.request.use(
    confirm => {
        //将token放入header，这里用Vuex把token放在store中，取出
        const token = store.state.token;
        token && (config.headers.Authorization = token);
        return config;
    },
    error => {
        return Promise.error(error);
    }
) */

// 响应拦截器（处理响应数据）
axios.interceptors.response.use(
    response => {
        console.log(response,'=========2')
        const data = response.data;
        switch (data.code){
            case 1:
                return response
                break;
            case 10004:
                //localStorage.clear()
                if (process.env.NODE_ENV !== 'development')
                    return author()
                return new Promise(() => {});
                break;
            }
        if (response.status === 200) {
            return Promise.resolve(response);
        } else {
            // 可以由后台编辑状态码区分不同情况，做不同的逻辑处理
            return Promise.reject(response);
        }
    },
    error => {
        // 请求失败，可根据error.response.status统一处理一些界面逻辑
        return Promise.reject(error.response);
    }
)