let fm = (value) => {
  return Number(value) == 0 ? 0 : '￥' + Number(value).toFixed(2);
}

let handleDate = (date,ymd)=> {
  if(date==""||date==null){return ""; }
  date=new Date(date);
  var year = date.getFullYear()
  ,month = date.getMonth() + 1
  ,day = date.getDate()
  ,hour = date.getHours()
  ,minute = date.getMinutes()
  ,second = date.getSeconds();
  if (10 > month) {
    month = "0" + month;
  }
  if (10 > day) {
    day = "0" + day;
  }
  if (10 > hour) {
    hour = "0" + hour;
  }
  if (10 > minute) {
    minute = "0" + minute;
  }
  if (10 > second) {
    second = "0" + second;
  }
  if(ymd=="ss"){
    return year + "-" + month + "-" + day+ " " + hour+ ":" + minute + ":" + second;
  }else if(ymd=='md') {
    return month + "月" + day+'日';
  }else if(ymd=='ff') {
    return hour+ ":" + minute ;
  }else if(ymd=='.hm') {
    return  year + "." + month + "." + day+ " " + hour+ ":" + minute;
  }else if(ymd) {
    return year + "-" + month + "-" + day;
  }else{
    return year + "-" + month + "-" + day+ " " + hour+ ":" + minute;
  }
}

export {
  fm,
  handleDate
} //默认导出
