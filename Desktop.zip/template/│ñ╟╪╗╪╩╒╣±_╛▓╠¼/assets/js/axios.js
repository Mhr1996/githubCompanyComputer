import axios from 'axios'
import qs from 'qs'
import Tool from './tool'
import { author } from "@/assets/js/author"
import router from '../../router.js'

const mainUrl = 'http://szmqndj.app.xiaozhuschool.com'

function getUrl(url) {
    /* 判断传入的url路径是否是http开头 */
    if (url.startsWith('http') || url.startsWith('https')) {
        return url
    }
    /* 不是http开头，进行路径的拼接 */
    return `${mainUrl}${url}`
}

const Http = {
    get: (url, query) => new Promise((resolve, reject) => {
        /* new Promise 是为进行在vue store里面进行异步传值 */
        var path = getUrl(url)
        /* get请求 */
        axios.get(path, {
            params: query
        }).then((res1, error) => {
            if (res1) {
                resolve(res1)
            } else {
                reject(error)
            }
        })
    }),

    post: (url, query , contentType) => new Promise((resolve, reject) => {
        /* new Promise 是为进行在vue store里面进行异步传值 */
        var path = getUrl(url)
        //query.token = query.token ? query.token : localStorage.getItem('token') ? localStorage.getItem('token') : '';
        if(localStorage.getItem("business_token")||localStorage.getItem("maintain_token")||localStorage.getItem("agent_token")){
            console.log("有token 进入")
            if(/Bs_/g.test(router.history.current.name)){
                console.log("匹配1")
                query.token = localStorage.getItem("business_token");
            }else if(/Mt_/g.test(router.history.current.name)){
                console.log("匹配2")
                query.token = localStorage.getItem("maintain_token");
            }else{
                console.log("匹配3")
                query.token = localStorage.getItem("agent_token");
            }
        }

        /* post请求 */
        axios({
            url: path,
            method: 'post',
            data: contentType?query:qs.stringify(query),
            headers: {
                'Content-Type': contentType?contentType:'application/x-www-form-urlencoded' //数据被编码为名称/值对。这是标准的编码格式
            }
        }).then((res1, error) => {
            if (res1) {
                if(res1.data.code==401){
                    Tool.removeStore("token");
                    window.location.reload();
                    return;
                }
                resolve(res1.data)
                console.log('%c' + res1.data.code, 'color:red;');
            } else {
                reject(error)
            }
        })
    }),
    jsonp: (url, query) => new Promise((resolve, reject) => {
        /* new Promise 是为进行在vue store里面进行异步传值 */
        /* new Promise 是为进行在vue store里面进行异步传值 */
        var path = getUrl(url)
        /* get请求 */
        axios.post(path, {
            params: query
        }).then((res1, error) => {
            if (res1) {
                resolve(res1)
            } else {
                reject(error)
            }
        })
    }),
}

export default Http
