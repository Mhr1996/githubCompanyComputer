<template>
	<div class="commodityOrder">
		<div class="title csa mb15 cgf">
			<div v-for="(item,index) in title" :class="{'active':isActive==index}" @click="changeType(item,index)">{{item.name}}<span></span></div>
		</div>
		<div class="cgf mb10" >
			<div class="csb plr_15 lh40 h40">
				<span class="c9">订单编号</span><span>已支付</span>
			</div>
			<div class="csb cgg plr_15 ptb_10">
				<img src="@/assets/imgs/title.png" alt="" class="wh8 mr10">
				<div class="flex1 csb2" style="height: 1.6rem;">
					<div class="fz16">name</div>
					<div class="tr c9">x1</div>
					<div class="c9">环保金:18</div>
				</div>
			</div>
			<div class="tr plr_15 lh40 h40">
				合计:￥198.00
			</div>
		</div>
		<div class="cgf mb10" >
			<div class="csb plr_15 lh40 h40">
				<span class="c9">订单编号</span><span>已支付</span>
			</div>
			<div class="csb cgg plr_15 ptb_10">
				<img src="@/assets/imgs/title.png" alt="" class="wh8 mr10">
				<div class="flex1 csb2" style="height: 1.6rem;">
					<div class="fz16">name</div>
					<div class="tr c9">x1</div>
					<div class="c9">环保金:18</div>
				</div>
			</div>
			<div class="tr plr_15 lh40 h40">
				合计:￥198.00
			</div>
		</div>
	</div>
</template>

<script>
	export default{
		name:"commodityOrder",
		components:{
		},
		data(){
			return {
				isActive:0,
				title:[
					{name:"全部"},
					{name:"代发货"},
					{name:"待收货"},
					{name:"已完成"}
				]
			}
		},
		created(){

		},
		methods:{
			changeType(item,index){
				this.isActive=index;
			}
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.commodityOrder{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.title{
		height:45px;
		display:flex;
		width:100%;
		line-height:45px;
		font-weight:bold;
		color: #999;
	}
	.title div{
		text-align:center;
	}
	.title div.active{
		color:#00a0e9;
		position:relative;
	}
	.title div.active span{
		display:inline-block;
		position:absolute;
		width:.4rem;
		height:3px;
		@include br();
		background-color: #00a0e9;
		bottom:.15rem;
		left:50%;
		margin-left:-.2rem;
	}
	.wh8{
		width: 1.6rem;
		height: 1.6rem;
	}
	.cgg{
		background-color:#fafafa;
	}
</style>