<template>
	<div class="index">
		<div class="csb ptb_30 mlr_15 bz ac">
			<div class="cca2 ac fc">
				<p class="bold fz22 bold mb10">姓名</p>
				<span class="deliveryCard br">绑定投递卡&gt;</span>
			</div>
			<img src="@/assets/imgs/title.png" alt="" class="br50 mr15" style="height: 1.5rem;">
		</div>
		<div class="mlr_15 cgf br oh bz mt20 bst2">
			<div class="flex ac fc csa mtb_20">
				<div class="bold"><img src="@/assets/imgs/ic6.png" alt="" class="w28 br mr10">环保金</div>
			</div>
			<div class="csa mt10 mb15">
				<div class="cca2">
					<span class="fz30 center mb5 bold">22.8</span>
					<span class="c9">当前环保金</span>
				</div>
				<div class="cca2">
					<span class="fz30 center mb5 bold">10</span>
					<span class="c9">投递次数</span>
				</div>
				<div class="cca2">
					<span class="fz30 center mb5 bold">765</span>
					<span class="c9">累计收益</span>
				</div>
			</div>
		</div>
		<div class="csa mlr_15 wrap mt30">
			<div class="cca2 center ac fc w25 pb20" v-for="(g,index) of type" :key="index">
				<div class="icon csa fc mb10" style="height: .6rem;"><img :src="g.img" alt="" class="w28"></div>
				<span>{{g.name}}</span>
			</div>
		</div>
	</div>
</template>

<script>
	export default{
		name:"index",
		components:{
		},
		data(){
			return {
				type:[
					{
						name:'我的邀请',
						img: require('@/assets/imgs/icp1.png')
					},
					{
						name:'礼券',
						img: require('@/assets/imgs/icp2.png')
					},{
						name:'商城',
						img: require('@/assets/imgs/icp3.png')
					},{
						name:'我的订单',
						img: require('@/assets/imgs/icp4.png')
					},{
						name:'意见反馈',
						img: require('@/assets/imgs/icp5.png')
					},{
						name:'系统设置',
						img: require('@/assets/imgs/icp6.png')
					},{
						name:'帮助中心',
						img: require('@/assets/imgs/icp7.png')
					},{
						name:'关于我们',
						img: require('@/assets/imgs/icp8.png')
					}
				]
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.index{
		min-height: 100vh;
		/*background-color: #f5f5f5;*/
	}
	.deliveryCard{
		padding:.1rem;
		color: #fff;
		background-color: #59360b;
	}
	.w28{
		width: .56rem;
	}
</style>