<template>
	<div class="giftVoucher">
		<div class="title csa mb15 cgf bbef">
			<div v-for="(item,index) in title" :class="{'active':isActive==index}" @click="changeType(item,index)">{{item.name}}<span></span></div>
		</div>
		<div>
			<div class="mlr_15 cca2 bz plr_20 item pb35 pt15 mb10">
				<p class="cf fz18 bold">环保金</p>
				<p class="cf">有效日期2019-12-10~2019-12-10</p>
			</div>
			<div class="mlr_15 cca2 bz plr_20 item pb35 pt15 mb10">
				<p class="cf fz18 bold">环保金</p>
				<p class="cf">有效日期2019-12-10~2019-12-10</p>
			</div>
			<div class="mlr_15 cca2 bz plr_20 item pb35 pt15 mb10">
				<p class="cf fz18 bold">环保金</p>
				<p class="cf">有效日期2019-12-10~2019-12-10</p>
			</div>
			<div class="mlr_15 cca2 bz plr_20 item grey pb35 pt15 mb10">
				<p class="cf fz18 bold">环保金</p>
				<p class="cf">有效日期2019-12-10~2019-12-10</p>
			</div>
		</div>
	</div>
</template>

<script>
	export default{
		name:"giftVoucher",
		components:{
		},
		data(){
			return {
				isActive:0,
				title:[
					{name:"未使用"},
					{name:"已使用"},
					{name:"已过期"}
				]
			}
		},
		created(){

		},
		methods:{
			changeType(item,index){
				this.isActive=index;
			}
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.giftVoucher{
		min-height: 100vh;
		/*background-color: #f5f5f5;*/
	}
	.title{
		height:45px;
		display:flex;
		width:100%;
		line-height:45px;
		font-weight:bold;
		color: #999;
	}
	.title div{
		text-align:center;
	}
	.title div.active{
		color:#00a0e9;
		position:relative;
	}
	.title div.active span{
		display:inline-block;
		position:absolute;
		width:.4rem;
		height:3px;
		@include br();
		background-color: #00a0e9;
		bottom:.15rem;
		left:50%;
		margin-left:-.2rem;
	}
	.item{
		height: 2.13rem;
		background: url('~@/assets/imgs/ic54.png') no-repeat;
		background-size: 100% 100%;
	}
	.item.grey{
		background: url('~@/assets/imgs/ic53.png') no-repeat;
		background-size: 100% 100%;
	}
</style>