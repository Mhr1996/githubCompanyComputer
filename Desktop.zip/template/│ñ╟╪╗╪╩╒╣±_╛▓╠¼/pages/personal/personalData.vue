<template>
	<div class="personalData oh bz">
		<div class="csb plr_20 cgf bbef mt10 mb10" style="height:1.6rem">
			<span>头像</span>
			<img src="@/assets/imgs/title.png" class="br50" style="width: 1.1rem;height: 1.1rem;"/>
		</div>
		<div class="csb plr_20 lh50 cgf bbef">
			<span>昵称</span>
			<span class="c9">阿萨德</span>
		</div>
		<div class="csb plr_20 lh50 cgf mb10">
			<span>登录手机号</span>
			<span class="c9">ad</span>
		</div>
		<div class="csb plr_20 lh50 cgf bbef rj mb10">
			<span>投递卡</span>
			<span class="c9">123123123</span>
		</div>
		<div class="csb plr_20 lh50 cgf bbef rj mb10">
			<span>实名认证</span>
			<span class="c9">123123123</span>
		</div>
		<div class="csb plr_20 lh50 cgf bbef rj mb10">
			<span>人脸上传</span>
			<span class="c9">上传后可以人脸识别登录安卓APK</span>
		</div>
	</div>
</template>

<script>
	export default{
		name:"personalData",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.personalData{
		min-height: 100vh;
		background-color: #f5f5f5;
	}

	.unbinding {
	    width: .76rem;
	    @include br();
	    text-align: center;
	    color: #fc846b;
	    line-height: .48rem;
	    border: 1px solid #fc846b;
	}

	.rj {
	    background-image: url('~@/assets/imgs/ic34.png');
	    background-repeat: no-repeat;
	    background-size: 6px 11px;
	    background-position: 7.2rem;
	}
</style>