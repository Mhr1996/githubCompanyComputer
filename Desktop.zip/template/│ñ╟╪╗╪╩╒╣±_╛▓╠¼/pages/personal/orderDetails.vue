<template>
	<div class="orderDetails bz oh">
		<div class="banner pl20">
			<img src="@/assets/imgs/bicycle.png" />
		</div>
		<div class="mlr_15 br cgf bst2 plr_15 radioGrey">
			<div class="ptb_15 bz bbef center">
				<div class="status mb10">待收货</div>
				<div class="c6 mb10 bold">实付款：<span class="fz18 bold" style="color:#ce351c;">环保金</span></div>
				<div class="c9">商家已发货</div>
			</div>
			<div class="ptb_15 plr_30">
				<div class="mb10 flex fc">
					<img src="@/assets/imgs/ic58.png" alt="" class="mr10 w_icon">
					陈跳跳 156****5959
				</div>
				<div class="flex fc">
					<img src="@/assets/imgs/address.png" alt="" class="mr10 w_icon">广东省东莞是南城区莫扎特街道303号
				</div>
			</div>
		</div>
		<div class="cgf mlr_15 ptb_15 mt20 br">
			<div class="csb cgg plr_15 ptb_10 mb20">
				<img src="@/assets/imgs/title.png" alt="" class="wh8 mr10">
				<div class="flex1 csb2" style="height: 1.6rem;">
					<div class="fz16">name</div>
					<div class="tr c9">x1</div>
					<div class="c9">环保金:18</div> 
				</div>
			</div>
			<div class="csb plr_15 mb10">
				<span class="c9">快递运费</span><span>免费包邮</span>
			</div>
			<div class="csb plr_15 mb10">
				<span class="c9">合计金额</span><span>￥151</span>
			</div>
			<div class="csb plr_15 mb10 bbef pb20">
				<span class="c9">优惠券抵扣</span><span>￥1515</span>
			</div>
			<div class="csb plr_15">
				<span class="c9">实付款</span><div>合计: <span style="color:#ce351c;">￥158.88</span></div>
			</div>
		</div>
		<div class="mt20 cgf mlr_15 p15 mb20">
			<div class="mb10">
				<span class="c9 mr10">订单编号</span><span>14521545154515415</span>
			</div>
			<div class="mb10">
				<span class="c9 mr10">下单时间</span><span>2019-12-10 18:57</span>
			</div>
			<div class="mb10">
				<span class="c9 mr10">付款时间</span><span>2019-12-10 18:57</span>
			</div>
			<div class="mb10">
				<span class="c9 mr10">支付方式</span><span>环保金支付</span>
			</div>
			<div>
				<span class="c9 mr10">发货时间</span><span>2019-12-10 18:57</span>
			</div>
		</div>
	</div>
</template>

<script>
	export default{
		name:"orderDetails",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.orderDetails{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.banner{
		overflow: hidden;
		margin-top: .4rem;
		img{
			width: 65%;
			min-height:1.276rem
		}
	}
	.w_icon{
		width: .3rem;
	}
	.radioGrey{
		position: relative;
		&:after{
			position: absolute;
		    content: '';
		    z-index: 10;
		    top: 1.75rem;
		    width: .15rem;
		    height: .3rem;
		    left: 0rem;
		    background: url('~@/assets/imgs/ic59.png') no-repeat;
		    background-size: 100% 100%;
		}
		&:before{
			position: absolute;
		    content: '';
		    z-index: 10;
		    top: 1.75rem;
		    width: .15rem;
		    height: .3rem;
		    right: 0rem;
		    background: url('~@/assets/imgs/ic59.png') no-repeat;
		    background-size: 100% 100%;
		    transform:rotate(180deg);
		}
	}
	.wh8{
		width: 1.6rem;
		height: 1.6rem;
	}
	.cgg{
		background-color:#fafafa;
	}
</style>