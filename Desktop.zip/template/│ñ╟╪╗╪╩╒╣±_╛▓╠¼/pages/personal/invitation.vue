<template>
	<div class="invitation">
		<div class="cgo mb15">
			<img src="@/assets/imgs/ic56.png" alt="" class="w100">
			<div class="redBag">
				<div id="qrcode" class="mauto" style="width: 2.2rem;"></div>
			</div>
		</div>
		<div class="center fontInfo">
			<span class="bold">我的邀请码</span> <span class="num">562423</span> <span class="copy br">复制</span>
		</div>
		<div class="center bold lh40 h40 w50 mauto br invitationBtn mtb_15" >立即邀请</div>
		<div class="mlr_15 cgf p15 br">
			<p class="fz18 center co2 bold">邀请战绩</p>
			<div class="title csa cgf fz16">
				<div v-for="(item,index) in title" :class="{'active':isActive==index}" @click="changeType(item,index)">{{item.name}}<span></span></div>
			</div>
			<div v-show="isActive==0">
				<div class="center lh30 h30 br co mtb_10" style="background-color: #fff6ea;">
					总计注册好友&nbsp;&nbsp;8
				</div>
				<div class="csa fz16 c9">
					<span>好友账号</span><span>注册时间</span>
				</div>
				<div>
					<div class="csa mtb_10">
						<span>134&nbsp;1948&nbsp;5959</span><span>1978.25.25 12:23</span>
					</div>
					<div class="csa mtb_10">
						<span>134&nbsp;1948&nbsp;5959</span><span>1978.25.25 12:23</span>
					</div>
				</div>
			</div>
			<div v-show="isActive==1">
				<div class="center lh30 h30 br co mtb_10" style="background-color: #fff6ea;">
					累计奖励环保金&nbsp;&nbsp;168.55
				</div>
				<div class="csa fz16 c9">
					<span>获奖时间</span><span>金额</span>
				</div>
				<div>
					<div class="flex mtb_10">
						<span class="w50 center">1978.25.25 12:23</span><span class="w50 center">+102323.00</span>
					</div>
					<div class="csa mtb_10">
						<span class="w50 center">1978.25.25 12:23</span><span class="w50 center">+10.00</span>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import QRCode from 'qrcodejs2'  // 引入qrcode
	export default{
		name:"invitation",
		components:{
		},
		data(){
			return {
				isActive:0,
				title:[
					{name:"已邀请好友"},
					{name:"已获得奖励"}
				]
			}
		},
		mounted(){
			this.qrcode();
		},
		created(){

		},
		methods:{
			qrcode() {
		      let qrcode = new QRCode('qrcode', {
		        width: 110,  
		        height: 110,
		        text: `http://www.baidu.com`, // 二维码地址
		        colorDark : "#000",
		        colorLight : "#fff",
		      })
		    },
		    changeType(item,index){
				this.isActive=index;
			}
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.invitation{
		min-height: 100vh;
		background-color: #fff0d3;
	}
	.cgo{
		background-color:#ffb917;
	}
	.redBag{
		background: url('~@/assets/imgs/ic57.png');
		width: 100%;
		height: 4.19rem;
		background-size: 100% 100%; 
	}
	#qrcode{
		width: 2.2rem;
		padding-top: .2rem;
		padding-right: .24rem;
	}
	.title{
		height:45px;
		display:flex;
		width:100%;
		line-height:45px;
		font-weight:bold;
		color: #999;
	}
	.title div{
		text-align:center;
	}
	.title div.active{
		position:relative;
	}
	.title div.active span{
		display:inline-block;
		position:absolute;
		width:.4rem;
		height:3px;
		@include br();
		background-color: #1cce3b;
		bottom:.15rem;
		left:50%;
		margin-left:-.2rem;
	}
	.fontInfo{
		.num{
			margin-left: .2rem;
			margin-right: .2rem;
			color: #cc2f16;
			font-size: .42rem;
			font-weight: bold;
		}
		.copy{
			background-color: #fae2c0;
			color: #cc2f16;
			padding: .1rem .3rem;
			border:0.03rem dashed #cc2f16;
		}
	}
	.invitationBtn{
		background-color: #f9be49;
		color: #b67300;
		border:0.03rem solid #b67300;
		font-size: .36rem;
	}
</style>