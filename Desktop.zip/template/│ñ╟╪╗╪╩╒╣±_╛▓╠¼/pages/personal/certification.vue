<template>
	<div class="certification bz oh">
		<div class="p15">
			<p class="mb10 bold">身份证名字</p>
			<input type="text" class="w100 bbef lh40 h40 mb20" placeholder="请输入身份证名字">
			<p class="mb10 bold">身份证号码</p>
			<input type="text" class="w100 bbef lh40 h40 mb20" placeholder="请输入身份证号码">
		</div>
		<div class="submitBtn2">开始认证</div>
	</div>
</template>

<script>
	export default{
		name:"certification",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.certification{
		min-height: 100vh;
		/*background-color: #f5f5f5;*/
	}
</style>