<template>
	<div class="feedback oh bz">
		<div class="title csa mb15 cgf">
			<div v-for="(item,index) in title" :class="{'active':isActive==index}" @click="changeType(item,index)">{{item.name}}<span></span></div>
		</div>
		<div class="m15 cgf br p15">
			<textarea class="w100" cols="30" rows="10" v-model="content" placeholder="请填写描述"></textarea>
		</div>
		<div class="lh40 cgf br p15 mlr_15">
			<img-up width="1.5rem" height="1.5rem" file="faultUp" @setImgFile="setImgFile" @delImgFile="delImgFile"></img-up>
			<p class="center c9">上传图片(最多8张)</p>
		</div>
		<div class="cgf mlr_15 lh40 h40 pl15 bz mt15 br">
			<input type="text" class="h100" placeholder="请输入手机号码">
		</div>
		<div class="submitBtn2">提交</div>
	</div>
</template>

<script>
	import ImgUp from '@/components/ImgUpLoad'
	export default{
		name:"feedback",
		components:{
			ImgUp
		},
		data(){
			return {
				rd:{
					img:[]
				},
				offImg: require('@/assets/imgs/add.jpg'),
				isActive:0,
				title:[
					{name:"建议"},
					{name:"吐槽"},
					{name:"其他"}
				]
			}
		},
		created(){
			
		},
		methods:{
			setImgFile(imgFile){
		    	this.imgFile=imgFile;

		    	let formData = new FormData();
		    	formData.append('api_name','uploadPic');
		        formData.append('img',this.imgFile[this.imgFile.length-1]);
		        this.$toast.loading({duration:0, forbidClick:true, mask:true, loadingType:'spinner', message:'提交中...'});
				this.$http.post('/outside/User/api',formData,'multipart/form-data').then(res => {
					this.$toast.clear();

		        	if (res.code==1) {
		        		this.imgId[this.imgId.length]=res.data.id;
		        		this.imgSrc[this.imgSrc.length]=res.data.path;
		        		console.log(this.imgSrc)
		        		console.log(this.imgId)
		        		console.log(this.imgId.join())
		        	}else{
			        	this.$toast(res.msg);
		        	}
	      		})
		    },
		    delImgFile(index){
		    	this.imgSrc.splice(index,1);
		    },
			go(){
				let vis=this;
				vis.$router.push({
					path:'/Mt_MaintenanceRecord',
					query:{
						id: vis.$route.query.id,
						macno: vis.rd.macno,
						address: vis.rd.device_address
					}
				})
			},
			changeType(item,index){
				this.isActive=index;
			}
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.feedback{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.title{
		height:45px;
		display:flex;
		width:100%;
		line-height:45px;
		font-weight:bold;
		color: #999;
	}
	.title div{
		text-align:center;
	}
	.title div.active{
		color:#00a0e9;
		position:relative;
	}
	.title div.active span{
		display:inline-block;
		position:absolute;
		width:.4rem;
		height:3px;
		@include br();
		background-color: #00a0e9;
		bottom:.15rem;
		left:50%;
		margin-left:-.2rem;
	}
</style>