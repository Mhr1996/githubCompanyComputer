<template>
	<div class="main">
		<div class="banner" style="height:3rem;">
			<van-swipe :autoplay="3000" style="height:100%;">
			  	<van-swipe-item v-for="(g, index) in images" :key="index" >
			    	<img v-lazy="g.image" class="w100 h100" />
			  	</van-swipe-item>
			</van-swipe>
		</div>
		<div class="csa mt20">
			<div class="cca2 center ac fc">
				<img src="@/assets/imgs/ic0.png" alt="" class="w70">
				<span class="mt10">社区</span>
			</div>
			<div class="cca2 center ac fc">
				<img src="@/assets/imgs/ic1.png" alt="" class="w70">
				<span class="mt10">回收指南</span>
			</div>
			<div class="cca2 center ac fc">
				<img src="@/assets/imgs/ic2.png" alt="" class="w70">
				<span class="mt10">回收分类</span>
			</div>
			<div class="cca2 center ac fc">
				<img src="@/assets/imgs/ic3.png" alt="" class="w70">
				<span class="mt10">上门回收</span>
			</div>
		</div>
		<div class="mlr_15 cgf br oh bz mt20">
			<div class="flex ac fc csa mtb_20">
				<div class="bold"><img src="@/assets/imgs/ic6.png" alt="" class="w28 br mr10">环保金</div>
			</div>
			<div class="csa mtb_10"><div class="bge3f6ff">一元环保金=0.01元人民币</div></div>
			<div class="csa mt10 mb15">
				<div class="cca2">
					<span class="fz30 center mb5 bold">22.8</span>
					<span class="c9">当前环保金</span>
				</div>
				<div class="cca2">
					<span class="fz30 center mb5 bold">10</span>
					<span class="c9">投递次数</span>
				</div>
				<div class="cca2">
					<span class="fz30 center mb5 bold">765</span>
					<span class="c9">累计收益</span>
				</div>
			</div>
		</div>
		<div class="cgf br mlr_15 mt15 p15 flex ac fc more_">
			<img src="@/assets/imgs/ic8.png" alt="" style="width: .6rem;" class="mr10">
			<div class="csb"><span>消息中心</span></div>
		</div>
		<div class="cgf br mlr_15 mt15 p15 more_">
			<div class="bold fz18 mb10">
				<img src="" alt="">高盛科技大厦
				<span class="c6 fz14 bg1">约688m</span>
			</div>
			<div class="csa">
				<div class="cca2 center ac fc " v-for="(g,index) of type" :key="index">
					<div class="icon csa ac fc mb10"><img :src="g.img" alt=""></div>
					<span>{{g.name}}</span>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default{
		name:"main",
		components:{
		},
		data(){
			return {
				images: [
					{image:require('@/assets/imgs/banner.jpg')}
				],
				type:[
					{
						name:'饮料瓶',
						img:require('@/assets/imgs/ic11.png')
					},
					{
						name:'纸类',
						img:require('@/assets/imgs/ic14.png')
					},{
						name:'纺织物',
						img:require('@/assets/imgs/ic15.png')
					},{
						name:'金属',
						img:require('@/assets/imgs/ic16.png')
					},{
						name:'塑料',
						img:require('@/assets/imgs/ic17.png')
					},{
						name:'玻璃',
						img:require('@/assets/imgs/ic18.png')
					}
				]
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.main{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.w70{
		width: 1.2rem;
	}
	.w28{
		width: .56rem;
	}
	.bge3f6ff{
		background-color: #e3f6ff;
		color: #00a0e9;
		padding: .1rem;
	}
	.bg1{
		background-color: #eeeeee;
	}
	.icon{
		width: .8rem;
		height: .8rem;
		@include br(50%);
		background-color: #f2f2f2;
		text-align: center;
		img{
			width: .4rem;
		}
	}
	.more_{
		position: relative;
		&:after{
			background: url('~@/assets/imgs/ic34.png') no-repeat;
			background-size: 100%;
			content: '';
			height: .4rem;
			position: absolute;
			right: .2rem;
			top: .36rem;
			width: .2rem;
			z-index: 10;
		}
	}
</style>