<template>
	<div class="nearby">
		<tmap :markerIcon="markerIcon" :marker="mapMarker" :center="center" ref="oMap">
			<div class="csb cgf w90 br first">
				<div class="w80 h100 cca2 pl15 bz ptb_10">
					<div class="fz18 bbef lh40 h40">设备编号:696969</div>
					<div class="c9 lh40 h40">
						<img src="@/assets/imgs/address.png" class="mr5 w24" alt="">
						广东东莞南城高盛科技22号
					</div>
				</div>
				<div class="flex1 ac fc">
					<img src="@/assets/imgs/ic44.png" alt="" style="width: .7rem;height: .7rem;" class="mauto">	
				</div>
			</div>
			<div class="cgf br mt15 p15 cgf w90 bz" style="position: fixed;top: 2.5rem; left: 5%;z-index: 10;">
				<div class="csa">
					<div class="cca2 center ac fc " v-for="(g,index) of type" :key="index">
						<div class="icon csa ac fc mb10"><img :src="g.img" alt=""></div>
						<span class="mb5">{{g.name}}</span>
						<span class="c9 fz12">{{g.info}}</span>
					</div>
				</div>
			</div>
			<img src="@/assets/imgs/ic46.png" alt="" class="bottomLeft1">
			<img src="@/assets/imgs/ic45.png" alt="" class="bottomLeft2">
		</tmap>
	</div>
</template>

<script>
	import Tmap from '@/components/tmap'
	export default{
		name:"nearby",
		components:{
			Tmap
		},
		data(){
			return {
				markerIcon: require("@/assets/imgs/ic43.png"),
				mapMarker: [
					{
						// 标注点ID
						id: 1,
						// 标注点名称
						name: "汤包",
						// 标注点经纬度
						lat: "22.993054",
						lng: "113.707691",
						// 标注点点击事件
						f: () => {
							console.log(1);
						}
				    },
				],
				center: {},
				type:[
					{
						name:'饮料瓶',
						img:require('@/assets/imgs/ic11.png'),
						info: '￥0.5/斤'
					},
					{
						name:'纸类',
						img:require('@/assets/imgs/ic14.png'),
						info: '￥0.5/斤'
					},{
						name:'纺织物',
						img:require('@/assets/imgs/ic15.png'),
						info: '￥0.5/斤'
					},{
						name:'金属',
						img:require('@/assets/imgs/ic16.png'),
						info: '￥0.5/斤'
					},{
						name:'塑料',
						img:require('@/assets/imgs/ic17.png'),
						info: '￥0.5/斤'
					},{
						name:'玻璃',
						img:require('@/assets/imgs/ic18.png'),
						info: '￥0.5/斤'
					}
				]
			}
		},
		created(){
			let vis=this;
			setTimeout(()=>{
	            vis.center.lat =22.991543;
	            vis.center.lng =113.708024;
	            vis.$refs['oMap'].init();
	        },300)
		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.nearby{
		min-height: 100vh;
		/*background-color: #f5f5f5;*/
	}
	.icon{
		width: .8rem;
		height: .8rem;
		@include br(50%);
		background-color: #f2f2f2;
		text-align: center;
		img{
			width: .4rem;
		}
	}
	.w24{
		width: .24rem;
	}
	.first{
		position: fixed;top: .3rem; left: 5%;z-index: 10; height: 2.1rem;
	}
	.bottomLeft1{
		@include after();
		width: 1.2rem;
	    height: 1.2rem;
	    bottom: 3.4rem;
	    top: initial;
	}
	.bottomLeft2{
		@include after();
	    width: 1.2rem;
	    height: 1.2rem;
	    bottom: 2.2rem;
	    top: initial;
	}
</style>