<template>
	<div class="find">
		<div class="title csa mb15 cgf">
			<div v-for="(item,index) in title" :class="{'active':isActive==index}" @click="changeType(item,index)">{{item.name}}<span></span></div>
		</div>
		<div v-show="isActive==0" class="flex wrap cgf plr_15">
			<div class="csb bbef wrap w100 ptb_15">
				<div class="w60 ptb_5"> 
					<p class="fz18 bold c3 ellipsis mb5">标题标标题标题标题标题标题标标题标题标题标题</p>
					<p class="c9 twoLines" style="line-height: .4rem;">内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容</p>
				</div>
				<img src="@/assets/imgs/banner.png" alt="" class="imgbr br flex1 ml15">
			</div>
			<div class="csb bbef wrap w100 ptb_15">
				<div class="w60 ptb_5"> 
					<p class="fz18 bold c3 ellipsis mb5">标题标标题标题标题标题标题标标题标题标题标题</p>
					<p class="c9 twoLines" style="line-height: .4rem;">内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容</p>
				</div>
				<img src="@/assets/imgs/banner.png" alt="" class="imgbr br flex1 ml15">
			</div>
			<div class="ptb_15">
				<p class="fz18 bold c3 ellipsis mb5">标题标题标题标题</p>
				<img src="@/assets/imgs/banner.png" alt="" class="w100 br" style="max-height:3.1rem;">
			</div>
		</div>
		<div v-show="isActive==1">2</div>
		<div v-show="isActive==2">3</div>
	</div>
</template>

<script>
	export default{
		name:"find",
		components:{
		},
		data(){
			return {
				isActive:0,
				title:[
					{name:"最新推荐"},
					{name:"环保百科"},
					{name:"环保动态"}
				]
			}
		},
		created(){

		},
		methods:{
			changeType(item,index){
				this.isActive=index;
			}
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.find{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.title{
		height:45px;
		display:flex;
		width:100%;
		line-height:45px;
		font-weight:bold;
		color: #999;
	}
	.title div{
		text-align:center;
	}
	.title div.active{
		color:#00a0e9;
		position:relative;
	}
	.title div.active span{
		display:inline-block;
		position:absolute;
		width:.4rem;
		height:3px;
		@include br();
		background-color: #00a0e9;
		bottom:.15rem;
		left:50%;
		margin-left:-.2rem;
	}
	.imgbr{
		width: 2.24rem;
		height: 1.48rem;
	}
</style>