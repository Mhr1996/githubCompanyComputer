<template>
	<div class="protectAmbient oh bz pt10">
		<div class="mlr_15 h360 br cca2 center mb20 cf bz pt70">
			<div class="price fz30 mb20 ">958.20</div>
			<span>环保金</span>
		</div>
		<div class="cgf plr_15 mb10 br mlr_15">
			<div class="lh40 h40 csb bbef">
				<input type="text" placeholder="请输入兑换数量">
				<span style="color: #59360b;">全部兑换</span>
			</div>
			<div class="lh40 h40">
				<span class="c9 p5 br" style="background-color: #f8f8f8;">1环保金可退换1元人民币</span>
			</div>
		</div>
		<div class="cgf plr_15 mb20 br more35 mlr_15 lh40 h40 pr10 ac fc">
			<img src="@/assets/imgs/ic27.png" alt="" class="w38 mr10">环保金明细
		</div>
		<p class="boldl fz18 mb10 mlr_15">选择到账方式</p>
		<div class="cgf plr_15 mb10 br csb mlr_15 lh40 h40">
			<div>
				<img src="@/assets/imgs/icon14.png" alt="" class="w55 mr10">微信
			</div>
			<img src="@/assets/imgs/ic31.png" alt="" class="w40">
		</div>
		<div class="cgf plr_15 mb10 br csb mlr_15 lh40 h40">
			<div>
				<img src="@/assets/imgs/ic28.png" alt="" class="w55 mr10">支付宝
			</div>
			<img src="@/assets/imgs/ic42.png" alt="" class="w40">
		</div>
		<div class="submitBtn2">
			确认兑换
		</div>
	</div>
</template>

<script>
	export default{
		name:"protectAmbient",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.protectAmbient{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.h360{
		height: 3.6rem;
		background:url('~@/assets/imgs/ic26.png') no-repeat;
		background-size: 100% 100%;
	}
	.w55{
		width: .55rem;
	}
	.w40{
		width: .4rem;
	}
	.w38{
		width: .38rem;
	}
</style>