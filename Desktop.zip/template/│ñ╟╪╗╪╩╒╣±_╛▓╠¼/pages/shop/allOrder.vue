<template>
	<div class="allOrder plr_15 oh bz">
		<div class="csb mt20 ac fc">
			<span class="fz22 bold titleBorder">全部订单</span>
			<span class="flex ac fc"><img src="@/assets/imgs/ic35.png" alt="" class="w3 mr10">订单说明</span>
		</div>
		<div class="mt30 mb20">
			<div class="mb20">预约上门时间:2019-12-6 14:10:30</div>
			<div class="after plr_15 panel shadow">
				<div class="csb bbef lh40 h40 ptb_10 fz16">
					<p class="bold">笔记本平板</p><span style="color: #59360b;" class="more34 pr15">待接单</span>
				</div>
				<div class="flex" style="justify-content: flex-end;">
					<span class="brde mtb_10 p5_15 br c9">取消订单</span>
				</div>
			</div>
		</div>
		<div class="mt30 mb20">
			<div class="mb20">预约上门时间:2019-12-6 14:10:30</div>
			<div class="after plr_15 panel shadow">
				<div class="csb bbef lh40 h40 ptb_10 fz16">
					<p class="bold">笔记本平板</p><span style="color: #59360b;" class="more34 pr15">待接单</span>
				</div>
				<div class="flex" style="justify-content: flex-end;">
					<span class="brde mtb_10 p5_15 br c9">取消订单</span>
				</div>
			</div>
		</div>
		<div class="mt30 mb20">
			<div class="mb20">预约上门时间:2019-12-6 14:10:30</div>
			<div class="after plr_15 panel shadow">
				<div class="csb bbef lh40 h40 ptb_10 fz16">
					<p class="bold">笔记本平板</p><span style="color: #59360b;" class="more34 pr15">待接单</span>
				</div>
				<div class="flex" style="justify-content: flex-end;">
					<span class="brde mtb_10 p5_15 br c9">取消订单</span>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default{
		name:"allOrder",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.allOrder{
		min-height: 100vh;
		/*background-color: #f5f5f5;*/
	}
	.w3{
		width: .3rem;
	}
	.panel{

	}
	.shadow{
		@include box-shadow-abroad(0rem 0.02rem 0.1rem 0.02rem #eaeaea);
		position: relative;
		&:before{
			background: url('~@/assets/imgs/ic36.png');
			position: absolute;
		    left: 0;
		    content: '';
		    z-index: 10;
		    top: .36rem;
		    width: .06rem;
		    height: .4rem;
		    background-size: 100%;
		}
	}
</style>