<template>
	<div class="finalOrder bz oh">
		<div class="cgf br m15">
			<div class="cgf more34 p15">
				<div class="mb10">
					<span class="bold fz20 mr10">name</span>1233123123
				</div>
				<div class="c9">
					<img src="@/assets/imgs/ic39.png" alt="" class="mr10 w1">广东省东莞市南城区高盛科技大厦303
				</div>
			</div>
			<div class="borderBottom"></div>
		</div>
		<div class="flex p15 cgf mb10 mlr_15">
			<img src="@/assets/imgs/ic50.png" alt="" class="wh_150 br mr10">
			<div class="csb flex1">
				<p class="name">30.00环保金</p><span class="name">*1</span>
			</div>
		</div>
		<div class="mb10 plr_15 mlr_15 more35 lh40 h40 cgf bz ac fc" @click="show=true">
			<img src="@/assets/imgs/ic52.png" alt="" class="mr10 w_35">礼券
		</div>
		<div class="cf lh40 h40 center bottomSubmit">需支付环保金:60.00 | 立即支付</div>
		<van-popup v-model="show" position="bottom">
			<van-picker :columns="columns" @change="onChange" show-toolbar />
		</van-popup>
	</div>
</template>

<script>
	export default{
		name:"finalOrder",
		components:{
		},
		data(){
			return {
				show:false,
				columns: ['杭州', '宁波', '温州', '嘉兴', '湖州']
			}
		},
		created(){

		},
		methods:{
			onChange(picker, value, index) {
	      		this.$toast(`当前值：${value}, 当前索引：${index}`);
	    	}
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.finalOrder{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.w1{
		width:.3rem;
	}
	.p15.more34{
		&:after{
			right:.2rem;
		}
	}
	.borderBottom{
		background:url('~@/assets/imgs/ic38.png') repeat-x;
		height:.1rem;
		background-size: 2rem;
	}
	.w_35{
		width:.35rem;
	}
	.bottomSubmit{
		background-color:#00a0e9;
		position:fixed;
		bottom: 0;
		left: 0;
		width: 100%;
		z-index: 4;
	}
	.wh_150{
		width: 1.5rem;
		height: 1.5rem;
		border:1px solid #e5e5e5;
	}
</style>