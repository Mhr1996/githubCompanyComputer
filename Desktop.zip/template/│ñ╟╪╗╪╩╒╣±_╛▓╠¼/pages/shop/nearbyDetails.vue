<template>
	<div class="nearbyDetails pt15 bz oh">
		<div class="csb cgf w90 br first mauto">
			<div class="w80 h100 cca2 pl15 bz ptb_10">
				<div class="fz18 bbef">
					<div class=" lh40 h40">
						<img src="@/assets/imgs/ic48.png" alt="" style="width: .3rem;" class="mr5">设备编号:696969
					</div>
					<p class="c9 mb10 fz12">502m</p>
				</div>
				<div class="c9 lh40 h40 csb">
					<span>回收机编号：62012486</span> <span class="tdBtn br plr_6" style="line-height: initial;">正常快递</span>
				</div>
			</div>
			<div class="flex1 ac fc">
				<img src="@/assets/imgs/ic44.png" alt="" style="width: .7rem;height: .7rem;" class="mauto">	
			</div>
		</div>
		<div class="cgf br bst w90 mauto mt15 p15 bz oh">
			<p class="title mb20">回收品类</p>
			<div class="csa wrap">
				<div class="cca2 center ac fc w33 mb20" v-for="(g,index) of type" :key="index">
					<div class="icon csa ac fc mb10"><img :src="g.img" alt="" class="wh_100"></div>
					<span class="mb5">{{g.name}}</span>
					<span class="c9 fz12">{{g.info}}</span>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default{
		name:"nearbyDetails",
		components:{
		},
		data(){
			return {
				type:[
					{
						name:'塑料',
						img:require('@/assets/imgs/ic_csl.png'),
						info: '￥0.5/斤'
					},
					{
						name:'纸类',
						img:require('@/assets/imgs/ic_czl.png'),
						info: '￥0.1/斤'
					},{
						name:'饮料瓶',
						img:require('@/assets/imgs/ic_cslp.png'),
						info: '￥0.5/斤'
					},{
						name:'纺织物',
						img:require('@/assets/imgs/ic_cfzw.png'),
						info: '￥0.5/斤'
					},{
						name:'金属',
						img:require('@/assets/imgs/ic_cjs.png'),
						info: '￥0.1/斤'
					},{
						name:'玻璃',
						img:require('@/assets/imgs/ic_cbl.png'),
						info: '￥0.1 /斤'
					}
				]
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.nearbyDetails{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.tdBtn{
		color:#14b5ff;
		border: 1px solid #14b5ff;
		line-height: initial;
	}
	.wh_100{
		width:1rem;
		height:1rem;
	}
</style>