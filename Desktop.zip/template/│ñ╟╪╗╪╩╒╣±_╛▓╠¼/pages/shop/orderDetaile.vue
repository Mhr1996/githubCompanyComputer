<template>
	<div class="orderDetaile">
		<div class="ptb_30 cca2 ac fc center cgf mb10">
			<span class="fz20 mb10 cb">已接单</span>
			<span class="c9">请耐心等待骑手接单</span>
		</div>
		<div class="flex cgf mb10 plr_15 ptb_10">
			<img src="@/assets/imgs/ic37.png" alt="" class="w7 mr10">
			<div class="csb flex1 ">
				<div class="cca2 h100">
					<p>name</p>
					<p>已接200单</p>
				</div>
				<div class="call cf br p5_15">联系骑手</div>
			</div>
		</div>
		<div class="cgf plr_15 mb10">
			<div class="lh40 h40 bold bbef">回收清单</div>
			<div class="bbef">
				<div class="cca2 mtb_10" style="height:1rem;">
					<p class="bold">台式电脑</p>
					<p class="c9">液晶屏&lt;14寸</p>
				</div>
				<div class="cca2 mtb_10" style="height:1rem;">
					<p class="bold">台式电脑</p>
					<p class="c9">液晶屏&lt;14寸</p>
				</div>
			</div>
			<div class="lh40 h40 c9">
				<span class="bold mr10 c0">留言备注</span>帮我
			</div>
		</div>
		<div class="cgf plr_15 mb20 oh pb10">
			<div class="lh40 h40 bold bbef">回收清单</div>
			<div class="csb mtb_10">
				<span class="bold mr10">预约时间</span>
				<span class="c9 flex1">2019-12-6 15:54:42</span>
			</div>
			<div class="csb mtb_10">
				<span class="bold mr10">联系方式</span>
				<span class="c9 flex1">2019-12-6 15:54:42</span>
			</div>
			<div class="csb mtb_10">
				<span class="bold mr10">上门地址</span>
				<span class="c9 flex1">2019-12-6 15:54:42</span>
			</div>
		</div>
		<div class="submitBtn2">取消订单</div>
	</div>
</template>

<script>
	export default{
		name:"orderDetaile",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.orderDetaile{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.w7{
		width:.7rem;
	}
	.call{
		background-color:#00a0e9;
	}
</style>