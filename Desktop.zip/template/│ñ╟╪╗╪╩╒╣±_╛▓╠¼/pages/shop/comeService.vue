<template>
	<div class="comeService">
		<div class="banner" style="height:3rem;">
			<van-swipe :autoplay="3000" style="height:100%;">
			  	<van-swipe-item v-for="(g, index) in images" :key="index" >
			    	<img v-lazy="g.image" class="w100 h100" />
			  	</van-swipe-item>
			</van-swipe>
		</div>
		<div class="mlr_15 mt20">
			<div class="fz22 bold">3c数码</div>
			<div class="swiper-container ">
			    <swiper :options="swiperOption" class="pt20">
			     	<div class="product ac fc cca2 swiper-slide br" v-for="(g,index) of material " :key="index">
						<img :src="g.img" alt="">
						<p>{{g.name}}</p>
						<p>{{g.en}}</p>
					</div>
			    </swiper>
			</div>
		</div>
		<div class="mlr_15 mt20">
			<div class="fz22 bold">家用电器</div>
			<div class="swiper-container ">
			    <swiper :options="swiperOption" class="pt20">
			     	<div class="product ac fc cca2 swiper-slide br" v-for="(g,index) of material " :key="index">
						<img :src="g.img" alt="">
						<p>{{g.name}}</p>
						<p>{{g.en}}</p>
					</div>
			    </swiper>
			</div>
		</div>
		<div class="mlr_15 mt20">
			<div class="fz22 bold">大宗废品</div>
			<div class="csa p15 shadow br mt10">
				<div class="cca2 center ac fc " v-for="(g,index) of type" :key="index">
					<div class="icon csa ac fc mb10"><img :src="g.img" alt=""></div>
					<span class="c9">{{g.name}}</span>
				</div>
			</div>
		</div>
		<div class="csa mt20">
			<div class="br w45 lh40 h40 center brde">我的订单</div>
			<div class="br w45 lh40 h40 center reserve">马上预约</div>
		</div>
	</div>
</template>

<script>
	export default{
		name:"comeService",
		components:{
		},
		data(){
			return {
				swiperOption:{
			      slidesPerView: 3.5,
			      spaceBetween: 15,
			      freeMode: true,
			      pagination: {
			        el: '.swiper-pagination',
			        clickable: true,
			      },
			    },
				images: [
					{
						image:require('@/assets/imgs/banner.jpg')
					},
					{
						image:require('@/assets/imgs/banner.jpg')
					}
				],
				material:[
					{
						img:require('@/assets/imgs/banner.jpg'),
						name:'手机',
						en:'Phone'
					},{
						name:'手机',
						img:require('@/assets/imgs/banner.jpg'),
						en:'Phone'
					},{
						img:require('@/assets/imgs/banner.jpg'),
						name:'手机',
						en:'Phone'
					},{
						name:'手机',
						img:require('@/assets/imgs/banner.jpg'),
						en:'Phone'
					},{
						img:require('@/assets/imgs/banner.jpg'),
						name:'手机',
						en:'Phone'
					},{
						name:'手机',
						img:require('@/assets/imgs/banner.jpg'),
						en:'Phone'
					},{
						name:'手机',
						img:require('@/assets/imgs/banner.jpg'),
						en:'Phone'
					}
				],
				type:[
					{
						name:'纸类',
						img:require('@/assets/imgs/ic14.png')
					},{
						name:'纺织物',
						img:require('@/assets/imgs/ic15.png')
					},{
						name:'金属',
						img:require('@/assets/imgs/ic16.png')
					},{
						name:'塑料',
						img:require('@/assets/imgs/ic17.png')
					}
				]
			}
		},
		created(){
		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.comeService{
		min-height: 100vh;
		/*background-color: #f5f5f5;*/
	}
	.product{
		background-color: #f4f4f4;
		width: 1.5rem;
		height: 1.8rem;
		img{
			@include br(50%);
			margin-top: -.4rem;
			height: 1rem;
			width: 1rem;
			background-color: #fff;
		}
	}
	.icon{
		width: .8rem;
		height: .8rem;
		@include br(50%);
		background-color: #f2f2f2;
		text-align: center;
		img{
			width: .4rem;
		}
	}
	.shadow{
		@include box-shadow-abroad(0rem 0.02rem 0.1rem 0.02rem #eaeaea);
	}
	.reserve{
		background-color: #00a0e9;
		color: #fff;
	}
</style>