<template>
	<div class="login bz oh">
		<div class="cgf m15 p20 br" style="margin-top:3rem;">
			<div class="flex ac jc ptb_20">
				<img src="@/assets/imgs/ic_logo.png" alt="" style="width: 1rem;">	
			</div>
			<div class="lh40 h40 bbef  flex ac">
				<img src="@/assets/imgs/ic_phone.png" alt="" class="w3 mr10">
				<input type="text" placeholder="请输入手机号码">
			</div>
			<div class="relative lh40 h40 bbef flex ac">
				<img src="@/assets/imgs/ic_yzm.png" alt="" class="w3 mr10">
				<input type="text" placeholder="请输入验证码">
				<validate @click="getCode" class="verBtn"></validate>
			</div>
			<div class="lh40 h40 bbef mb20 flex ac">
				<img src="@/assets/imgs/ic33.png" alt="" class="w3 mr10">
				<input type="text" placeholder="请输入邀请码">
			</div>
			<div @click="agree=!agree">
				<img src="@/assets/imgs/ic32.png" alt="" v-show="!agree" class="w32 mr10">
				<img src="@/assets/imgs/ic31.png" alt="" v-show="agree" class="w32 mr10">认证及已阅读并同意《用户服务协议》
			</div>
			<div class="submitBtn2">认证</div>
		</div>
	</div>
</template>

<script>
	import validate from '@/components/validate'
	export default{
		name:"login",
		components:{
			validate
		},
		data(){
			return {
				agree: false
			}
		},
		created(){

		},
		methods:{
			sendVer(){
				let vis = this;
	            bindSendPhone({
	                phone:vis.mobile
	            }).then(res=>{
	            	if (res.code == 0) {
						vis.$toast("发送成功，请注意查收");
					}else{
						vis.$toast(res.msg);
					}
	            })
			},
			getCode(cb){
				let re=/^1[0-9]{10}$/;
				if(!re.test(this.mobile)){
					this.$toast("手机号格式不正确!");
					return;
				}
				cb(this.sendVer);
			}
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.login{
		min-height: 100vh;
		/*background-color: #f5f5f5;*/
		background:url('~@/assets/imgs/ic5.png') no-repeat;
		background-size:100% 100%;
	}
	.verBtn{
		background-color:#00a0e9;
		color:#fff;
	}
	.w32{
		width:.32rem;
		height: .32rem;
	}
	.w3{
		width: .3rem;
	}
</style>