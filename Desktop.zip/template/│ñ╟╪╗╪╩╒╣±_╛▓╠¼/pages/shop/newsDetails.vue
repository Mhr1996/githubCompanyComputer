<template>
	<div class="newsDetails cca2">
		<img src="@/assets/imgs/ic49.png" alt="" class="w100">
		<div class="content flex1 cgf" style="margin-top:-.3rem;">
			<p class="title"></p>
			<p>
				内容内容
			</p>
		</div>
	</div>
</template>

<script>
	export default{
		name:"newsDetails",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.newsDetails{
		min-height: 100vh;
		/*background-color: #f5f5f5;*/
	}
	.content{
		@include border-radiustl(.5rem);
		@include border-radiustr(.5rem);
		padding:.3rem;
		box-shadow: 0 0.04rem 0.4rem 0.02rem #eaeaea;
      	-ms-box-shadow: 0 0.04rem 0.4rem 0.02rem #eaeaea;
     	-moz-box-shadow: 0 0.04rem 0.4rem 0.02rem #eaeaea;
  		-webkit-box-shadow: 0 0.04rem 0.4rem 0.02rem #eaeaea;
	}
</style>