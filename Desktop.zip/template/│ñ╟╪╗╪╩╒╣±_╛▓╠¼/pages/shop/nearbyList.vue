<template>
	<div class="nearbyList pt10 bz br">
		<div class="after plr_15 panel shadow cgf mlr_15 box-shadow-trbl more35">
			<div class="csb bbef lh40 h40 ptb_10 fz16">
				<p class="bold flex ac fc">
					<img src="@/assets/imgs/address.png" alt="" style="width: .3rem;" class="mr5">笔记本平板
				</p>
				<span>5052m</span>
			</div>
			<div class="flex" style="justify-content: flex-end;">
				<span class="brde mtb_10 p5_15 br c9 br tdBtn" >正常投递</span>
			</div>
		</div>
		<img src="@/assets/imgs/ic47.png" alt="" class="bottomLeft">
	</div>
</template>

<script>
	export default{
		name:"nearbyList",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.nearbyList{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.more35{
		padding-right: 1rem;
		&:after{
			right:.4rem;
		}
	}
	.tdBtn{
		color:#14b5ff;
		border: 1px solid #14b5ff;
	}
	.bottomLeft{
		@include after();
		width: 1.5rem;
	    top: initial;
	    left: .2rem;
	    bottom: 3rem;
	}
</style>