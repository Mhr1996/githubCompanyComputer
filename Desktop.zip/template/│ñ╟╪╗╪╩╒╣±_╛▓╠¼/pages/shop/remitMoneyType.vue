<template>
	<div class="remitMoneyType pt10 oh bz">
		<p class="c9 pl15 mb10">微信零钱</p>
		<div class="cgf plr_15 mb20 br csb mlr_15 lh40 h40">
			<div>
				<img src="@/assets/imgs/icon14.png" alt="" class="w55 mr10">微信
			</div>
			<img src="@/assets/imgs/ic29.png" alt="" class="w40">
		</div>
		<p class="c9 pl15 mb10">支付宝零钱</p>
		<div class="cgf plr_15 mb20 br csb mlr_15 lh40 h40">
			<div>
				<img src="@/assets/imgs/ic28.png" alt="" class="w55 mr10">支付宝
			</div>
			<img src="@/assets/imgs/ic30.png" alt="" class="w40">
		</div>
	</div>
</template>

<script>
	export default{
		name:"remitMoneyType",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.remitMoneyType{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.w55{
		width: .55rem;
	}
	.w40{
		width: .4rem;
	}
</style>