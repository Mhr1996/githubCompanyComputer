<template>
	<div class="commodityDetails">
		<div class="cgf mb10 center">
			<van-image-preview
			  v-model="show"
			  :images="images"
			  @change="onChange"
			>
				<template v-slot:index>第{{ index+1 }}页</template>
			</van-image-preview>
			<img src="@/assets/imgs/ic50.png" alt="" style="max-width:100%;max-height:4.4rem;" @click="show=true">
			<div class="pt10">
				<p class=" bold fz18 mtb_10">环保杯</p>
				<div class="cr bold fz18 center pb10">
					<img src="@/assets/imgs/ic51.png" alt="" style="width: .3rem;vertical-align: unset;" class="mr5">
					60.00
				</div>
			</div>
		</div>
		<div class="cgf">
			<div class="csb p10">
				<span class="fz16 bold">购买数量</span>
				<div><van-stepper v-model="value" /></div>
				<span class="c9">已售16件</span>
			</div>
		</div>
		<div class="content">
			
		</div>
	</div>
</template>

<script>
	export default{
		name:"commodityDetails",
		components:{
		},
		data(){
			return {
				show:false,
				images:[
					require("@/assets/imgs/ic50.png"),
					require("@/assets/imgs/ic50.png"),
					require("@/assets/imgs/ic50.png")
				],
				value:1
			}
		},
		created(){

		},
		methods:{
			onChange(index) {
		      	this.index = index;
		    }
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.commodityDetails{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
</style>