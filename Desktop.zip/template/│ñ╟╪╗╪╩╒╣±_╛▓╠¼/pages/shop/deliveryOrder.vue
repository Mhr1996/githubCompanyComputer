<template>
	<div class="deliveryOrder oh bz">
		<div class="title csa mb15 cgf">
			<div v-for="(item,index) in title" :class="{'active':isActive==index}" @click="changeType(item,index)">{{item.name}}<span></span></div>
		</div>
		<div v-show="isActive==0">
			<div class="mlr_15 p15 cgf br bst mb15" v-for="(g,index) of 4" :key="index">
				<div class="bbef pb15">
					<p class="fz16 bold mb10 flex ac fc"><img src="@/assets/imgs/ic39.png" alt="" class="mr10" style="width: .3rem;">地址内容</p>
					<span class="c9 ">2019-01-08</span>
				</div>
				<div class="bbef ptb_15">
					<div class="csb mb15">
						<div>投递纸1.6kg <span class="c9">￥1.5/斤</span></div>
						<span class="c9">￥3.6</span>
					</div>
					<div class="csb">
						<div>投递纸1.6kg <span class="c9">￥1.5/斤</span></div>
						<span class="c9">￥3.6</span>
					</div>
				</div>
				<div class="tr mt15 bold">环保金收入<span class="fz18" style="color:#ce351c;">￥4.6</span></div>
			</div>
		</div>
		<div v-show="isActive==1">
			<div class="mt30 mb20 mlr_15">
				<div class="mb20">预约上门时间:2019-12-6 14:10:30</div>
				<div class="after plr_15 panel shadow cgf br">
					<div class="csb bbef lh40 h40 ptb_10 fz16">
						<p class="bold">笔记本平板</p><span style="color: #59360b;" class="more34 pr15">待接单</span>
					</div>
					<div class="flex" style="justify-content: flex-end;">
						<span class="brde mtb_10 p5_15 br c9 mr10">取消订单</span>
						<span class="brde mtb_10 p5_15 br c9 tdBtn">联系骑手</span>
					</div>
				</div>
			</div>
			<div class="mt30 mb20 mlr_15">
				<div class="mb20">预约上门时间:2019-12-6 14:10:30</div>
				<div class="after plr_15 panel shadow cgf br">
					<div class="csb bbef lh40 h40 ptb_10 fz16">
						<p class="bold">笔记本平板</p><span style="color: #59360b;" class="more34 pr15">待接单</span>
					</div>
					<div class="flex" style="justify-content: flex-end;">
						<span class="brde mtb_10 p5_15 br c9 mr10">取消订单</span>
						<span class="brde mtb_10 p5_15 br c9 tdBtn">联系骑手</span>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default{
		name:"deliveryOrder",
		components:{
		},
		data(){
			return {
				isActive:0,
				title:[
					{name:"我的投递"},
					{name:"上门回收"}
				]
			}
		},
		created(){

		},
		methods:{
			changeType(item,index){
				this.isActive=index;
			}
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.deliveryOrder{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.title{
		height:45px;
		display:flex;
		width:100%;
		line-height:45px;
		font-weight:bold;
		color: #999;
	}
	.title div{
		text-align:center;
	}
	.title div.active{
		color:#00a0e9;
		position:relative;
	}
	.title div.active span{
		display:inline-block;
		position:absolute;
		width:.4rem;
		height:3px;
		@include br();
		background-color: #00a0e9;
		bottom:.15rem;
		left:50%;
		margin-left:-.2rem;
	}
	.shadow{
		@include box-shadow-abroad(0rem 0.02rem 0.1rem 0.02rem #eaeaea);
		position: relative;
		&:before{
			background: url('~@/assets/imgs/ic36.png');
			position: absolute;
		    left: 0;
		    content: '';
		    z-index: 10;
		    top: .36rem;
		    width: .06rem;
		    height: .4rem;
		    background-size: 100%;
		}
	}
	.tdBtn{
		color:#14b5ff;
		border: 1px solid #14b5ff;
	}
</style>