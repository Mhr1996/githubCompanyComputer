<template>
	<div class="appoint oh bz">
		<div class="cgf br m15">
			<div class="cgf more34 p15">
				<div class="mb10">
					<span class="bold fz20 mr10">name</span>1233123123
				</div>
				<div class="c9">
					<img src="@/assets/imgs/ic39.png" alt="" class="mr10 w1">广东省东莞市南城区高盛科技大厦303
				</div>
			</div>
			<div class="borderBottom"></div>
		</div>
		
		<div class="cca2 ac fc center cgf mb10 mlr_15 br">
			<div class="mt15 w100 bz">
				<div class="csb bbef plr_15 pb10 tl" style="height:1.2rem;">
					<div class="cca2 h100">
						<p class="bold fz18">功能机</p>
						<span class="c9">功能机带电池</span>
					</div>
					<div>￥2.00~￥2.00 <img src="@/assets/imgs/ic41.png" alt="" class="w4"></div>
				</div>
				<div class="csb bbef plr_15 pb10 tl" style="height:1.2rem;">
					<div class="cca2 h100">
						<p class="bold fz18">功能机</p>
						<span class="c9">功能机带电池</span>
					</div>
					<div>￥2.00~￥2.00 <img src="@/assets/imgs/ic41.png" alt="" class="w4"></div>
				</div>
			</div>
			<span class="mb20 c9 mt40">请添加您需要上门回收的物品吧</span>
			<span class="c3 fz20 mb40"><img src="@/assets/imgs/ic40.png" alt="" class="w43 mr10">立即添加</span>
		</div>
		<div class="lh40 h40 csb cgf mb10 mlr_15 plr_15 br" @click="timeShow=true">
			<span>预约时间</span><span class="more34 pr15">请选择预约上门时间</span>
		</div>
		<div class="lh40 h40 csb cgf mb10 mlr_15 plr_15 br">
			<span>留言备注</span><span class="more34 pr15">可描述物品状、特殊要求等</span>
		</div>
		<div class="submitBtn2">马上预约</div>
		<van-popup 
			v-model="timeShow"
			position="bottom"
		>
			<van-picker 
			:columns="columns" 
			@change="onChange"
			show-toolbar
			title="标题"
			@cancel="onCancel"
  			@confirm="onConfirm" />
		</van-popup>
	</div>
</template>

<script>
	const citys = {
  '今天': ['随时可以'],
  '明天': ['11:00~13:00', '15:00~17:00']
};

	export default{
		name:"appoint",
		components:{
		},
		data(){
			return {
				toolbar:true,
				timeShow:false,
				columns: [
					{
						values: Object.keys(citys),
						className: 'column1'
					},
					{
						values: citys['今天'],
						className: 'column2',
						defaultIndex: 2
					}
				]
			}
		},
		created(){

		},
		methods:{
			onChange(picker, values) {
		    	picker.setColumnValues(1, citys[values[0]]);
		    },
		    onCancel(){
		    	this.timeShow=false;
		    },
			onConfirm(){
				this.timeShow=false;
			},
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.appoint{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
	.w1{
		width:.3rem;
	}
	.w43{
		width:.43rem;
		height: .43rem;
	}
	.p15.more34{
		&:after{
			right:.2rem;
		}
	}
	.borderBottom{
		background:url('~@/assets/imgs/ic38.png') repeat-x;
		height:.1rem;
		background-size: 2rem;
	}
	.w4{
		width:.4rem;
	}
</style>