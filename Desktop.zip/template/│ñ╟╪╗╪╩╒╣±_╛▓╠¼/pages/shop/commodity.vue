<template>
	<div class="commodity pt15 bz">
		<div class="csb mb15 plr_15">
			<span class="titleBorder fz22 bold">我的环保金</span>
			<div>
				<img src="@/assets/imgs/ic6.png" alt="" style="width: .4rem;vertical-align: bottom;" class="mr5 ">
				<span class="cb fz16 bold">688.00</span>
			</div>
		</div>
		<div class="csb plr_15 br wrap ac fc center bz">
			<div class="mb10 w47 p15 bz brde br" v-for="(g,index) of 10" :key="index">
				<img src="@/assets/imgs/ic50.png" alt="" class="w100 mb10">
				<p class="bold mb10">环保杯</p>
				<div class="cr bold fz18 center ">
					<img src="@/assets/imgs/ic51.png" alt="" style="width: .3rem;vertical-align: unset;" class="mr5">60.00
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default{
		name:"commodity",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.commodity{
		min-height: 100vh;
		/*background-color: #f5f5f5;*/
	}
</style>