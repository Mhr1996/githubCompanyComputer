<template>
	<div class="recoveryType">
		<div class="title csa">
			<div v-for="(item,index) in title" :class="{'active':isActive==index}" @click="changeType(item,index)">{{item.name}}<span></span></div>
		</div>
		<div v-show="isActive==0" class="flex wrap">
			<div class="cca2 w25 h2 ac fc "> 
				<img src="@/assets/imgs/banner.png" alt="" class="imgbr">
				<span>办公废纸</span>
			</div>
			<div class="cca2 w25 h2 ac fc"> 
				<img src="@/assets/imgs/banner.png" alt="" class="imgbr">
				<span>废报纸</span>
			</div>
			<div class="cca2 w25 h2 ac fc"> 
				<img src="@/assets/imgs/banner.png" alt="" class="imgbr">
				<span>纸盒</span>
			</div>
			<div class="cca2 w25 h2 ac fc"> 
				<img src="@/assets/imgs/banner.png" alt="" class="imgbr">
				<span>明信片</span>
			</div>
			<div class="cca2 w25 h2 ac fc"> 
				<img src="@/assets/imgs/banner.png" alt="" class="imgbr">
				<span>办公废纸</span>
			</div>
			<div class="cca2 w25 h2 ac fc"> 
				<img src="@/assets/imgs/banner.png" alt="" class="imgbr">
				<span>办公废纸</span>
			</div>
		</div>
		<div v-show="isActive==1">2</div>
	</div>
</template>

<script>
	export default{
		name:"recoveryType",
		components:{
		},
		data(){
			return {
				isActive:0,
				title:[
					{name:"纸类"},
					{name:"金属"},
					{name:"瓶子"},
					{name:"纺织物"}
				]
			}
		},
		created(){

		},
		methods:{
			changeType(item,index){
				this.isActive=index;
			}
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.recoveryType{
		min-height: 100vh;
		/*background-color: #f5f5f5;*/
	}
	.title{
		height:45px;
		display:flex;
		width:100%;
		line-height:45px;
		color:#1cce3b;
		font-weight:bold;
		border-bottom:1px solid #e5e5e5;
	}
	.title div{
		text-align:center;
	}
	.title div.active{
		position:relative;
	}
	.title div.active span{
		display:inline-block;
		position:absolute;
		width:.4rem;
		height:3px;
		@include br();
		background-color: #1cce3b;
		bottom:.15rem;
		left:50%;
		margin-left:-.2rem;
	}
	.imgbr{
		@include br(50%);
		width: 1.2rem;
		height: 1.2rem;
	}
	.h2{
		height: 2rem;
	}
</style>