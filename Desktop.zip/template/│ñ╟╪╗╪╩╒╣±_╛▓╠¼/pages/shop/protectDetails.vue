<template>
	<div class="protectDetails pt10 oh bz">
		<div class="csb mlr_15 p15 cgf mb10 br">
			<div class="cca2">
				<span class="fz18 mb10">回收物收益</span>
				<span class="c9">2019-12-7 13:50:48</span>
			</div>
			<span class="cr fz24">+10</span>
		</div>
		<div class="csb mlr_15 p15 cgf mb10 br">
			<div class="cca2">
				<span class="fz18 mb10">回收物收益</span>
				<span class="c9">2019-12-7 13:50:48</span>
			</div>
			<span class="cr fz24">+10</span>
		</div>
	</div>
</template>

<script>
	export default{
		name:"protectDetails",
		components:{
		},
		data(){
			return {
			}
		},
		created(){

		},
		methods:{
			
		}
	} 
</script>

<style lang="scss" scoped>
	@import '@/assets/css/common.scss';
	.protectDetails{
		min-height: 100vh;
		background-color: #f5f5f5;
	}
</style>